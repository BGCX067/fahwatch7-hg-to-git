﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmXmlCreator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmXmlCreator))
        Me.tcMain = New System.Windows.Forms.TabControl()
        Me.tpDI = New System.Windows.Forms.TabPage()
        Me.gbSMP = New System.Windows.Forms.GroupBox()
        Me.txtGpuVistaBetaVersion = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.LinkLabel3 = New System.Windows.Forms.LinkLabel()
        Me.txtGpuVistaBetaClient = New System.Windows.Forms.TextBox()
        Me.txtGpuVistaBetaThread = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtGpuXP03BetaVersion = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.txtGpuXP03BetaClient = New System.Windows.Forms.TextBox()
        Me.txtGpuXP03BetaThread = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtGpu2XP03Url = New System.Windows.Forms.TextBox()
        Me.txtGpu2XP03AtiFAQ = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtGpu2VistaGuide = New System.Windows.Forms.TextBox()
        Me.txtGpu2VistaUrl = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.txtGpu2XP03Guide = New System.Windows.Forms.TextBox()
        Me.txtGpu2XP03NvidiaFAQ = New System.Windows.Forms.TextBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.txtGpu2VistaAtiFAQ = New System.Windows.Forms.TextBox()
        Me.txtCpuURL = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtGpu2VistaNvidiaFAQ = New System.Windows.Forms.TextBox()
        Me.txtCpuGuide = New System.Windows.Forms.TextBox()
        Me.txtCpuInstallation = New System.Windows.Forms.TextBox()
        Me.txtSmpBetaVersion = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.txtUrlDeino = New System.Windows.Forms.TextBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.txtUrlMpich = New System.Windows.Forms.TextBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.txtDeinoGuide = New System.Windows.Forms.TextBox()
        Me.txtDeinoFAQ = New System.Windows.Forms.TextBox()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.txtMpichGuide = New System.Windows.Forms.TextBox()
        Me.txtMpichFAQ = New System.Windows.Forms.TextBox()
        Me.txtSmpBetaClient = New System.Windows.Forms.TextBox()
        Me.txtSmpBetaThread = New System.Windows.Forms.TextBox()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.tpCI = New System.Windows.Forms.TabPage()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cmdLoad = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.rtfExplain = New System.Windows.Forms.RichTextBox()
        Me.tcSettings = New System.Windows.Forms.TabControl()
        Me.tpSXD = New System.Windows.Forms.TabPage()
        Me.gbClient = New System.Windows.Forms.GroupBox()
        Me.chkParameters = New System.Windows.Forms.CheckBox()
        Me.chkDisableCpuAffinityLock = New System.Windows.Forms.CheckBox()
        Me.chkService = New System.Windows.Forms.CheckBox()
        Me.chkWuSize = New System.Windows.Forms.CheckBox()
        Me.chkCpuUsage = New System.Windows.Forms.CheckBox()
        Me.chkDissableAssembly = New System.Windows.Forms.CheckBox()
        Me.chkPauseBattery = New System.Windows.Forms.CheckBox()
        Me.chkAdvancedMethods = New System.Windows.Forms.CheckBox()
        Me.chkInterval = New System.Windows.Forms.CheckBox()
        Me.chkIgnoreLocalDeadline = New System.Windows.Forms.CheckBox()
        Me.chkAskForNetwork = New System.Windows.Forms.CheckBox()
        Me.chkCorePriority = New System.Windows.Forms.CheckBox()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.txtParameters = New System.Windows.Forms.TextBox()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.cmbDisableCpuAffinityLock = New System.Windows.Forms.ComboBox()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.cmbAskForNetwork = New System.Windows.Forms.ComboBox()
        Me.cmbIgnoreLocalDeadlines = New System.Windows.Forms.ComboBox()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.cmbWuSize = New System.Windows.Forms.ComboBox()
        Me.cmbCorePriority = New System.Windows.Forms.ComboBox()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.nudInterval = New System.Windows.Forms.NumericUpDown()
        Me.cmdService = New System.Windows.Forms.ComboBox()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.cmbPauseBattery = New System.Windows.Forms.ComboBox()
        Me.nudCpuUsage = New System.Windows.Forms.NumericUpDown()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.cmdAdvancedMethods = New System.Windows.Forms.ComboBox()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.cmbDisableAssembly = New System.Windows.Forms.ComboBox()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.tpSXM = New System.Windows.Forms.TabPage()
        Me.tpSVD = New System.Windows.Forms.TabPage()
        Me.tpSVM = New System.Windows.Forms.TabPage()
        Me.tpGXA = New System.Windows.Forms.TabPage()
        Me.tpGXN = New System.Windows.Forms.TabPage()
        Me.tpGVA = New System.Windows.Forms.TabPage()
        Me.tpGVN = New System.Windows.Forms.TabPage()
        Me.tpCPU = New System.Windows.Forms.TabPage()
        Me.oDiag = New System.Windows.Forms.OpenFileDialog()
        Me.sDiag = New System.Windows.Forms.SaveFileDialog()
        Me.tcMain.SuspendLayout()
        Me.tpDI.SuspendLayout()
        Me.gbSMP.SuspendLayout()
        Me.tpCI.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.tcSettings.SuspendLayout()
        Me.tpSXD.SuspendLayout()
        Me.gbClient.SuspendLayout()
        CType(Me.nudInterval, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudCpuUsage, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tcMain
        '
        Me.tcMain.Controls.Add(Me.tpDI)
        Me.tcMain.Controls.Add(Me.tpCI)
        Me.tcMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tcMain.Location = New System.Drawing.Point(0, 0)
        Me.tcMain.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.tcMain.Name = "tcMain"
        Me.tcMain.SelectedIndex = 0
        Me.tcMain.Size = New System.Drawing.Size(847, 806)
        Me.tcMain.TabIndex = 1
        '
        'tpDI
        '
        Me.tpDI.Controls.Add(Me.gbSMP)
        Me.tpDI.Location = New System.Drawing.Point(4, 25)
        Me.tpDI.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.tpDI.Name = "tpDI"
        Me.tpDI.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.tpDI.Size = New System.Drawing.Size(839, 777)
        Me.tpDI.TabIndex = 0
        Me.tpDI.Text = "Download/Info urls"
        Me.tpDI.UseVisualStyleBackColor = True
        '
        'gbSMP
        '
        Me.gbSMP.Controls.Add(Me.txtGpuVistaBetaVersion)
        Me.gbSMP.Controls.Add(Me.Label14)
        Me.gbSMP.Controls.Add(Me.LinkLabel3)
        Me.gbSMP.Controls.Add(Me.txtGpuVistaBetaClient)
        Me.gbSMP.Controls.Add(Me.txtGpuVistaBetaThread)
        Me.gbSMP.Controls.Add(Me.Label18)
        Me.gbSMP.Controls.Add(Me.txtGpuXP03BetaVersion)
        Me.gbSMP.Controls.Add(Me.Label3)
        Me.gbSMP.Controls.Add(Me.LinkLabel1)
        Me.gbSMP.Controls.Add(Me.txtGpuXP03BetaClient)
        Me.gbSMP.Controls.Add(Me.txtGpuXP03BetaThread)
        Me.gbSMP.Controls.Add(Me.Label4)
        Me.gbSMP.Controls.Add(Me.txtGpu2XP03Url)
        Me.gbSMP.Controls.Add(Me.txtGpu2XP03AtiFAQ)
        Me.gbSMP.Controls.Add(Me.Label15)
        Me.gbSMP.Controls.Add(Me.Label16)
        Me.gbSMP.Controls.Add(Me.Label17)
        Me.gbSMP.Controls.Add(Me.txtGpu2VistaGuide)
        Me.gbSMP.Controls.Add(Me.txtGpu2VistaUrl)
        Me.gbSMP.Controls.Add(Me.Label21)
        Me.gbSMP.Controls.Add(Me.Label28)
        Me.gbSMP.Controls.Add(Me.Label29)
        Me.gbSMP.Controls.Add(Me.txtGpu2XP03Guide)
        Me.gbSMP.Controls.Add(Me.txtGpu2XP03NvidiaFAQ)
        Me.gbSMP.Controls.Add(Me.Label33)
        Me.gbSMP.Controls.Add(Me.Label1)
        Me.gbSMP.Controls.Add(Me.Label32)
        Me.gbSMP.Controls.Add(Me.txtGpu2VistaAtiFAQ)
        Me.gbSMP.Controls.Add(Me.txtCpuURL)
        Me.gbSMP.Controls.Add(Me.Label2)
        Me.gbSMP.Controls.Add(Me.Label5)
        Me.gbSMP.Controls.Add(Me.txtGpu2VistaNvidiaFAQ)
        Me.gbSMP.Controls.Add(Me.txtCpuGuide)
        Me.gbSMP.Controls.Add(Me.txtCpuInstallation)
        Me.gbSMP.Controls.Add(Me.txtSmpBetaVersion)
        Me.gbSMP.Controls.Add(Me.Label13)
        Me.gbSMP.Controls.Add(Me.LinkLabel2)
        Me.gbSMP.Controls.Add(Me.txtUrlDeino)
        Me.gbSMP.Controls.Add(Me.Label34)
        Me.gbSMP.Controls.Add(Me.Label35)
        Me.gbSMP.Controls.Add(Me.txtUrlMpich)
        Me.gbSMP.Controls.Add(Me.Label36)
        Me.gbSMP.Controls.Add(Me.Label40)
        Me.gbSMP.Controls.Add(Me.txtDeinoGuide)
        Me.gbSMP.Controls.Add(Me.txtDeinoFAQ)
        Me.gbSMP.Controls.Add(Me.Label42)
        Me.gbSMP.Controls.Add(Me.Label46)
        Me.gbSMP.Controls.Add(Me.txtMpichGuide)
        Me.gbSMP.Controls.Add(Me.txtMpichFAQ)
        Me.gbSMP.Controls.Add(Me.txtSmpBetaClient)
        Me.gbSMP.Controls.Add(Me.txtSmpBetaThread)
        Me.gbSMP.Controls.Add(Me.Label47)
        Me.gbSMP.Location = New System.Drawing.Point(12, 5)
        Me.gbSMP.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.gbSMP.Name = "gbSMP"
        Me.gbSMP.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.gbSMP.Size = New System.Drawing.Size(811, 763)
        Me.gbSMP.TabIndex = 127
        Me.gbSMP.TabStop = False
        Me.gbSMP.Text = "Download/Guide/Faq links"
        '
        'txtGpuVistaBetaVersion
        '
        Me.txtGpuVistaBetaVersion.Location = New System.Drawing.Point(681, 599)
        Me.txtGpuVistaBetaVersion.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtGpuVistaBetaVersion.Name = "txtGpuVistaBetaVersion"
        Me.txtGpuVistaBetaVersion.Size = New System.Drawing.Size(113, 22)
        Me.txtGpuVistaBetaVersion.TabIndex = 162
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(612, 603)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(61, 17)
        Me.Label14.TabIndex = 161
        Me.Label14.Text = "Version*"
        '
        'LinkLabel3
        '
        Me.LinkLabel3.AutoSize = True
        Me.LinkLabel3.Location = New System.Drawing.Point(72, 635)
        Me.LinkLabel3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LinkLabel3.Name = "LinkLabel3"
        Me.LinkLabel3.Size = New System.Drawing.Size(93, 17)
        Me.LinkLabel3.TabIndex = 160
        Me.LinkLabel3.TabStop = True
        Me.LinkLabel3.Text = "Forum thread"
        '
        'txtGpuVistaBetaClient
        '
        Me.txtGpuVistaBetaClient.Location = New System.Drawing.Point(173, 599)
        Me.txtGpuVistaBetaClient.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtGpuVistaBetaClient.Name = "txtGpuVistaBetaClient"
        Me.txtGpuVistaBetaClient.Size = New System.Drawing.Size(429, 22)
        Me.txtGpuVistaBetaClient.TabIndex = 157
        '
        'txtGpuVistaBetaThread
        '
        Me.txtGpuVistaBetaThread.Location = New System.Drawing.Point(173, 631)
        Me.txtGpuVistaBetaThread.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtGpuVistaBetaThread.Name = "txtGpuVistaBetaThread"
        Me.txtGpuVistaBetaThread.Size = New System.Drawing.Size(621, 22)
        Me.txtGpuVistaBetaThread.TabIndex = 158
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(83, 603)
        Me.Label18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(79, 17)
        Me.Label18.TabIndex = 159
        Me.Label18.Text = "Beta client*"
        '
        'txtGpuXP03BetaVersion
        '
        Me.txtGpuXP03BetaVersion.Location = New System.Drawing.Point(681, 405)
        Me.txtGpuXP03BetaVersion.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtGpuXP03BetaVersion.Name = "txtGpuXP03BetaVersion"
        Me.txtGpuXP03BetaVersion.Size = New System.Drawing.Size(113, 22)
        Me.txtGpuXP03BetaVersion.TabIndex = 156
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(612, 409)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(61, 17)
        Me.Label3.TabIndex = 155
        Me.Label3.Text = "Version*"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Location = New System.Drawing.Point(72, 441)
        Me.LinkLabel1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(93, 17)
        Me.LinkLabel1.TabIndex = 154
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Forum thread"
        '
        'txtGpuXP03BetaClient
        '
        Me.txtGpuXP03BetaClient.Location = New System.Drawing.Point(173, 405)
        Me.txtGpuXP03BetaClient.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtGpuXP03BetaClient.Name = "txtGpuXP03BetaClient"
        Me.txtGpuXP03BetaClient.Size = New System.Drawing.Size(429, 22)
        Me.txtGpuXP03BetaClient.TabIndex = 151
        '
        'txtGpuXP03BetaThread
        '
        Me.txtGpuXP03BetaThread.Location = New System.Drawing.Point(173, 437)
        Me.txtGpuXP03BetaThread.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtGpuXP03BetaThread.Name = "txtGpuXP03BetaThread"
        Me.txtGpuXP03BetaThread.Size = New System.Drawing.Size(621, 22)
        Me.txtGpuXP03BetaThread.TabIndex = 152
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(83, 409)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(79, 17)
        Me.Label4.TabIndex = 153
        Me.Label4.Text = "Beta client*"
        '
        'txtGpu2XP03Url
        '
        Me.txtGpu2XP03Url.Location = New System.Drawing.Point(173, 281)
        Me.txtGpu2XP03Url.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtGpu2XP03Url.Name = "txtGpu2XP03Url"
        Me.txtGpu2XP03Url.Size = New System.Drawing.Size(621, 22)
        Me.txtGpu2XP03Url.TabIndex = 135
        '
        'txtGpu2XP03AtiFAQ
        '
        Me.txtGpu2XP03AtiFAQ.Location = New System.Drawing.Point(173, 345)
        Me.txtGpu2XP03AtiFAQ.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtGpu2XP03AtiFAQ.Name = "txtGpu2XP03AtiFAQ"
        Me.txtGpu2XP03AtiFAQ.Size = New System.Drawing.Size(621, 22)
        Me.txtGpu2XP03AtiFAQ.TabIndex = 137
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(9, 286)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(149, 17)
        Me.Label15.TabIndex = 138
        Me.Label15.Text = "Gpu2 XP/03 download"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(96, 348)
        Me.Label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(65, 17)
        Me.Label16.TabIndex = 150
        Me.Label16.Text = "Faq ATI2"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(20, 475)
        Me.Label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(142, 17)
        Me.Label17.TabIndex = 144
        Me.Label17.Text = "Gpu2 Vista download"
        '
        'txtGpu2VistaGuide
        '
        Me.txtGpu2VistaGuide.Location = New System.Drawing.Point(173, 566)
        Me.txtGpu2VistaGuide.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtGpu2VistaGuide.Name = "txtGpu2VistaGuide"
        Me.txtGpu2VistaGuide.Size = New System.Drawing.Size(621, 22)
        Me.txtGpu2VistaGuide.TabIndex = 143
        '
        'txtGpu2VistaUrl
        '
        Me.txtGpu2VistaUrl.Location = New System.Drawing.Point(173, 470)
        Me.txtGpu2VistaUrl.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtGpu2VistaUrl.Name = "txtGpu2VistaUrl"
        Me.txtGpu2VistaUrl.Size = New System.Drawing.Size(621, 22)
        Me.txtGpu2VistaUrl.TabIndex = 140
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(117, 570)
        Me.Label21.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(46, 17)
        Me.Label21.TabIndex = 149
        Me.Label21.Text = "Guide"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(87, 316)
        Me.Label28.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(75, 17)
        Me.Label28.TabIndex = 145
        Me.Label28.Text = "Faq Nvidia"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(117, 378)
        Me.Label29.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(46, 17)
        Me.Label29.TabIndex = 146
        Me.Label29.Text = "Guide"
        '
        'txtGpu2XP03Guide
        '
        Me.txtGpu2XP03Guide.Location = New System.Drawing.Point(173, 374)
        Me.txtGpu2XP03Guide.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtGpu2XP03Guide.Name = "txtGpu2XP03Guide"
        Me.txtGpu2XP03Guide.Size = New System.Drawing.Size(621, 22)
        Me.txtGpu2XP03Guide.TabIndex = 139
        '
        'txtGpu2XP03NvidiaFAQ
        '
        Me.txtGpu2XP03NvidiaFAQ.Location = New System.Drawing.Point(173, 313)
        Me.txtGpu2XP03NvidiaFAQ.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtGpu2XP03NvidiaFAQ.Name = "txtGpu2XP03NvidiaFAQ"
        Me.txtGpu2XP03NvidiaFAQ.Size = New System.Drawing.Size(621, 22)
        Me.txtGpu2XP03NvidiaFAQ.TabIndex = 136
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(96, 538)
        Me.Label33.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(65, 17)
        Me.Label33.TabIndex = 148
        Me.Label33.Text = "Faq ATI2"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(15, 667)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(150, 17)
        Me.Label1.TabIndex = 166
        Me.Label1.Text = "Cpu console download"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(87, 506)
        Me.Label32.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(75, 17)
        Me.Label32.TabIndex = 147
        Me.Label32.Text = "Faq Nvidia"
        '
        'txtGpu2VistaAtiFAQ
        '
        Me.txtGpu2VistaAtiFAQ.Location = New System.Drawing.Point(173, 534)
        Me.txtGpu2VistaAtiFAQ.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtGpu2VistaAtiFAQ.Name = "txtGpu2VistaAtiFAQ"
        Me.txtGpu2VistaAtiFAQ.Size = New System.Drawing.Size(621, 22)
        Me.txtGpu2VistaAtiFAQ.TabIndex = 142
        '
        'txtCpuURL
        '
        Me.txtCpuURL.Location = New System.Drawing.Point(173, 663)
        Me.txtCpuURL.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtCpuURL.Name = "txtCpuURL"
        Me.txtCpuURL.Size = New System.Drawing.Size(621, 22)
        Me.txtCpuURL.TabIndex = 163
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(65, 699)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 17)
        Me.Label2.TabIndex = 167
        Me.Label2.Text = "Uni installation"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(96, 731)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(68, 17)
        Me.Label5.TabIndex = 168
        Me.Label5.Text = "Uni guide"
        '
        'txtGpu2VistaNvidiaFAQ
        '
        Me.txtGpu2VistaNvidiaFAQ.Location = New System.Drawing.Point(173, 502)
        Me.txtGpu2VistaNvidiaFAQ.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtGpu2VistaNvidiaFAQ.Name = "txtGpu2VistaNvidiaFAQ"
        Me.txtGpu2VistaNvidiaFAQ.Size = New System.Drawing.Size(621, 22)
        Me.txtGpu2VistaNvidiaFAQ.TabIndex = 141
        '
        'txtCpuGuide
        '
        Me.txtCpuGuide.Location = New System.Drawing.Point(173, 727)
        Me.txtCpuGuide.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtCpuGuide.Name = "txtCpuGuide"
        Me.txtCpuGuide.Size = New System.Drawing.Size(621, 22)
        Me.txtCpuGuide.TabIndex = 165
        '
        'txtCpuInstallation
        '
        Me.txtCpuInstallation.Location = New System.Drawing.Point(173, 695)
        Me.txtCpuInstallation.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtCpuInstallation.Name = "txtCpuInstallation"
        Me.txtCpuInstallation.Size = New System.Drawing.Size(621, 22)
        Me.txtCpuInstallation.TabIndex = 164
        '
        'txtSmpBetaVersion
        '
        Me.txtSmpBetaVersion.Location = New System.Drawing.Point(681, 214)
        Me.txtSmpBetaVersion.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtSmpBetaVersion.Name = "txtSmpBetaVersion"
        Me.txtSmpBetaVersion.Size = New System.Drawing.Size(113, 22)
        Me.txtSmpBetaVersion.TabIndex = 47
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(612, 218)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(61, 17)
        Me.Label13.TabIndex = 46
        Me.Label13.Text = "Version*"
        '
        'LinkLabel2
        '
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.Location = New System.Drawing.Point(72, 250)
        Me.LinkLabel2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(93, 17)
        Me.LinkLabel2.TabIndex = 45
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "Forum thread"
        '
        'txtUrlDeino
        '
        Me.txtUrlDeino.Location = New System.Drawing.Point(173, 23)
        Me.txtUrlDeino.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtUrlDeino.Name = "txtUrlDeino"
        Me.txtUrlDeino.Size = New System.Drawing.Size(621, 22)
        Me.txtUrlDeino.TabIndex = 1
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(52, 28)
        Me.Label34.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(109, 17)
        Me.Label34.TabIndex = 8
        Me.Label34.Text = "Deino download"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(44, 123)
        Me.Label35.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(114, 17)
        Me.Label35.TabIndex = 9
        Me.Label35.Text = "MPICH download"
        '
        'txtUrlMpich
        '
        Me.txtUrlMpich.Location = New System.Drawing.Point(173, 118)
        Me.txtUrlMpich.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtUrlMpich.Name = "txtUrlMpich"
        Me.txtUrlMpich.Size = New System.Drawing.Size(621, 22)
        Me.txtUrlMpich.TabIndex = 4
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(127, 59)
        Me.Label36.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(36, 17)
        Me.Label36.TabIndex = 20
        Me.Label36.Text = "FAQ"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(117, 91)
        Me.Label40.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(46, 17)
        Me.Label40.TabIndex = 21
        Me.Label40.Text = "Guide"
        '
        'txtDeinoGuide
        '
        Me.txtDeinoGuide.Location = New System.Drawing.Point(173, 87)
        Me.txtDeinoGuide.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtDeinoGuide.Name = "txtDeinoGuide"
        Me.txtDeinoGuide.Size = New System.Drawing.Size(621, 22)
        Me.txtDeinoGuide.TabIndex = 3
        '
        'txtDeinoFAQ
        '
        Me.txtDeinoFAQ.Location = New System.Drawing.Point(173, 55)
        Me.txtDeinoFAQ.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtDeinoFAQ.Name = "txtDeinoFAQ"
        Me.txtDeinoFAQ.Size = New System.Drawing.Size(621, 22)
        Me.txtDeinoFAQ.TabIndex = 2
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(127, 154)
        Me.Label42.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(36, 17)
        Me.Label42.TabIndex = 24
        Me.Label42.Text = "FAQ"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(117, 186)
        Me.Label46.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(46, 17)
        Me.Label46.TabIndex = 25
        Me.Label46.Text = "Guide"
        '
        'txtMpichGuide
        '
        Me.txtMpichGuide.Location = New System.Drawing.Point(173, 182)
        Me.txtMpichGuide.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtMpichGuide.Name = "txtMpichGuide"
        Me.txtMpichGuide.Size = New System.Drawing.Size(621, 22)
        Me.txtMpichGuide.TabIndex = 6
        '
        'txtMpichFAQ
        '
        Me.txtMpichFAQ.Location = New System.Drawing.Point(173, 150)
        Me.txtMpichFAQ.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtMpichFAQ.Name = "txtMpichFAQ"
        Me.txtMpichFAQ.Size = New System.Drawing.Size(621, 22)
        Me.txtMpichFAQ.TabIndex = 5
        '
        'txtSmpBetaClient
        '
        Me.txtSmpBetaClient.Location = New System.Drawing.Point(173, 214)
        Me.txtSmpBetaClient.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtSmpBetaClient.Name = "txtSmpBetaClient"
        Me.txtSmpBetaClient.Size = New System.Drawing.Size(429, 22)
        Me.txtSmpBetaClient.TabIndex = 7
        '
        'txtSmpBetaThread
        '
        Me.txtSmpBetaThread.Location = New System.Drawing.Point(173, 246)
        Me.txtSmpBetaThread.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtSmpBetaThread.Name = "txtSmpBetaThread"
        Me.txtSmpBetaThread.Size = New System.Drawing.Size(621, 22)
        Me.txtSmpBetaThread.TabIndex = 8
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(83, 218)
        Me.Label47.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(79, 17)
        Me.Label47.TabIndex = 44
        Me.Label47.Text = "Beta client*"
        '
        'tpCI
        '
        Me.tpCI.Controls.Add(Me.Panel1)
        Me.tpCI.Controls.Add(Me.tcSettings)
        Me.tpCI.Location = New System.Drawing.Point(4, 25)
        Me.tpCI.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.tpCI.Name = "tpCI"
        Me.tpCI.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.tpCI.Size = New System.Drawing.Size(839, 777)
        Me.tpCI.TabIndex = 1
        Me.tpCI.Text = "Client/Installer settings"
        Me.tpCI.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.cmdLoad)
        Me.Panel1.Controls.Add(Me.cmdSave)
        Me.Panel1.Controls.Add(Me.rtfExplain)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(4, 407)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(831, 366)
        Me.Panel1.TabIndex = 137
        '
        'cmdLoad
        '
        Me.cmdLoad.Location = New System.Drawing.Point(476, 330)
        Me.cmdLoad.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmdLoad.Name = "cmdLoad"
        Me.cmdLoad.Size = New System.Drawing.Size(168, 30)
        Me.cmdLoad.TabIndex = 2
        Me.cmdLoad.Text = "Load xml"
        Me.cmdLoad.UseVisualStyleBackColor = True
        '
        'cmdSave
        '
        Me.cmdSave.Location = New System.Drawing.Point(656, 330)
        Me.cmdSave.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(168, 30)
        Me.cmdSave.TabIndex = 1
        Me.cmdSave.Text = "Save xml"
        Me.cmdSave.UseVisualStyleBackColor = True
        '
        'rtfExplain
        '
        Me.rtfExplain.Dock = System.Windows.Forms.DockStyle.Top
        Me.rtfExplain.Location = New System.Drawing.Point(0, 0)
        Me.rtfExplain.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rtfExplain.Name = "rtfExplain"
        Me.rtfExplain.ReadOnly = True
        Me.rtfExplain.Size = New System.Drawing.Size(831, 324)
        Me.rtfExplain.TabIndex = 0
        Me.rtfExplain.Text = resources.GetString("rtfExplain.Text")
        '
        'tcSettings
        '
        Me.tcSettings.Controls.Add(Me.tpSXD)
        Me.tcSettings.Controls.Add(Me.tpSXM)
        Me.tcSettings.Controls.Add(Me.tpSVD)
        Me.tcSettings.Controls.Add(Me.tpSVM)
        Me.tcSettings.Controls.Add(Me.tpGXA)
        Me.tcSettings.Controls.Add(Me.tpGXN)
        Me.tcSettings.Controls.Add(Me.tpGVA)
        Me.tcSettings.Controls.Add(Me.tpGVN)
        Me.tcSettings.Controls.Add(Me.tpCPU)
        Me.tcSettings.Dock = System.Windows.Forms.DockStyle.Top
        Me.tcSettings.Location = New System.Drawing.Point(4, 4)
        Me.tcSettings.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.tcSettings.Multiline = True
        Me.tcSettings.Name = "tcSettings"
        Me.tcSettings.SelectedIndex = 0
        Me.tcSettings.Size = New System.Drawing.Size(831, 398)
        Me.tcSettings.TabIndex = 136
        '
        'tpSXD
        '
        Me.tpSXD.Controls.Add(Me.gbClient)
        Me.tpSXD.Location = New System.Drawing.Point(4, 46)
        Me.tpSXD.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.tpSXD.Name = "tpSXD"
        Me.tpSXD.Size = New System.Drawing.Size(823, 348)
        Me.tpSXD.TabIndex = 0
        Me.tpSXD.Text = "SMP XP/03 Deino"
        Me.tpSXD.UseVisualStyleBackColor = True
        '
        'gbClient
        '
        Me.gbClient.Controls.Add(Me.chkParameters)
        Me.gbClient.Controls.Add(Me.chkDisableCpuAffinityLock)
        Me.gbClient.Controls.Add(Me.chkService)
        Me.gbClient.Controls.Add(Me.chkWuSize)
        Me.gbClient.Controls.Add(Me.chkCpuUsage)
        Me.gbClient.Controls.Add(Me.chkDissableAssembly)
        Me.gbClient.Controls.Add(Me.chkPauseBattery)
        Me.gbClient.Controls.Add(Me.chkAdvancedMethods)
        Me.gbClient.Controls.Add(Me.chkInterval)
        Me.gbClient.Controls.Add(Me.chkIgnoreLocalDeadline)
        Me.gbClient.Controls.Add(Me.chkAskForNetwork)
        Me.gbClient.Controls.Add(Me.chkCorePriority)
        Me.gbClient.Controls.Add(Me.Label75)
        Me.gbClient.Controls.Add(Me.txtParameters)
        Me.gbClient.Controls.Add(Me.Label76)
        Me.gbClient.Controls.Add(Me.cmbDisableCpuAffinityLock)
        Me.gbClient.Controls.Add(Me.Label77)
        Me.gbClient.Controls.Add(Me.cmbAskForNetwork)
        Me.gbClient.Controls.Add(Me.cmbIgnoreLocalDeadlines)
        Me.gbClient.Controls.Add(Me.Label78)
        Me.gbClient.Controls.Add(Me.Label79)
        Me.gbClient.Controls.Add(Me.cmbWuSize)
        Me.gbClient.Controls.Add(Me.cmbCorePriority)
        Me.gbClient.Controls.Add(Me.Label80)
        Me.gbClient.Controls.Add(Me.Label81)
        Me.gbClient.Controls.Add(Me.Label82)
        Me.gbClient.Controls.Add(Me.nudInterval)
        Me.gbClient.Controls.Add(Me.cmdService)
        Me.gbClient.Controls.Add(Me.Label83)
        Me.gbClient.Controls.Add(Me.cmbPauseBattery)
        Me.gbClient.Controls.Add(Me.nudCpuUsage)
        Me.gbClient.Controls.Add(Me.Label85)
        Me.gbClient.Controls.Add(Me.cmdAdvancedMethods)
        Me.gbClient.Controls.Add(Me.Label86)
        Me.gbClient.Controls.Add(Me.cmbDisableAssembly)
        Me.gbClient.Controls.Add(Me.Label87)
        Me.gbClient.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gbClient.Location = New System.Drawing.Point(0, 0)
        Me.gbClient.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.gbClient.Name = "gbClient"
        Me.gbClient.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.gbClient.Size = New System.Drawing.Size(823, 348)
        Me.gbClient.TabIndex = 123
        Me.gbClient.TabStop = False
        Me.gbClient.Tag = "False"
        '
        'chkParameters
        '
        Me.chkParameters.AutoSize = True
        Me.chkParameters.Location = New System.Drawing.Point(785, 313)
        Me.chkParameters.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.chkParameters.Name = "chkParameters"
        Me.chkParameters.Size = New System.Drawing.Size(18, 17)
        Me.chkParameters.TabIndex = 126
        Me.chkParameters.UseVisualStyleBackColor = True
        '
        'chkDisableCpuAffinityLock
        '
        Me.chkDisableCpuAffinityLock.AutoSize = True
        Me.chkDisableCpuAffinityLock.Location = New System.Drawing.Point(785, 282)
        Me.chkDisableCpuAffinityLock.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.chkDisableCpuAffinityLock.Name = "chkDisableCpuAffinityLock"
        Me.chkDisableCpuAffinityLock.Size = New System.Drawing.Size(18, 17)
        Me.chkDisableCpuAffinityLock.TabIndex = 125
        Me.chkDisableCpuAffinityLock.UseVisualStyleBackColor = True
        '
        'chkService
        '
        Me.chkService.AutoSize = True
        Me.chkService.Location = New System.Drawing.Point(785, 15)
        Me.chkService.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.chkService.Name = "chkService"
        Me.chkService.Size = New System.Drawing.Size(18, 17)
        Me.chkService.TabIndex = 124
        Me.chkService.UseVisualStyleBackColor = True
        '
        'chkWuSize
        '
        Me.chkWuSize.AutoSize = True
        Me.chkWuSize.Location = New System.Drawing.Point(785, 55)
        Me.chkWuSize.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.chkWuSize.Name = "chkWuSize"
        Me.chkWuSize.Size = New System.Drawing.Size(18, 17)
        Me.chkWuSize.TabIndex = 123
        Me.chkWuSize.UseVisualStyleBackColor = True
        '
        'chkCpuUsage
        '
        Me.chkCpuUsage.AutoSize = True
        Me.chkCpuUsage.Location = New System.Drawing.Point(785, 97)
        Me.chkCpuUsage.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.chkCpuUsage.Name = "chkCpuUsage"
        Me.chkCpuUsage.Size = New System.Drawing.Size(18, 17)
        Me.chkCpuUsage.TabIndex = 122
        Me.chkCpuUsage.UseVisualStyleBackColor = True
        '
        'chkDissableAssembly
        '
        Me.chkDissableAssembly.AutoSize = True
        Me.chkDissableAssembly.Location = New System.Drawing.Point(412, 128)
        Me.chkDissableAssembly.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.chkDissableAssembly.Name = "chkDissableAssembly"
        Me.chkDissableAssembly.Size = New System.Drawing.Size(18, 17)
        Me.chkDissableAssembly.TabIndex = 121
        Me.chkDissableAssembly.UseVisualStyleBackColor = True
        '
        'chkPauseBattery
        '
        Me.chkPauseBattery.AutoSize = True
        Me.chkPauseBattery.Location = New System.Drawing.Point(785, 159)
        Me.chkPauseBattery.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.chkPauseBattery.Name = "chkPauseBattery"
        Me.chkPauseBattery.Size = New System.Drawing.Size(18, 17)
        Me.chkPauseBattery.TabIndex = 120
        Me.chkPauseBattery.UseVisualStyleBackColor = True
        '
        'chkAdvancedMethods
        '
        Me.chkAdvancedMethods.AutoSize = True
        Me.chkAdvancedMethods.Location = New System.Drawing.Point(785, 220)
        Me.chkAdvancedMethods.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.chkAdvancedMethods.Name = "chkAdvancedMethods"
        Me.chkAdvancedMethods.Size = New System.Drawing.Size(18, 17)
        Me.chkAdvancedMethods.TabIndex = 119
        Me.chkAdvancedMethods.UseVisualStyleBackColor = True
        '
        'chkInterval
        '
        Me.chkInterval.AutoSize = True
        Me.chkInterval.Location = New System.Drawing.Point(785, 190)
        Me.chkInterval.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.chkInterval.Name = "chkInterval"
        Me.chkInterval.Size = New System.Drawing.Size(18, 17)
        Me.chkInterval.TabIndex = 118
        Me.chkInterval.UseVisualStyleBackColor = True
        '
        'chkIgnoreLocalDeadline
        '
        Me.chkIgnoreLocalDeadline.AutoSize = True
        Me.chkIgnoreLocalDeadline.Location = New System.Drawing.Point(785, 251)
        Me.chkIgnoreLocalDeadline.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.chkIgnoreLocalDeadline.Name = "chkIgnoreLocalDeadline"
        Me.chkIgnoreLocalDeadline.Size = New System.Drawing.Size(18, 17)
        Me.chkIgnoreLocalDeadline.TabIndex = 117
        Me.chkIgnoreLocalDeadline.UseVisualStyleBackColor = True
        '
        'chkAskForNetwork
        '
        Me.chkAskForNetwork.AutoSize = True
        Me.chkAskForNetwork.Location = New System.Drawing.Point(785, 128)
        Me.chkAskForNetwork.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.chkAskForNetwork.Name = "chkAskForNetwork"
        Me.chkAskForNetwork.Size = New System.Drawing.Size(18, 17)
        Me.chkAskForNetwork.TabIndex = 116
        Me.chkAskForNetwork.UseVisualStyleBackColor = True
        '
        'chkCorePriority
        '
        Me.chkCorePriority.AutoSize = True
        Me.chkCorePriority.Location = New System.Drawing.Point(411, 97)
        Me.chkCorePriority.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.chkCorePriority.Name = "chkCorePriority"
        Me.chkCorePriority.Size = New System.Drawing.Size(18, 17)
        Me.chkCorePriority.TabIndex = 115
        Me.chkCorePriority.UseVisualStyleBackColor = True
        '
        'Label75
        '
        Me.Label75.Location = New System.Drawing.Point(20, 47)
        Me.Label75.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(661, 37)
        Me.Label75.TabIndex = 31
        Me.Label75.Text = "Acceptable size of work assignment and work result packets (bigger units may have" & _
            " large memory demands) -- 'small' is <5MB, 'normal' is <10MB, and 'big' is >10MB" & _
            " "
        '
        'txtParameters
        '
        Me.txtParameters.Location = New System.Drawing.Point(209, 309)
        Me.txtParameters.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtParameters.Name = "txtParameters"
        Me.txtParameters.Size = New System.Drawing.Size(567, 22)
        Me.txtParameters.TabIndex = 113
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.Location = New System.Drawing.Point(20, 314)
        Me.Label76.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(183, 17)
        Me.Label76.TabIndex = 112
        Me.Label76.Text = "Additional client parameters"
        '
        'cmbDisableCpuAffinityLock
        '
        Me.cmbDisableCpuAffinityLock.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbDisableCpuAffinityLock.FormattingEnabled = True
        Me.cmbDisableCpuAffinityLock.Items.AddRange(New Object() {"no", "yes"})
        Me.cmbDisableCpuAffinityLock.Location = New System.Drawing.Point(711, 278)
        Me.cmbDisableCpuAffinityLock.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmbDisableCpuAffinityLock.Name = "cmbDisableCpuAffinityLock"
        Me.cmbDisableCpuAffinityLock.Size = New System.Drawing.Size(65, 24)
        Me.cmbDisableCpuAffinityLock.TabIndex = 111
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.Location = New System.Drawing.Point(20, 283)
        Me.Label77.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(161, 17)
        Me.Label77.TabIndex = 110
        Me.Label77.Text = "Disable CPU affinity lock"
        '
        'cmbAskForNetwork
        '
        Me.cmbAskForNetwork.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbAskForNetwork.FormattingEnabled = True
        Me.cmbAskForNetwork.Items.AddRange(New Object() {"no", "yes"})
        Me.cmbAskForNetwork.Location = New System.Drawing.Point(709, 124)
        Me.cmbAskForNetwork.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmbAskForNetwork.Name = "cmbAskForNetwork"
        Me.cmbAskForNetwork.Size = New System.Drawing.Size(65, 24)
        Me.cmbAskForNetwork.TabIndex = 91
        '
        'cmbIgnoreLocalDeadlines
        '
        Me.cmbIgnoreLocalDeadlines.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbIgnoreLocalDeadlines.FormattingEnabled = True
        Me.cmbIgnoreLocalDeadlines.Items.AddRange(New Object() {"no", "yes"})
        Me.cmbIgnoreLocalDeadlines.Location = New System.Drawing.Point(709, 247)
        Me.cmbIgnoreLocalDeadlines.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmbIgnoreLocalDeadlines.Name = "cmbIgnoreLocalDeadlines"
        Me.cmbIgnoreLocalDeadlines.Size = New System.Drawing.Size(65, 24)
        Me.cmbIgnoreLocalDeadlines.TabIndex = 81
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Location = New System.Drawing.Point(20, 252)
        Me.Label78.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(534, 17)
        Me.Label78.TabIndex = 79
        Me.Label78.Text = "Ignore any deadline information (mainly useful if system clock frequently has err" & _
            "ors)"
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Location = New System.Drawing.Point(467, 129)
        Me.Label79.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(225, 17)
        Me.Label79.TabIndex = 90
        Me.Label79.Text = "Ask before fetching/sending work?"
        '
        'cmbWuSize
        '
        Me.cmbWuSize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbWuSize.FormattingEnabled = True
        Me.cmbWuSize.Items.AddRange(New Object() {"normal", "small", "big"})
        Me.cmbWuSize.Location = New System.Drawing.Point(691, 50)
        Me.cmbWuSize.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmbWuSize.Name = "cmbWuSize"
        Me.cmbWuSize.Size = New System.Drawing.Size(85, 24)
        Me.cmbWuSize.TabIndex = 44
        '
        'cmbCorePriority
        '
        Me.cmbCorePriority.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbCorePriority.FormattingEnabled = True
        Me.cmbCorePriority.Items.AddRange(New Object() {"idle", "low"})
        Me.cmbCorePriority.Location = New System.Drawing.Point(316, 94)
        Me.cmbCorePriority.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmbCorePriority.Name = "cmbCorePriority"
        Me.cmbCorePriority.Size = New System.Drawing.Size(85, 24)
        Me.cmbCorePriority.TabIndex = 77
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.Location = New System.Drawing.Point(467, 98)
        Me.Label80.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(144, 17)
        Me.Label80.TabIndex = 78
        Me.Label80.Text = "Cpu usage requested"
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.Location = New System.Drawing.Point(20, 98)
        Me.Label81.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(90, 17)
        Me.Label81.TabIndex = 69
        Me.Label81.Text = "Core Priority "
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.Location = New System.Drawing.Point(20, 16)
        Me.Label82.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(377, 17)
        Me.Label82.TabIndex = 30
        Me.Label82.Text = "Launch automatically, install as a service in this directory ?"
        '
        'nudInterval
        '
        Me.nudInterval.Location = New System.Drawing.Point(711, 186)
        Me.nudInterval.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.nudInterval.Maximum = New Decimal(New Integer() {30, 0, 0, 0})
        Me.nudInterval.Minimum = New Decimal(New Integer() {3, 0, 0, 0})
        Me.nudInterval.Name = "nudInterval"
        Me.nudInterval.Size = New System.Drawing.Size(67, 22)
        Me.nudInterval.TabIndex = 76
        Me.nudInterval.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudInterval.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left
        Me.nudInterval.Value = New Decimal(New Integer() {15, 0, 0, 0})
        '
        'cmdService
        '
        Me.cmdService.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmdService.FormattingEnabled = True
        Me.cmdService.Items.AddRange(New Object() {"no", "yes"})
        Me.cmdService.Location = New System.Drawing.Point(691, 11)
        Me.cmdService.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmdService.Name = "cmdService"
        Me.cmdService.Size = New System.Drawing.Size(85, 24)
        Me.cmdService.TabIndex = 74
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.Location = New System.Drawing.Point(20, 191)
        Me.Label83.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(270, 17)
        Me.Label83.TabIndex = 75
        Me.Label83.Text = "Interval, in minutes, between checkpoints "
        '
        'cmbPauseBattery
        '
        Me.cmbPauseBattery.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbPauseBattery.FormattingEnabled = True
        Me.cmbPauseBattery.Items.AddRange(New Object() {"no", "yes"})
        Me.cmbPauseBattery.Location = New System.Drawing.Point(709, 155)
        Me.cmbPauseBattery.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmbPauseBattery.Name = "cmbPauseBattery"
        Me.cmbPauseBattery.Size = New System.Drawing.Size(65, 24)
        Me.cmbPauseBattery.TabIndex = 72
        '
        'nudCpuUsage
        '
        Me.nudCpuUsage.Location = New System.Drawing.Point(691, 94)
        Me.nudCpuUsage.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.nudCpuUsage.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudCpuUsage.Name = "nudCpuUsage"
        Me.nudCpuUsage.Size = New System.Drawing.Size(87, 22)
        Me.nudCpuUsage.TabIndex = 70
        Me.nudCpuUsage.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudCpuUsage.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left
        Me.nudCpuUsage.Value = New Decimal(New Integer() {100, 0, 0, 0})
        '
        'Label85
        '
        Me.Label85.AutoSize = True
        Me.Label85.Location = New System.Drawing.Point(20, 222)
        Me.Label85.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(638, 17)
        Me.Label85.TabIndex = 66
        Me.Label85.Text = "Set -advmethods flag always, requesting new advanced scientific cores and/or work" & _
            " units if available" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'cmdAdvancedMethods
        '
        Me.cmdAdvancedMethods.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmdAdvancedMethods.FormattingEnabled = True
        Me.cmdAdvancedMethods.Items.AddRange(New Object() {"no", "yes"})
        Me.cmdAdvancedMethods.Location = New System.Drawing.Point(711, 217)
        Me.cmdAdvancedMethods.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmdAdvancedMethods.Name = "cmdAdvancedMethods"
        Me.cmdAdvancedMethods.Size = New System.Drawing.Size(65, 24)
        Me.cmdAdvancedMethods.TabIndex = 67
        '
        'Label86
        '
        Me.Label86.AutoSize = True
        Me.Label86.Location = New System.Drawing.Point(20, 160)
        Me.Label86.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(360, 17)
        Me.Label86.TabIndex = 57
        Me.Label86.Text = "Pause if battery power is being used (useful for laptops)"
        '
        'cmbDisableAssembly
        '
        Me.cmbDisableAssembly.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbDisableAssembly.FormattingEnabled = True
        Me.cmbDisableAssembly.Items.AddRange(New Object() {"no", "yes"})
        Me.cmbDisableAssembly.Location = New System.Drawing.Point(316, 124)
        Me.cmbDisableAssembly.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmbDisableAssembly.Name = "cmbDisableAssembly"
        Me.cmbDisableAssembly.Size = New System.Drawing.Size(85, 24)
        Me.cmbDisableAssembly.TabIndex = 65
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.Location = New System.Drawing.Point(20, 129)
        Me.Label87.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(258, 17)
        Me.Label87.TabIndex = 56
        Me.Label87.Text = "Disable highly optimized assembly code"
        '
        'tpSXM
        '
        Me.tpSXM.Location = New System.Drawing.Point(4, 46)
        Me.tpSXM.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.tpSXM.Name = "tpSXM"
        Me.tpSXM.Size = New System.Drawing.Size(820, 348)
        Me.tpSXM.TabIndex = 1
        Me.tpSXM.Text = "SMP XP/03 Mpich"
        Me.tpSXM.UseVisualStyleBackColor = True
        '
        'tpSVD
        '
        Me.tpSVD.Location = New System.Drawing.Point(4, 46)
        Me.tpSVD.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.tpSVD.Name = "tpSVD"
        Me.tpSVD.Size = New System.Drawing.Size(820, 348)
        Me.tpSVD.TabIndex = 2
        Me.tpSVD.Text = "SMP Vista Deino"
        Me.tpSVD.UseVisualStyleBackColor = True
        '
        'tpSVM
        '
        Me.tpSVM.Location = New System.Drawing.Point(4, 46)
        Me.tpSVM.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.tpSVM.Name = "tpSVM"
        Me.tpSVM.Size = New System.Drawing.Size(820, 348)
        Me.tpSVM.TabIndex = 3
        Me.tpSVM.Text = "SMP Vista Mpich"
        Me.tpSVM.UseVisualStyleBackColor = True
        '
        'tpGXA
        '
        Me.tpGXA.Location = New System.Drawing.Point(4, 46)
        Me.tpGXA.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.tpGXA.Name = "tpGXA"
        Me.tpGXA.Size = New System.Drawing.Size(820, 348)
        Me.tpGXA.TabIndex = 4
        Me.tpGXA.Text = "Gpu2 XP/03 Ati"
        Me.tpGXA.UseVisualStyleBackColor = True
        '
        'tpGXN
        '
        Me.tpGXN.Location = New System.Drawing.Point(4, 46)
        Me.tpGXN.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.tpGXN.Name = "tpGXN"
        Me.tpGXN.Size = New System.Drawing.Size(820, 348)
        Me.tpGXN.TabIndex = 5
        Me.tpGXN.Text = "Gpu XP/03 Nvidia"
        Me.tpGXN.UseVisualStyleBackColor = True
        '
        'tpGVA
        '
        Me.tpGVA.Location = New System.Drawing.Point(4, 46)
        Me.tpGVA.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.tpGVA.Name = "tpGVA"
        Me.tpGVA.Size = New System.Drawing.Size(820, 348)
        Me.tpGVA.TabIndex = 6
        Me.tpGVA.Text = "Gpu Vista Ati"
        Me.tpGVA.UseVisualStyleBackColor = True
        '
        'tpGVN
        '
        Me.tpGVN.Location = New System.Drawing.Point(4, 46)
        Me.tpGVN.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.tpGVN.Name = "tpGVN"
        Me.tpGVN.Size = New System.Drawing.Size(820, 348)
        Me.tpGVN.TabIndex = 7
        Me.tpGVN.Text = "Gpu Vista Nvidia"
        Me.tpGVN.UseVisualStyleBackColor = True
        '
        'tpCPU
        '
        Me.tpCPU.Location = New System.Drawing.Point(4, 46)
        Me.tpCPU.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.tpCPU.Name = "tpCPU"
        Me.tpCPU.Size = New System.Drawing.Size(820, 348)
        Me.tpCPU.TabIndex = 8
        Me.tpCPU.Text = "Cpu XP/03/Vista"
        Me.tpCPU.UseVisualStyleBackColor = True
        '
        'oDiag
        '
        Me.oDiag.FileName = "mtmFAH_script.xml"
        Me.oDiag.RestoreDirectory = True
        Me.oDiag.Title = "Load from xml"
        '
        'sDiag
        '
        Me.sDiag.FileName = "mtmFAH_script.xml"
        Me.sDiag.RestoreDirectory = True
        Me.sDiag.Title = "Save to xml"
        '
        'frmXmlCreator
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(847, 806)
        Me.Controls.Add(Me.tcMain)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.MaximizeBox = False
        Me.Name = "frmXmlCreator"
        Me.Text = "mtmFAH"
        Me.tcMain.ResumeLayout(False)
        Me.tpDI.ResumeLayout(False)
        Me.gbSMP.ResumeLayout(False)
        Me.gbSMP.PerformLayout()
        Me.tpCI.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.tcSettings.ResumeLayout(False)
        Me.tpSXD.ResumeLayout(False)
        Me.gbClient.ResumeLayout(False)
        Me.gbClient.PerformLayout()
        CType(Me.nudInterval, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudCpuUsage, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents tcMain As System.Windows.Forms.TabControl
    Friend WithEvents tpDI As System.Windows.Forms.TabPage
    Friend WithEvents gbSMP As System.Windows.Forms.GroupBox
    Friend WithEvents LinkLabel2 As System.Windows.Forms.LinkLabel
    Friend WithEvents txtUrlDeino As System.Windows.Forms.TextBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents txtUrlMpich As System.Windows.Forms.TextBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents txtDeinoGuide As System.Windows.Forms.TextBox
    Friend WithEvents txtDeinoFAQ As System.Windows.Forms.TextBox
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents txtMpichGuide As System.Windows.Forms.TextBox
    Friend WithEvents txtMpichFAQ As System.Windows.Forms.TextBox
    Friend WithEvents txtSmpBetaClient As System.Windows.Forms.TextBox
    Friend WithEvents txtSmpBetaThread As System.Windows.Forms.TextBox
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents tpCI As System.Windows.Forms.TabPage
    Friend WithEvents tcSettings As System.Windows.Forms.TabControl
    Friend WithEvents tpSXD As System.Windows.Forms.TabPage
    Public WithEvents gbClient As System.Windows.Forms.GroupBox
    Friend WithEvents chkParameters As System.Windows.Forms.CheckBox
    Friend WithEvents chkDisableCpuAffinityLock As System.Windows.Forms.CheckBox
    Friend WithEvents chkService As System.Windows.Forms.CheckBox
    Friend WithEvents chkWuSize As System.Windows.Forms.CheckBox
    Friend WithEvents chkCpuUsage As System.Windows.Forms.CheckBox
    Friend WithEvents chkDissableAssembly As System.Windows.Forms.CheckBox
    Friend WithEvents chkPauseBattery As System.Windows.Forms.CheckBox
    Friend WithEvents chkAdvancedMethods As System.Windows.Forms.CheckBox
    Friend WithEvents chkInterval As System.Windows.Forms.CheckBox
    Friend WithEvents chkIgnoreLocalDeadline As System.Windows.Forms.CheckBox
    Friend WithEvents chkAskForNetwork As System.Windows.Forms.CheckBox
    Friend WithEvents chkCorePriority As System.Windows.Forms.CheckBox
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents txtParameters As System.Windows.Forms.TextBox
    Friend WithEvents Label76 As System.Windows.Forms.Label
    Friend WithEvents cmbDisableCpuAffinityLock As System.Windows.Forms.ComboBox
    Friend WithEvents Label77 As System.Windows.Forms.Label
    Friend WithEvents cmbAskForNetwork As System.Windows.Forms.ComboBox
    Friend WithEvents cmbIgnoreLocalDeadlines As System.Windows.Forms.ComboBox
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents cmbWuSize As System.Windows.Forms.ComboBox
    Friend WithEvents cmbCorePriority As System.Windows.Forms.ComboBox
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents Label81 As System.Windows.Forms.Label
    Friend WithEvents Label82 As System.Windows.Forms.Label
    Friend WithEvents nudInterval As System.Windows.Forms.NumericUpDown
    Friend WithEvents cmdService As System.Windows.Forms.ComboBox
    Friend WithEvents Label83 As System.Windows.Forms.Label
    Friend WithEvents cmbPauseBattery As System.Windows.Forms.ComboBox
    Friend WithEvents nudCpuUsage As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents cmdAdvancedMethods As System.Windows.Forms.ComboBox
    Friend WithEvents Label86 As System.Windows.Forms.Label
    Friend WithEvents cmbDisableAssembly As System.Windows.Forms.ComboBox
    Friend WithEvents Label87 As System.Windows.Forms.Label
    Friend WithEvents tpSXM As System.Windows.Forms.TabPage
    Friend WithEvents tpSVD As System.Windows.Forms.TabPage
    Friend WithEvents tpSVM As System.Windows.Forms.TabPage
    Friend WithEvents tpGXA As System.Windows.Forms.TabPage
    Friend WithEvents tpGXN As System.Windows.Forms.TabPage
    Friend WithEvents tpGVA As System.Windows.Forms.TabPage
    Friend WithEvents tpGVN As System.Windows.Forms.TabPage
    Friend WithEvents txtSmpBetaVersion As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents tpCPU As System.Windows.Forms.TabPage
    Friend WithEvents txtGpuVistaBetaVersion As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents LinkLabel3 As System.Windows.Forms.LinkLabel
    Friend WithEvents txtGpuVistaBetaClient As System.Windows.Forms.TextBox
    Friend WithEvents txtGpuVistaBetaThread As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents txtGpuXP03BetaVersion As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents txtGpuXP03BetaClient As System.Windows.Forms.TextBox
    Friend WithEvents txtGpuXP03BetaThread As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtGpu2XP03Url As System.Windows.Forms.TextBox
    Friend WithEvents txtGpu2XP03AtiFAQ As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txtGpu2VistaGuide As System.Windows.Forms.TextBox
    Friend WithEvents txtGpu2VistaUrl As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents txtGpu2XP03Guide As System.Windows.Forms.TextBox
    Friend WithEvents txtGpu2XP03NvidiaFAQ As System.Windows.Forms.TextBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents txtGpu2VistaAtiFAQ As System.Windows.Forms.TextBox
    Friend WithEvents txtCpuURL As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtGpu2VistaNvidiaFAQ As System.Windows.Forms.TextBox
    Friend WithEvents txtCpuGuide As System.Windows.Forms.TextBox
    Friend WithEvents txtCpuInstallation As System.Windows.Forms.TextBox
    Friend WithEvents oDiag As System.Windows.Forms.OpenFileDialog
    Friend WithEvents sDiag As System.Windows.Forms.SaveFileDialog
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents rtfExplain As System.Windows.Forms.RichTextBox
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents cmdLoad As System.Windows.Forms.Button
End Class
