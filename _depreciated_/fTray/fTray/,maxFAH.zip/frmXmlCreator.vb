﻿'   fTray client control class
'   Copyright (c) 2010 Marvin Westmaas ( MtM / Marvin_The_Martian )
'
'   This program is free software: you can redistribute it and/or modify
'   it under the terms of the GNU General Public License as published by
'   the Free Software Foundation, either version 3 of the License, or
'   (at your option) any later version.
'
'   This program is distributed in the hope that it will be useful,
'   but WITHOUT ANY WARRANTY; without even the implied warranty of
'   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'   GNU General Public License for more details.
'
'   You should have received a copy of the GNU General Public License
'   along with this program.  If not, see <http://www.gnu.org/licenses/>.
Imports System.Xml
Imports System.IO

Public Class frmXmlCreator
    Private _Loading As Boolean = True
    Private Sub tcSettings_Deselecting(ByVal sender As Object, ByVal e As System.Windows.Forms.TabControlCancelEventArgs) Handles tcSettings.Deselecting
        'Handle object update
        Dim pSettings As New clsClientConfiguration.clsClientConfigs.sPerferdConfig.sSingleClient
        With pSettings
            .AdditionalParameter = txtParameters.Text
            .AdvancedMethods = cmdAdvancedMethods.Text
            .AskNetwork = cmbAskForNetwork.Text
            .CorePriority = cmbCorePriority.Text
            .CpuUsage = nudCpuUsage.Value.ToString
            .DisableAffinityLock = cmbDisableCpuAffinityLock.Text
            .DisableAssembly = cmbDisableAssembly.Text
            .IgnoreLocalDeadlines = cmbIgnoreLocalDeadlines.Text
            .LaunchService = cmdService.Text
            .PauseBattery = cmbPauseBattery.Text
            .WuSize = cmbWuSize.Text
            .CPInterval = nudInterval.Value.ToString
            .LockAdditionalParameters = chkParameters.Checked
            .LockAdvancedMethods = chkAdvancedMethods.Checked
            .LockAskNetwork = chkAskForNetwork.Checked
            .LockCorePriority = chkCorePriority.Checked
            .LockCpuUsage = chkCpuUsage.Checked
            .LockDisableAffinityLock = chkDisableCpuAffinityLock.Checked
            .LockDisableAssembly = chkDissableAssembly.Checked
            .LockIgnoreLocalDeadlines = chkIgnoreLocalDeadline.Checked
            .LockLaunchService = chkService.Checked
            .LockPauseBattery = chkPauseBattery.Checked
            .LockWuSize = chkWuSize.Checked
            .TypeOfClient = tcSettings.SelectedIndex + 1
        End With
        Cfg.CfgManager.PrefferedSettings.AddToPreferred(tcSettings.SelectedIndex + 1, pSettings)
    End Sub
    Public Sub InitGroupbox()
        Dim pSettings As clsClientConfiguration.clsClientConfigs.sPerferdConfig.sSingleClient = Cfg.CfgManager.PrefferedSettings.GetPreffered(clsClientConfiguration.clsClientConfigs.sPerferdConfig.sSingleClient.eClient.SXD)
        Static _Once As Boolean = True
        If _Once Then
            For Each ctrl In gbClient.Controls
                If TypeOf ctrl Is TextBox Then
                    Dim cTxt As TextBox = ctrl
                    cTxt.Text = ""
                ElseIf TypeOf ctrl Is CheckBox Then
                    Dim chk As CheckBox = ctrl
                    chk.Checked = False
                ElseIf TypeOf ctrl Is ComboBox Then
                    Dim cmb As ComboBox = ctrl
                    cmb.Text = cmb.Items(0)
                End If
            Next
            _Once = False
        End If
        If pSettings.TypeOfClient = Nothing Or pSettings.TypeOfClient = clsClientConfiguration.clsClientConfigs.sPerferdConfig.sSingleClient.eClient.Empty Then
            For Each ctrl In gbClient.Controls
                If TypeOf ctrl Is TextBox Then
                    Dim cTxt As TextBox = ctrl
                    cTxt.Text = ""
                ElseIf TypeOf ctrl Is CheckBox Then
                    Dim chk As CheckBox = ctrl
                    chk.Checked = False
                ElseIf TypeOf ctrl Is ComboBox Then
                    Dim cmb As ComboBox = ctrl
                    cmb.Text = cmb.Items(0)
                End If
            Next
            Exit Sub
        Else
            With pSettings
                txtParameters.Text = .AdditionalParameter
                cmdAdvancedMethods.Text = .AdvancedMethods
                cmbAskForNetwork.Text = .AskNetwork
                cmbCorePriority.Text = .CorePriority
                nudCpuUsage.Value = CInt(.CpuUsage)
                cmbDisableCpuAffinityLock.Text = .DisableAffinityLock
                cmbDisableAssembly.Text = .DisableAssembly
                cmbIgnoreLocalDeadlines.Text = .IgnoreLocalDeadlines
                cmdService.Text = .LaunchService
                cmbPauseBattery.Text = .PauseBattery
                cmbWuSize.Text = .WuSize
                chkParameters.Checked = .LockAdditionalParameters
                chkAdvancedMethods.Checked = .LockAdvancedMethods
                chkAskForNetwork.Checked = .LockAskNetwork
                chkCorePriority.Checked = .LockCorePriority
                chkCpuUsage.Checked = .LockCpuUsage
                chkDisableCpuAffinityLock.Checked = .LockDisableAffinityLock
                chkDissableAssembly.Checked = .LockDisableAssembly
                chkIgnoreLocalDeadline.Checked = .LockIgnoreLocalDeadlines
                chkService.Checked = .LockLaunchService
                chkPauseBattery.Checked = .LockPauseBattery
                chkWuSize.Checked = .LockWuSize
            End With
        End If
    End Sub
    Private Sub tcSettings_Selecting(ByVal sender As Object, ByVal e As System.Windows.Forms.TabControlCancelEventArgs) Handles tcSettings.Selecting
        'Deselecting updated client 
        If e.TabPageIndex = -1 Then
            Exit Sub
        End If
        tcSettings.TabPages(e.TabPageIndex).Controls.Add(gbClient)
        Application.DoEvents()
        Dim pSettings As clsClientConfiguration.clsClientConfigs.sPerferdConfig.sSingleClient = Cfg.CfgManager.PrefferedSettings.GetPreffered(e.TabPageIndex + 1)
        If pSettings.TypeOfClient = Nothing Or pSettings.TypeOfClient = clsClientConfiguration.clsClientConfigs.sPerferdConfig.sSingleClient.eClient.Empty Then
            For Each ctrl In gbClient.Controls
                If TypeOf ctrl Is TextBox Then
                    Dim cTxt As TextBox = ctrl
                    cTxt.Text = ""
                ElseIf TypeOf ctrl Is CheckBox Then
                    Dim chk As CheckBox = ctrl
                    chk.Checked = False
                ElseIf TypeOf ctrl Is ComboBox Then
                    Dim cmb As ComboBox = ctrl
                    cmb.Text = cmb.Items(0)
                End If
            Next
            Exit Sub
        Else
            With pSettings
                txtParameters.Text = .AdditionalParameter
                cmdAdvancedMethods.Text = .AdvancedMethods
                cmbAskForNetwork.Text = .AskNetwork
                cmbCorePriority.Text = .AskNetwork
                nudCpuUsage.Value = CInt(.CpuUsage)
                cmbDisableCpuAffinityLock.Text = .DisableAffinityLock
                cmbDisableAssembly.Text = .DisableAssembly
                cmbIgnoreLocalDeadlines.Text = .IgnoreLocalDeadlines
                cmdService.Text = .LaunchService
                cmbPauseBattery.Text = .PauseBattery
                cmbWuSize.Text = .WuSize
                chkParameters.Checked = .LockAdditionalParameters
                chkAdvancedMethods.Checked = .LockAdvancedMethods
                chkAskForNetwork.Checked = .LockAskNetwork
                chkCorePriority.Checked = .LockCorePriority
                chkCpuUsage.Checked = .LockCpuUsage
                chkDisableCpuAffinityLock.Checked = .LockDisableAffinityLock
                chkDissableAssembly.Checked = .LockDisableAssembly
                chkIgnoreLocalDeadline.Checked = .LockIgnoreLocalDeadlines
                chkService.Checked = .LockLaunchService
                chkPauseBattery.Checked = .LockPauseBattery
                chkWuSize.Checked = .LockWuSize
            End With
        End If
    End Sub
    Private Sub frmXmlCreator_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Application.ExitThread()
    End Sub

    Private Sub frmXmlCreator_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        _Loading = False
        Dim pSettings As clsClientConfiguration.clsClientConfigs.sPerferdConfig.sSingleClient = Cfg.CfgManager.PrefferedSettings.GetPreffered(1)
        If pSettings.TypeOfClient = Nothing Or pSettings.TypeOfClient = 0 Then
            For Each ctrl In gbClient.Controls
                If TypeOf ctrl Is TextBox Then
                    Dim cTxt As TextBox = ctrl
                    cTxt.Text = ""
                ElseIf TypeOf ctrl Is CheckBox Then
                    Dim chk As CheckBox = ctrl
                    chk.Checked = False
                ElseIf TypeOf ctrl Is ComboBox Then
                    Dim cmb As ComboBox = ctrl
                    cmb.Text = cmb.Items(0)
                End If
            Next
            Exit Sub
        Else
            With pSettings
                txtParameters.Text = .AdditionalParameter
                cmdAdvancedMethods.Text = .AdvancedMethods
                cmbAskForNetwork.Text = .AskNetwork
                cmbCorePriority.Text = .AskNetwork
                nudCpuUsage.Value = CInt(.CpuUsage)
                cmbDisableCpuAffinityLock.Text = .DisableAffinityLock
                cmbDisableAssembly.Text = .DisableAssembly
                cmbIgnoreLocalDeadlines.Text = .IgnoreLocalDeadlines
                cmdService.Text = .LaunchService
                cmbPauseBattery.Text = .PauseBattery
                cmbWuSize.Text = .WuSize
                chkParameters.Checked = .LockAdditionalParameters
                chkAdvancedMethods.Checked = .LockAdvancedMethods
                chkAskForNetwork.Checked = .LockAskNetwork
                chkCorePriority.Checked = .LockCorePriority
                chkCpuUsage.Checked = .LockCpuUsage
                chkDisableCpuAffinityLock.Checked = .LockDisableAffinityLock
                chkDissableAssembly.Checked = .LockDisableAssembly
                chkIgnoreLocalDeadline.Checked = .LockIgnoreLocalDeadlines
                chkService.Checked = .LockLaunchService
                chkPauseBattery.Checked = .LockPauseBattery
                chkWuSize.Checked = .LockWuSize
            End With
        End If
    End Sub

    Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Try
            If sDiag.ShowDialog Then
                If sDiag.FileName <> "" Then
                    Dim fName As String = sDiag.FileName
                    cmdSave.Enabled = False
                    If Not Cfg.CfgManager.SetupManager.SaveXML(fName, Me) Then
                        MsgBox("Error while writing xml file!")
                    End If
                    cmdSave.Enabled = True
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub cmdLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdLoad.Click
        Try
            If oDiag.ShowDialog Then
                If oDiag.FileName <> "" Then
                    Dim fName As String = oDiag.FileName
                    cmdLoad.Enabled = False
                    If Not Cfg.CfgManager.SetupManager.LoadLocalXML(fName) Then
                        MsgBox("Error while loading xml file!")
                    End If
                    cmdLoad.Enabled = True
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub
End Class