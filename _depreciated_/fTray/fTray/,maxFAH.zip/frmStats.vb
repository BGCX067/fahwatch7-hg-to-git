﻿'   Statistics form
'   Copyright (c) 2010 Marvin Westmaas ( MtM / Marvin_The_Martian )
'
'   This program is free software: you can redistribute it and/or modify
'   it under the terms of the GNU General Public License as published by
'   the Free Software Foundation, either version 3 of the License, or
'   (at your option) any later version.
'
'   This program is distributed in the hope that it will be useful,
'   but WITHOUT ANY WARRANTY; without even the implied warranty of
'   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'   GNU General Public License for more details.
'
'   You should have received a copy of the GNU General Public License
'   along with this program.  If not, see <http://www.gnu.org/licenses/>.
Public Class frmStats

    Private Sub frmStats_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
Entry:
        Dim bFailed As Boolean = False
        Try

        Catch ex As Exception
            If bFailed Then
                LogWindow.WriteError("Creating zedGraph", Err)
                MsgBox("Statistics graphs unavailable, check the debug messages!")
            Else
                LogWindow.WriteLog("Failed to create zedgraph control, trying again..")
                DownloadZEDGraph()
                GoTo Entry
            End If
        End Try
        Try
            For xInt As Int16 = 1 To Clients.Count - 1
                cmbClients.Items.Add(Clients(xInt).GuiController.ShortName)
                Dim alProjects As New ArrayList
                alProjects = Clients(xInt).GuiController.Statistics.AllProjects
                For Each Project As clsStats.clsProject In alProjects
                    cmbProjects.Items.Add(Project.QueuSlot.Project.Project & "(Run " & Project.QueuSlot.Project.Run & " Clone " & Project.QueuSlot.Project.Clone & " Gen " & Project.QueuSlot.Project.Gen & ")")
                Next
            Next
        Catch ex As Exception

        End Try
    End Sub

    Private Sub SplitContainer1_Panel1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles scMain.Panel1.Paint

    End Sub
End Class