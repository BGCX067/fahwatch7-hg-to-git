﻿'   Download file form
'   Copyright (c) 2010 Marvin Westmaas ( MtM / Marvin_The_Martian )
'
'   This program is free software: you can redistribute it and/or modify
'   it under the terms of the GNU General Public License as published by
'   the Free Software Foundation, either version 3 of the License, or
'   (at your option) any later version.
'
'   This program is distributed in the hope that it will be useful,
'   but WITHOUT ANY WARRANTY; without even the implied warranty of
'   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'   GNU General Public License for more details.
'
'   You should have received a copy of the GNU General Public License
'   along with this program.  If not, see <http://www.gnu.org/licenses/>.
Public Class frmDownloadClients
    Private speed As Double
    Private speedTemp As Double


    Public Function download(ByVal sURL As String, ByVal pProgress As ProgressBar, ByVal Filename As String) As Boolean
        'Dim wRemote As System.Net.WebRequest
        Me.Text = "Downloading " & Filename.Replace(Application.StartupPath & "\", "")
        Dim URLReq As Net.HttpWebRequest
        Dim URLRes As Net.HttpWebResponse
        Dim FileStreamer As New IO.FileStream(Filename, IO.FileMode.Create)
        Dim bBuffer(999) As Byte
        Dim iBytesRead As Integer

        'Visualizzo il file che si vuole scaricare
        Application.DoEvents()

        Try

            '(sURL)
            URLReq = System.Net.WebRequest.Create(sURL)
            URLRes = URLReq.GetResponse
            Dim sChunks As IO.Stream = URLReq.GetResponse.GetResponseStream

            'Inizializzo Visualizzatori

            PbarDownload.Value = 0
            PbarDownload.Maximum = URLRes.ContentLength
            tSpeed.Enabled = True

            Do
                iBytesRead = sChunks.Read(bBuffer, 0, 1000)

                'velocità e testo e progressione
                speed += iBytesRead
                lblDownload.Text = "Download " & Format(PbarDownload.Value / 1024, "#,###,###,###0.00") & " Kb from " & Format(PbarDownload.Maximum / 1024, "#,###,###,###0.00") & " kb"
                Application.DoEvents()
                If PbarDownload.Value + iBytesRead <= PbarDownload.Maximum Then
                    PbarDownload.Value += iBytesRead
                Else
                    PbarDownload.Value = PbarDownload.Maximum
                End If

                'scrivo file
                FileStreamer.Write(bBuffer, 0, iBytesRead)
            Loop Until iBytesRead = 0

            'azzero i visualizzatori
            PbarDownload.Value = PbarDownload.Maximum
            bitsec.Text = ""
            speed = 0
            tSpeed.Enabled = False

            'chiudo connessione e file
            sChunks.Close()
            FileStreamer.Close()

            Return True
        Catch
            MsgBox(Err.Description)
            tSpeed.Enabled = False
            Return False
        End Try
    End Function

    Private Sub tspeed_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tSpeed.Tick
        speedTemp = speed / 1000
        speed = 0
        bitsec.Text = Format(speedTemp, "#,###,###,###0.00") & " Kb/sec"
    End Sub

End Class