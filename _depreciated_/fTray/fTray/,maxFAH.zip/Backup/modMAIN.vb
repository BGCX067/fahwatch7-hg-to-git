﻿Imports System.Xml
Imports System.IO
Imports System
Imports ICSharpCode.SharpZipLib.Zip
Imports ICSharpCode.SharpZipLib.Checksums
Imports System.Runtime.InteropServices
Imports Microsoft.VisualBasic
Imports System.Management
Imports Microsoft.Win32
Imports Microsoft.Win32.Registry
Imports IWshRuntimeLibrary

Module modMAIN
#Region "Shortcuts"
    Public Function CreateTray(ByVal TargetLocation As String, ByVal LinkFile As String, ByVal Description As String, Optional ByVal IcoFile As String = "") As Boolean
        Try
            Dim objShell As WshShell
            objShell = New IWshShell_Class
            Dim wshTrayShortcut As WshShortcut = objShell.CreateShortcut(LinkFile)
            'wshShell = New WshShortcut
            With wshTrayShortcut
                .Arguments = "-tray"
                .Description = Description
                .WorkingDirectory = TargetLocation
                If IcoFile = "" Then
                    .IconLocation = TargetLocation & "\maxFAH.exe,0"
                Else
                    .IconLocation = TargetLocation & "\" & IcoFile
                End If

                .TargetPath = TargetLocation & "\maxFAH.exe"
            End With
            wshTrayShortcut.Save()
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function
#End Region
#Region "Forms declarations"
    Public WithEvents fTray As New frmTray
    Public WithEvents formXML As New frmXmlCreator
    Public WithEvents fPrBrowse As New frmProjectBrowser
    Public formDownload As New frmDownloadClients
    Public formHWinfo As New frmHWINFO
    Public fStats As New frmStats
#End Region
#Region "Class declarations"
    Public ProjectInfo As New clsProjectInfo(Application.StartupPath)
    Public LogWindow As New clsLogwindow
    Public hwInfo As New clsHWInfo
    Public WithEvents Cfg As New clsClientConfiguration
    Public mySettings As New clsSettings
    Public Clients() As clsClientConfiguration.clsClientConfigs.sClientSettings.sClient
#End Region
#Region "Load clients from xml"
    Public Sub LoadClients()
        Try
            Static IsDone As Boolean = False
            If IsDone Then Exit Sub
            ReDim Clients(0 To 0)
            If Not My.Computer.FileSystem.DirectoryExists(cPath) Then
                MsgBox("folder not found!")
                Application.Exit()
            Else
                For Each sDir In My.Computer.FileSystem.GetDirectories(cPath)
                    If My.Computer.FileSystem.FileExists(sDir & "\" & Cxml) Then
                        Dim nClient As New clsClientConfiguration.clsClientConfigs.sClientSettings.sClient
                        nClient.GuiController.ClientLocation = sDir
                        nClient = Cfg.CfgManager.ClientSettings.LoadConfig(nClient)
                        If Not nClient.GuiController.TypeOfClient = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eClient.Empty Then
                            nClient.Index = Clients.GetUpperBound(0) + 1
                            ReDim Preserve Clients(0 To Clients.GetUpperBound(0) + 1)
                            Clients(Clients.GetUpperBound(0)) = nClient
                            If nClient.PandeGroup.AdditionalParameters.ToUpper.Contains("-BETATEAM") Then bBetaTeam = True
                        Else
                            MsgBox("Can not read critical file!")
                            Application.Exit()
                        End If
                        If Not Cfg.CfgManager.colTakenHWID.Contains(nClient.PandeGroup.MachineID) Then
                            Cfg.CfgManager.colTakenHWID.Add(nClient.PandeGroup.MachineID, nClient.PandeGroup.MachineID)
                            Clients(Clients.GetUpperBound(0)).GuiController.MyClient = nClient
                        Else
                            MsgBox("Client " & nClient.GuiController.ClientLocation.Replace(cPath & "\", "") & " has a machineID already used by another client, please check configuration!")
                        End If
                    Else
                        MsgBox("Can not locate critical file!")
                        Application.Exit()
                    End If
                    'Exit For
                Next
            End If
            IsDone = True
        Catch ex As Exception
            MsgBox("Critical error while reading client settings")
            Application.Exit()
        End Try
    End Sub
    Sub EntryPoint(Optional ByVal ResetPath As Boolean = False)
        If ResetPath Then
            SetLocations(Application.StartupPath)
            mySettings.bTrayManager = True
        End If
        'Project startup has to get fixed, client manager has to be added ect.
        LogWindow = LogWindow.CreateLog
        LogWindow.WriteLog("Program entry point, loading settings and clients")
        mySettings.GetSettings()
        hwInfo.doWMI(True)

        Try
            LogWindow.WriteLog("Ensuring acces to fah-web-stanford.edu")
            If Not My.Computer.Network.Ping("fah-web.stanford.edu") Then
                LogWindow.WriteLog("-could not ping site, setting unavailable flag.")
                modMAIN.FAHWEB_Failure = DateTime.Now.Subtract(TimeSpan.FromMinutes(10))
            End If
        Catch ex As Exception
            LogWindow.WriteLog("-could not ping site, setting unavailable flag.")
            modMAIN.FAHWEB_Failure = DateTime.Now.Subtract(TimeSpan.FromMinutes(10))
        End Try
        Try
            LogWindow.WriteLog("Ensuring acces to folding.extremeoverclocking.com")
            If Not My.Computer.Network.Ping("extremeoverclocking.com") Then
                LogWindow.WriteLog("-could not ping site, setting unavailable flag.")
                modMAIN.EOC_Net_Failure = DateTime.Now.Subtract(TimeSpan.FromMinutes(10))
            End If
        Catch ex As Exception
            LogWindow.WriteLog("-could not ping site, setting unavailable flag.")
            modMAIN.EOC_Net_Failure = DateTime.Now.Subtract(TimeSpan.FromMinutes(10))
        End Try

        LoadClients()
        fTray.mnuExtend.Checked = mySettings.bExtendGUI

        'Set colomn width to 0
        For Each sCol In fTray.lvC.Columns
            sCol.width = 0
        Next
        fTray.lvC.Columns(1).Width = 10
        fTray.lvC.Columns(2).Width = 300

        'Get all controlled (local) clients!
        Dim bDone As Boolean = False
        Dim lvItem As ListViewItem
        Dim bIconDone As Boolean = False
        For xInd As Integer = 1 To Clients.GetUpperBound(0)
            bDone = False
            bIconDone = False
            If Clients(xInd).GuiController.TypeOfClient < 5 And Not Clients(xInd).GuiController.TypeOfClient = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eClient.CPU Then 'smp
                For Each cProc As Process In Process.GetProcessesByName(smpEXE.Replace(".exe", ""))
                    Try
                        If Clients(xInd).GuiController.ClientEXE.ToUpper = cProc.MainModule.FileName.ToUpper Then
                            
                            Clients(xInd).GuiController.Running = True
                            Clients(xInd).GuiController.cProcess = cProc
                            Clients(xInd).GuiController.ReadQueue(True)
                            lvItem = New ListViewItem
                            With lvItem
                                .Tag = Clients(xInd).GuiController.ClientLocation
                                If Not Clients(xInd).GuiController.Queue.HasError Then
                                    .ImageKey = "GREEN"
                                Else
                                    .ImageKey = "YELLOW"
                                End If
                                .Text = Clients(xInd).GuiController.ClientLocation.Replace(cPath & "\", "")
                                If Clients(xInd).GuiController.Queue.ActiveSlot.Status = "0" Then
                                    .ImageKey = "RED"
                                    .SubItems.Add("Idle", Color.Red, fTray.lvC.BackColor, fTray.lvC.Font)
                                    For yInt As Int16 = 2 To 6
                                        .SubItems.Add("")
                                    Next
                                    .SubItems.Add(Clients(xInd).GuiController.Queue.PointsInUpdate.ToString)
                                    .SubItems.Add(Clients(xInd).GuiController.Queue.EUE_Count.ToString)
                                    .SubItems.Add(Clients(xInd).GuiController.Queue.TotalUploadFailures.ToString)
                                    If Not Clients(xInd).PandeGroup.ServiceMode Then
                                        Clients(xInd).GuiController.IsService = False
                                        If Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Err Then
                                            .SubItems.Add("Err")
                                        ElseIf Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Hidden Then
                                            .SubItems.Add("-hidden-")
                                        ElseIf Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Visible Then
                                            .SubItems.Add("-visible-")
                                        End If
                                    Else
                                        Clients(xInd).GuiController.IsService = True
                                        Clients(xInd).GuiController.AttachToSC()
                                        .SubItems.Add("-service-")
                                    End If
                                Else
                                    If Not Clients(xInd).GuiController.Queue.HasError And Clients(xInd).GuiController.Queue.FullSlots Then
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.ActiveSlot.Project.Project & "(R" & Clients(xInd).GuiController.Queue.ActiveSlot.Project.Run & ", C" & Clients(xInd).GuiController.Queue.ActiveSlot.Project.Gen & ", G" & Clients(xInd).GuiController.Queue.ActiveSlot.Project.Gen & ")")
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.CoreVersion)
                                    Else
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                    End If
                                    If Not Clients(xInd).GuiController.Queue.HasError And Clients(xInd).GuiController.Queue.FullSlots Then
                                        If Clients(xInd).GuiController.Queue.ActiveSlot.Status = "2" Then
                                            .SubItems.Add("Ready")
                                            .ImageKey = "YELLOW"
                                            If mySettings.bClientIcons Then
                                                Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.Err)
                                                bIconDone = True
                                            End If
                                        ElseIf Clients(xInd).GuiController.Queue.ActiveSlot.Status = "4" Then
                                            .SubItems.Add("Downloading")
                                            .ImageKey = "YELLOW"
                                            If mySettings.bClientIcons Then
                                                Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.Err)
                                                bIconDone = True
                                            End If
                                        ElseIf Clients(xInd).GuiController.Queue.ActiveSlot.Status = "0" Then
                                            .SubItems.Add("Idle")
                                            .ImageKey = "Yellow"
                                            If mySettings.bClientIcons Then
                                                Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.Err)
                                                bIconDone = True
                                            End If
                                        Else
                                            If Clients(xInd).GuiController.Queue.Progress >= 0 Then
                                                .SubItems.Add(Clients(xInd).GuiController.Queue.Progress.ToString)
                                            ElseIf Clients(xInd).GuiController.Queue.Progress = -1 Or Clients(xInd).GuiController.Queue.Progress = -2 Then
                                                .SubItems.Add("")
                                            End If
                                        End If
                                    Else
                                        .SubItems.Add("")
                                    End If
                                    If Not Clients(xInd).GuiController.Queue.HasError And Clients(xInd).GuiController.Queue.FullSlots Then
                                        Dim strPPD As String = Clients(xInd).GuiController.Queue.PPD_LastFrame.ToString
                                        If Not strPPD = "0" Then
                                            If InStr(strPPD, ",") <> 0 Then
                                                Dim iDigits As Int16 = strPPD.Length - strPPD.LastIndexOf(",")
                                                For iAddDigits As Int16 = 4 To iDigits Step -1
                                                    strPPD &= "0"
                                                Next
                                            Else
                                                strPPD &= ",0000"
                                            End If
                                            .SubItems.Add(strPPD)
                                        Else
                                            'Look for statistical data 
                                            If Not Clients(xInd).GuiController.Statistics.ActivePRGC.KnownFrames = 0 Then
                                                'Use last frametime
                                                If ProjectInfo.KnownProject(Clients(xInd).GuiController.Queue.ActiveSlot.Project.Project) Then
                                                    strPPD = ProjectInfo.PPD(Clients(xInd).GuiController.Queue.ActiveSlot.Project.Project, Clients(xInd).GuiController.Statistics.ActivePRGC.AverageFrameTime).ToString
                                                    If InStr(strPPD, ",") <> 0 Then
                                                        Dim iDigits As Int16 = strPPD.Length - strPPD.LastIndexOf(",")
                                                        For iAddDigits As Int16 = 4 To iDigits Step -1
                                                            strPPD &= "0"
                                                        Next
                                                    Else
                                                        strPPD &= ",0000"
                                                    End If
                                                    .SubItems.Add(strPPD)
                                                Else
                                                    .SubItems.Add("0,0000")
                                                End If
                                            Else
                                                'Look for reference values
                                                If Clients(xInd).GuiController.Statistics.ActivePRGC.bHasReferenceValues Then
                                                    'Use reference frame time
                                                    strPPD = ProjectInfo.PPD(Clients(xInd).GuiController.Queue.ActiveSlot.Project.Project, Clients(xInd).GuiController.Statistics.ActivePRGC.rv3Frames).ToString
                                                    If InStr(strPPD, ",") <> 0 Then
                                                        Dim iDigits As Int16 = strPPD.Length - strPPD.LastIndexOf(",")
                                                        For iAddDigits As Int16 = 4 To iDigits Step -1
                                                            strPPD &= "0"
                                                        Next
                                                    Else
                                                        strPPD &= ",0000"
                                                    End If
                                                    .SubItems.Add(strPPD)
                                                Else
                                                    'Zero
                                                    .SubItems.Add("0,0000")
                                                End If
                                            End If
                                        End If
                                        strPPD = Clients(xInd).GuiController.Queue.PPD_Effective.ToString
                                        If InStr(strPPD, ",") <> 0 Then
                                            Dim iDigits As Int16 = strPPD.Length - strPPD.LastIndexOf(",")
                                            For iAddDigits As Int16 = 4 To iDigits Step -1
                                                strPPD &= "0"
                                            Next
                                        Else
                                            strPPD &= ",0000"
                                        End If
                                        .SubItems.Add(strPPD)
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.PointsInUpdate.ToString)
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.EUE_Count.ToString)
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.TotalUploadFailures.ToString)
                                    Else
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                    End If
                                    If Not Clients(xInd).PandeGroup.ServiceMode Then
                                        Clients(xInd).GuiController.IsService = False
                                        If Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Err Then
                                            .SubItems.Add("Err")
                                        ElseIf Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Hidden Then
                                            .SubItems.Add("-hidden-")
                                        ElseIf Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Visible Then
                                            .SubItems.Add("-visible-")
                                        End If
                                    Else
                                        Clients(xInd).GuiController.IsService = True
                                        Clients(xInd).GuiController.AttachToSC()
                                        .SubItems.Add("-service-")
                                    End If
                                End If
                            End With
                            lvItem.Tag = Clients(xInd).GuiController.ClientLocation
                            fTray.lvC.Items.Add(lvItem)
                            bDone = True
                            If mySettings.bClientIcons And Not bIconDone Then Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.iRun)
                            Exit For
                        End If
                    Catch ex As Exception
                        If Clients(xInd).PandeGroup.ServiceMode Then
                            Clients(xInd).GuiController.IsService = True
                            Clients(xInd).GuiController.AttachToSC()
                            If Clients(xInd).GuiController.ServiceState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eServiceState.Running Then
                                Clients(xInd).GuiController.Running = True
                            End If
                            Clients(xInd).GuiController.ReadQueue(True)
                            lvItem = New ListViewItem
                            With lvItem
                                .Tag = Clients(xInd).GuiController.ClientLocation
                                If Clients(xInd).GuiController.ServiceState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eServiceState.Err Then
                                    .ImageKey = "RED"
                                    If mySettings.bClientIcons Then Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.Err)
                                ElseIf Clients(xInd).GuiController.ServiceState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eServiceState.Paused Then
                                    .ImageKey = "YELLOW"
                                    If mySettings.bClientIcons Then Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.iPause)
                                ElseIf Clients(xInd).GuiController.ServiceState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eServiceState.Running Then
                                    .ImageKey = "GREEN"
                                    If mySettings.bClientIcons Then Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.iRun)
                                ElseIf Clients(xInd).GuiController.ServiceState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eServiceState.Stopped Then
                                    .ImageKey = "RED"
                                    If mySettings.bClientIcons Then Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.iStop)
                                End If
                                .Text = Clients(xInd).GuiController.ClientLocation.Replace(cPath & "\", "")
                                If Clients(xInd).GuiController.Queue.ActiveSlot.Status = "0" Then
                                    .ImageKey = "RED"
                                    .SubItems.Add("Idle", Color.Red, fTray.lvC.BackColor, fTray.lvC.Font)
                                    For yInt As Int16 = 2 To 6
                                        .SubItems.Add("")
                                    Next
                                    .SubItems.Add(Clients(xInd).GuiController.Queue.PointsInUpdate.ToString)
                                    .SubItems.Add(Clients(xInd).GuiController.Queue.EUE_Count.ToString)
                                    .SubItems.Add(Clients(xInd).GuiController.Queue.TotalUploadFailures.ToString)
                                    If Not Clients(xInd).PandeGroup.ServiceMode Then
                                        Clients(xInd).GuiController.IsService = False
                                        If Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Err Then
                                            .SubItems.Add("Err")
                                        ElseIf Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Hidden Then
                                            .SubItems.Add("-hidden-")
                                        ElseIf Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Visible Then
                                            .SubItems.Add("-visible-")
                                        End If
                                    Else
                                        Clients(xInd).GuiController.IsService = True
                                        Clients(xInd).GuiController.AttachToSC()
                                        .SubItems.Add("-service-")
                                    End If
                                Else
                                    If Not Clients(xInd).GuiController.Queue.HasError And Clients(xInd).GuiController.Queue.FullSlots Then
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.ActiveSlot.Project.Project & "(R" & Clients(xInd).GuiController.Queue.ActiveSlot.Project.Run & ", C" & Clients(xInd).GuiController.Queue.ActiveSlot.Project.Gen & ", G" & Clients(xInd).GuiController.Queue.ActiveSlot.Project.Gen & ")")
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.CoreVersion)
                                    Else
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                    End If
                                    If Not Clients(xInd).GuiController.Queue.HasError And Clients(xInd).GuiController.Queue.FullSlots Then
                                        If Clients(xInd).GuiController.Queue.ActiveSlot.Status = "2" Then
                                            .SubItems.Add("Ready")
                                            .ImageKey = "YELLOW"
                                            If mySettings.bClientIcons Then
                                                Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.Err)
                                                bIconDone = True
                                            End If
                                        ElseIf Clients(xInd).GuiController.Queue.ActiveSlot.Status = "4" Then
                                            .SubItems.Add("Downloading")
                                            .ImageKey = "YELLOW"
                                            If mySettings.bClientIcons Then
                                                Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.Err)
                                                bIconDone = True
                                            End If
                                        ElseIf Clients(xInd).GuiController.Queue.ActiveSlot.Status = "0" Then
                                            .SubItems.Add("Idle")
                                            .ImageKey = "Yellow"
                                            If mySettings.bClientIcons Then
                                                Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.Err)
                                                bIconDone = True
                                            End If
                                        Else
                                            If Clients(xInd).GuiController.Queue.Progress >= 0 Then
                                                .SubItems.Add(Clients(xInd).GuiController.Queue.Progress.ToString)
                                            ElseIf Clients(xInd).GuiController.Queue.Progress = -1 Or Clients(xInd).GuiController.Queue.Progress = -2 Then
                                                .SubItems.Add("")
                                            End If
                                        End If
                                    Else
                                        .SubItems.Add("")
                                    End If
                                    If Not Clients(xInd).GuiController.Queue.HasError And Clients(xInd).GuiController.Queue.FullSlots Then
                                        Dim strPPD As String = Clients(xInd).GuiController.Queue.PPD_LastFrame.ToString
                                        If Not strPPD = "0" Then
                                            If InStr(strPPD, ",") <> 0 Then
                                                Dim iDigits As Int16 = strPPD.Length - strPPD.LastIndexOf(",")
                                                For iAddDigits As Int16 = 4 To iDigits Step -1
                                                    strPPD &= "0"
                                                Next
                                            Else
                                                strPPD &= ",0000"
                                            End If
                                            .SubItems.Add(strPPD)
                                        Else
                                            'Look for statistical data 
                                            If Not Clients(xInd).GuiController.Statistics.ActivePRGC.KnownFrames = 0 Then
                                                'Use last frametime
                                                If ProjectInfo.KnownProject(Clients(xInd).GuiController.Queue.ActiveSlot.Project.Project) Then
                                                    strPPD = ProjectInfo.PPD(Clients(xInd).GuiController.Queue.ActiveSlot.Project.Project, Clients(xInd).GuiController.Statistics.ActivePRGC.AverageFrameTime).ToString
                                                    If InStr(strPPD, ",") <> 0 Then
                                                        Dim iDigits As Int16 = strPPD.Length - strPPD.LastIndexOf(",")
                                                        For iAddDigits As Int16 = 4 To iDigits Step -1
                                                            strPPD &= "0"
                                                        Next
                                                    Else
                                                        strPPD &= ",0000"
                                                    End If
                                                    .SubItems.Add(strPPD)
                                                Else
                                                    .SubItems.Add("0,0000")
                                                End If
                                            Else
                                                'Look for reference values
                                                If Clients(xInd).GuiController.Statistics.ActivePRGC.bHasReferenceValues Then
                                                    'Use reference frame time
                                                    strPPD = ProjectInfo.PPD(Clients(xInd).GuiController.Queue.ActiveSlot.Project.Project, Clients(xInd).GuiController.Statistics.ActivePRGC.rv3Frames).ToString
                                                    If InStr(strPPD, ",") <> 0 Then
                                                        Dim iDigits As Int16 = strPPD.Length - strPPD.LastIndexOf(",")
                                                        For iAddDigits As Int16 = 4 To iDigits Step -1
                                                            strPPD &= "0"
                                                        Next
                                                    Else
                                                        strPPD &= ",0000"
                                                    End If
                                                    .SubItems.Add(strPPD)
                                                Else
                                                    'Zero
                                                    .SubItems.Add("0,0000")
                                                End If
                                            End If
                                        End If
                                        strPPD = Clients(xInd).GuiController.Queue.PPD_Effective.ToString
                                        If InStr(strPPD, ",") <> 0 Then
                                            Dim iDigits As Int16 = strPPD.Length - strPPD.LastIndexOf(",")
                                            For iAddDigits As Int16 = 4 To iDigits Step -1
                                                strPPD &= "0"
                                            Next
                                        Else
                                            strPPD &= ",0000"
                                        End If
                                        .SubItems.Add(strPPD)
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.PointsInUpdate.ToString)
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.EUE_Count.ToString)
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.TotalUploadFailures.ToString)
                                    Else
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                    End If
                                    If Not Clients(xInd).PandeGroup.ServiceMode Then
                                        Clients(xInd).GuiController.IsService = False
                                        If Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Err Then
                                            .SubItems.Add("Err")
                                        ElseIf Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Hidden Then
                                            .SubItems.Add("-hidden-")
                                        ElseIf Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Visible Then
                                            .SubItems.Add("-visible-")
                                        End If
                                    Else
                                        Clients(xInd).GuiController.IsService = True
                                        Clients(xInd).GuiController.AttachToSC()
                                        .SubItems.Add("-service-")
                                    End If
                                End If
                            End With
                            fTray.lvC.Items.Add(lvItem)
                            If mySettings.bClientIcons And Not bIconDone Then Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.iRun)
                            bDone = True
                            Exit For
                        End If
                    End Try
                Next
            ElseIf Clients(xInd).GuiController.TypeOfClient >= 5 And Not Clients(xInd).GuiController.TypeOfClient = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eClient.CPU Then
                For Each cProc As Process In Process.GetProcessesByName(gpuEXE.Replace(".exe", ""))
                    'Get command line arguments with wmi?
                    Try
                        If Clients(xInd).GuiController.ClientEXE.ToUpper = cProc.MainModule.FileName.ToUpper Then
                            
                            Clients(xInd).GuiController.Running = True
                            Clients(xInd).GuiController.cProcess = cProc
                            Clients(xInd).GuiController.ReadQueue(True)
                            lvItem = New ListViewItem
                            With lvItem
                                .Tag = Clients(xInd).GuiController.ClientLocation
                                If Not Clients(xInd).GuiController.Queue.HasError Then
                                    .ImageKey = "GREEN"
                                Else
                                    .ImageKey = "YELLOW"
                                End If
                                .Text = Clients(xInd).GuiController.ClientLocation.Replace(cPath & "\", "")
                                If Clients(xInd).GuiController.Queue.ActiveSlot.Status = "0" Then
                                    .ImageKey = "RED"
                                    .SubItems.Add("Idle", Color.Red, fTray.lvC.BackColor, fTray.lvC.Font)
                                    For yInt As Int16 = 2 To 5
                                        .SubItems.Add("")
                                    Next
                                    .SubItems.Add(Clients(xInd).GuiController.Queue.PointsInUpdate.ToString)
                                    .SubItems.Add(Clients(xInd).GuiController.Queue.EUE_Count.ToString)
                                    .SubItems.Add(Clients(xInd).GuiController.Queue.TotalUploadFailures.ToString)
                                    If Not Clients(xInd).PandeGroup.ServiceMode Then
                                        Clients(xInd).GuiController.IsService = False
                                        If Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Err Then
                                            .SubItems.Add("Err")
                                        ElseIf Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Hidden Then
                                            .SubItems.Add("-hidden-")
                                        ElseIf Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Visible Then
                                            .SubItems.Add("-visible-")
                                        End If
                                    Else
                                        Clients(xInd).GuiController.IsService = True
                                        Clients(xInd).GuiController.AttachToSC()
                                        .SubItems.Add("-service-")
                                    End If
                                Else
                                    If Not Clients(xInd).GuiController.Queue.HasError And Clients(xInd).GuiController.Queue.FullSlots Then
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.ActiveSlot.Project.Project & "(R" & Clients(xInd).GuiController.Queue.ActiveSlot.Project.Run & ", C" & Clients(xInd).GuiController.Queue.ActiveSlot.Project.Gen & ", G" & Clients(xInd).GuiController.Queue.ActiveSlot.Project.Gen & ")")
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.CoreVersion)
                                    Else
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                    End If
                                    If Not Clients(xInd).GuiController.Queue.HasError And Clients(xInd).GuiController.Queue.FullSlots Then
                                        If Clients(xInd).GuiController.Queue.ActiveSlot.Status = "2" Then
                                            .SubItems.Add("Ready")
                                            .ImageKey = "YELLOW"
                                            If mySettings.bClientIcons Then
                                                Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.Err)
                                                bIconDone = True
                                            End If
                                        ElseIf Clients(xInd).GuiController.Queue.ActiveSlot.Status = "4" Then
                                            .SubItems.Add("Downloading")
                                            .ImageKey = "YELLOW"
                                            If mySettings.bClientIcons Then
                                                Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.Err)
                                                bIconDone = True
                                            End If
                                        ElseIf Clients(xInd).GuiController.Queue.ActiveSlot.Status = "0" Then
                                            .SubItems.Add("Idle")
                                            .ImageKey = "Yellow"
                                            If mySettings.bClientIcons Then
                                                Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.Err)
                                                bIconDone = True
                                            End If
                                        Else
                                            If Clients(xInd).GuiController.Queue.Progress >= 0 Then
                                                .SubItems.Add(Clients(xInd).GuiController.Queue.Progress.ToString)
                                            ElseIf Clients(xInd).GuiController.Queue.Progress = -1 Or Clients(xInd).GuiController.Queue.Progress = -2 Then
                                                .SubItems.Add("")
                                            End If
                                        End If
                                    Else
                                        .SubItems.Add("")
                                    End If
                                    If Not Clients(xInd).GuiController.Queue.HasError And Clients(xInd).GuiController.Queue.FullSlots Then
                                        Dim strPPD As String = Clients(xInd).GuiController.Queue.PPD_LastFrame.ToString
                                        If Not strPPD = "0" Then
                                            If InStr(strPPD, ",") <> 0 Then
                                                Dim iDigits As Int16 = strPPD.Length - strPPD.LastIndexOf(",")
                                                For iAddDigits As Int16 = 4 To iDigits Step -1
                                                    strPPD &= "0"
                                                Next
                                            Else
                                                strPPD &= ",0000"
                                            End If
                                            .SubItems.Add(strPPD)
                                        Else
                                            'Look for statistical data 
                                            If Not Clients(xInd).GuiController.Statistics.ActivePRGC.KnownFrames = 0 Then
                                                'Use last frametime
                                                If ProjectInfo.KnownProject(Clients(xInd).GuiController.Queue.ActiveSlot.Project.Project) Then
                                                    strPPD = ProjectInfo.PPD(Clients(xInd).GuiController.Queue.ActiveSlot.Project.Project, Clients(xInd).GuiController.Statistics.ActivePRGC.AverageFrameTime).ToString
                                                    If InStr(strPPD, ",") <> 0 Then
                                                        Dim iDigits As Int16 = strPPD.Length - strPPD.LastIndexOf(",")
                                                        For iAddDigits As Int16 = 4 To iDigits Step -1
                                                            strPPD &= "0"
                                                        Next
                                                    Else
                                                        strPPD &= ",0000"
                                                    End If
                                                    .SubItems.Add(strPPD)
                                                Else
                                                    .SubItems.Add("0,0000")
                                                End If
                                            Else
                                                'Look for reference values
                                                If Clients(xInd).GuiController.Statistics.ActivePRGC.bHasReferenceValues Then
                                                    'Use reference frame time
                                                    strPPD = ProjectInfo.PPD(Clients(xInd).GuiController.Queue.ActiveSlot.Project.Project, Clients(xInd).GuiController.Statistics.ActivePRGC.rv3Frames).ToString
                                                    If InStr(strPPD, ",") <> 0 Then
                                                        Dim iDigits As Int16 = strPPD.Length - strPPD.LastIndexOf(",")
                                                        For iAddDigits As Int16 = 4 To iDigits Step -1
                                                            strPPD &= "0"
                                                        Next
                                                    Else
                                                        strPPD &= ",0000"
                                                    End If
                                                    .SubItems.Add(strPPD)
                                                Else
                                                    'Zero
                                                    .SubItems.Add("0,0000")
                                                End If
                                            End If
                                        End If
                                        strPPD = Clients(xInd).GuiController.Queue.PPD_Effective.ToString
                                        If InStr(strPPD, ",") <> 0 Then
                                            Dim iDigits As Int16 = strPPD.Length - strPPD.LastIndexOf(",")
                                            For iAddDigits As Int16 = 4 To iDigits Step -1
                                                strPPD &= "0"
                                            Next
                                        Else
                                            strPPD &= ",0000"
                                        End If
                                        .SubItems.Add(strPPD)
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.PointsInUpdate.ToString)
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.EUE_Count.ToString)
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.TotalUploadFailures.ToString)
                                    Else
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                    End If
                                    If Not Clients(xInd).PandeGroup.ServiceMode Then
                                        Clients(xInd).GuiController.IsService = False
                                        If Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Err Then
                                            .SubItems.Add("Err")
                                        ElseIf Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Hidden Then
                                            .SubItems.Add("-hidden-")
                                        ElseIf Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Visible Then
                                            .SubItems.Add("-visible-")
                                        End If
                                    Else
                                        Clients(xInd).GuiController.IsService = True
                                        Clients(xInd).GuiController.AttachToSC()
                                        .SubItems.Add("-service-")
                                    End If
                                End If
                            End With
                            lvItem.Tag = Clients(xInd).GuiController.ClientLocation
                            fTray.lvC.Items.Add(lvItem)
                            bDone = True
                            If mySettings.bClientIcons And Not bIconDone Then Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.iRun)
                            Exit For
                        End If
                    Catch ex As Exception
                        If Clients(xInd).PandeGroup.ServiceMode Then
                            Clients(xInd).GuiController.IsService = True
                            Clients(xInd).GuiController.AttachToSC()
                            If Clients(xInd).GuiController.ServiceState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eServiceState.Running Then
                                Clients(xInd).GuiController.Running = True
                            End If
                            Clients(xInd).GuiController.ReadQueue(True)
                            lvItem = New ListViewItem
                            With lvItem
                                .Tag = Clients(xInd).GuiController.ClientLocation
                                If Clients(xInd).GuiController.ServiceState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eServiceState.Err Then
                                    .ImageKey = "RED"
                                    If mySettings.bClientIcons Then Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.Err)
                                ElseIf Clients(xInd).GuiController.ServiceState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eServiceState.Paused Then
                                    .ImageKey = "YELLOW"
                                    If mySettings.bClientIcons Then Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.iPause)
                                ElseIf Clients(xInd).GuiController.ServiceState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eServiceState.Running Then
                                    .ImageKey = "GREEN"
                                    If mySettings.bClientIcons Then Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.iRun)
                                ElseIf Clients(xInd).GuiController.ServiceState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eServiceState.Stopped Then
                                    .ImageKey = "RED"
                                    If mySettings.bClientIcons Then Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.iStop)
                                End If
                                .Text = Clients(xInd).GuiController.ClientLocation.Replace(cPath & "\", "")
                                If Clients(xInd).GuiController.Queue.ActiveSlot.Status = "0" Then
                                    .ImageKey = "RED"
                                    .SubItems.Add("Idle", Color.Red, fTray.lvC.BackColor, fTray.lvC.Font)
                                    For yInt As Int16 = 2 To 5
                                        .SubItems.Add("")
                                    Next
                                    .SubItems.Add(Clients(xInd).GuiController.Queue.PointsInUpdate.ToString)
                                    .SubItems.Add(Clients(xInd).GuiController.Queue.EUE_Count.ToString)
                                    .SubItems.Add(Clients(xInd).GuiController.Queue.TotalUploadFailures.ToString)
                                    If Not Clients(xInd).PandeGroup.ServiceMode Then
                                        Clients(xInd).GuiController.IsService = False
                                        If Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Err Then
                                            .SubItems.Add("Err")
                                        ElseIf Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Hidden Then
                                            .SubItems.Add("-hidden-")
                                        ElseIf Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Visible Then
                                            .SubItems.Add("-visible-")
                                        End If
                                    Else
                                        Clients(xInd).GuiController.IsService = True
                                        Clients(xInd).GuiController.AttachToSC()
                                        .SubItems.Add("-service-")
                                    End If
                                Else
                                    If Not Clients(xInd).GuiController.Queue.HasError And Clients(xInd).GuiController.Queue.FullSlots Then
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.ActiveSlot.Project.Project & "(R" & Clients(xInd).GuiController.Queue.ActiveSlot.Project.Run & ", C" & Clients(xInd).GuiController.Queue.ActiveSlot.Project.Gen & ", G" & Clients(xInd).GuiController.Queue.ActiveSlot.Project.Gen & ")")
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.CoreVersion)
                                    Else
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                    End If
                                    If Not Clients(xInd).GuiController.Queue.HasError And Clients(xInd).GuiController.Queue.FullSlots Then
                                        If Clients(xInd).GuiController.Queue.ActiveSlot.Status = "2" Then
                                            .SubItems.Add("Ready")
                                            .ImageKey = "YELLOW"
                                            If mySettings.bClientIcons Then
                                                Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.Err)
                                                bIconDone = True
                                            End If
                                        ElseIf Clients(xInd).GuiController.Queue.ActiveSlot.Status = "4" Then
                                            .SubItems.Add("Downloading")
                                            .ImageKey = "YELLOW"
                                            If mySettings.bClientIcons Then
                                                Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.Err)
                                                bIconDone = True
                                            End If
                                        ElseIf Clients(xInd).GuiController.Queue.ActiveSlot.Status = "0" Then
                                            .SubItems.Add("Idle")
                                            .ImageKey = "Yellow"
                                            If mySettings.bClientIcons Then
                                                Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.Err)
                                                bIconDone = True
                                            End If
                                        Else
                                            If Clients(xInd).GuiController.Queue.Progress >= 0 Then
                                                .SubItems.Add(Clients(xInd).GuiController.Queue.Progress.ToString)
                                            ElseIf Clients(xInd).GuiController.Queue.Progress = -1 Or Clients(xInd).GuiController.Queue.Progress = -2 Then
                                                .SubItems.Add("")
                                            End If
                                        End If
                                    Else
                                        .SubItems.Add("")
                                    End If
                                    If Not Clients(xInd).GuiController.Queue.HasError And Clients(xInd).GuiController.Queue.FullSlots Then
                                        Dim strPPD As String = Clients(xInd).GuiController.Queue.PPD_LastFrame.ToString
                                        If Not strPPD = "0" Then
                                            If InStr(strPPD, ",") <> 0 Then
                                                Dim iDigits As Int16 = strPPD.Length - strPPD.LastIndexOf(",")
                                                For iAddDigits As Int16 = 4 To iDigits Step -1
                                                    strPPD &= "0"
                                                Next
                                            Else
                                                strPPD &= ",0000"
                                            End If
                                            .SubItems.Add(strPPD)
                                        Else
                                            'Look for statistical data 
                                            If Not Clients(xInd).GuiController.Statistics.ActivePRGC.KnownFrames = 0 Then
                                                'Use last frametime
                                                If ProjectInfo.KnownProject(Clients(xInd).GuiController.Queue.ActiveSlot.Project.Project) Then
                                                    strPPD = ProjectInfo.PPD(Clients(xInd).GuiController.Queue.ActiveSlot.Project.Project, Clients(xInd).GuiController.Statistics.ActivePRGC.AverageFrameTime).ToString
                                                    If InStr(strPPD, ",") <> 0 Then
                                                        Dim iDigits As Int16 = strPPD.Length - strPPD.LastIndexOf(",")
                                                        For iAddDigits As Int16 = 4 To iDigits Step -1
                                                            strPPD &= "0"
                                                        Next
                                                    Else
                                                        strPPD &= ",0000"
                                                    End If
                                                    .SubItems.Add(strPPD)
                                                Else
                                                    .SubItems.Add("0,0000")
                                                End If
                                            Else
                                                'Look for reference values
                                                If Clients(xInd).GuiController.Statistics.ActivePRGC.bHasReferenceValues Then
                                                    'Use reference frame time
                                                    strPPD = ProjectInfo.PPD(Clients(xInd).GuiController.Queue.ActiveSlot.Project.Project, Clients(xInd).GuiController.Statistics.ActivePRGC.rv3Frames).ToString
                                                    If InStr(strPPD, ",") <> 0 Then
                                                        Dim iDigits As Int16 = strPPD.Length - strPPD.LastIndexOf(",")
                                                        For iAddDigits As Int16 = 4 To iDigits Step -1
                                                            strPPD &= "0"
                                                        Next
                                                    Else
                                                        strPPD &= ",0000"
                                                    End If
                                                    .SubItems.Add(strPPD)
                                                Else
                                                    'Zero
                                                    .SubItems.Add("0,0000")
                                                End If
                                            End If
                                        End If
                                        strPPD = Clients(xInd).GuiController.Queue.PPD_Effective.ToString
                                        If InStr(strPPD, ",") <> 0 Then
                                            Dim iDigits As Int16 = strPPD.Length - strPPD.LastIndexOf(",")
                                            For iAddDigits As Int16 = 4 To iDigits Step -1
                                                strPPD &= "0"
                                            Next
                                        Else
                                            strPPD &= ",0000"
                                        End If
                                        .SubItems.Add(strPPD)
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.PointsInUpdate.ToString)
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.EUE_Count.ToString)
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.TotalUploadFailures.ToString)
                                    Else
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                    End If
                                    If Not Clients(xInd).PandeGroup.ServiceMode Then
                                        Clients(xInd).GuiController.IsService = False
                                        If Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Err Then
                                            .SubItems.Add("Err")
                                        ElseIf Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Hidden Then
                                            .SubItems.Add("-hidden-")
                                        ElseIf Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Visible Then
                                            .SubItems.Add("-visible-")
                                        End If
                                    Else
                                        Clients(xInd).GuiController.IsService = True
                                        Clients(xInd).GuiController.AttachToSC()
                                        .SubItems.Add("-service-")
                                    End If
                                End If
                            End With
                            fTray.lvC.Items.Add(lvItem)
                            If mySettings.bClientIcons And Not bIconDone Then Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.iRun)
                            bDone = True
                            Exit For
                        End If
                    End Try
                Next
            ElseIf Clients(xInd).GuiController.TypeOfClient = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eClient.CPU Then
                For Each cProc As Process In Process.GetProcessesByName(cpuEXE.Replace(".exe", ""))
                    Try
                        If Clients(xInd).GuiController.ClientEXE.ToUpper = cProc.MainModule.FileName.ToUpper Then
                            
                            Clients(xInd).GuiController.Running = True
                            Clients(xInd).GuiController.cProcess = cProc
                            Clients(xInd).GuiController.ReadQueue(True)
                            lvItem = New ListViewItem
                            With lvItem
                                .Tag = Clients(xInd).GuiController.ClientLocation
                                If Not Clients(xInd).GuiController.Queue.HasError Then
                                    .ImageKey = "GREEN"
                                Else
                                    .ImageKey = "YELLOW"
                                End If
                                .Text = Clients(xInd).GuiController.ClientLocation.Replace(cPath & "\", "")
                                If Clients(xInd).GuiController.Queue.ActiveSlot.Status = "0" Then
                                    .ImageKey = "RED"
                                    .SubItems.Add("Idle", Color.Red, fTray.lvC.BackColor, fTray.lvC.Font)
                                    For yInt As Int16 = 2 To 5
                                        .SubItems.Add("")
                                    Next
                                    .SubItems.Add(Clients(xInd).GuiController.Queue.PointsInUpdate.ToString)
                                    .SubItems.Add(Clients(xInd).GuiController.Queue.EUE_Count.ToString)
                                    .SubItems.Add(Clients(xInd).GuiController.Queue.TotalUploadFailures.ToString)
                                    If Not Clients(xInd).PandeGroup.ServiceMode Then
                                        Clients(xInd).GuiController.IsService = False
                                        If Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Err Then
                                            .SubItems.Add("Err")
                                        ElseIf Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Hidden Then
                                            .SubItems.Add("-hidden-")
                                        ElseIf Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Visible Then
                                            .SubItems.Add("-visible-")
                                        End If
                                    Else
                                        Clients(xInd).GuiController.IsService = True
                                        Clients(xInd).GuiController.AttachToSC()
                                        .SubItems.Add("-service-")
                                    End If
                                Else
                                    If Not Clients(xInd).GuiController.Queue.HasError And Clients(xInd).GuiController.Queue.FullSlots Then
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.ActiveSlot.Project.Project & "(R" & Clients(xInd).GuiController.Queue.ActiveSlot.Project.Run & ", C" & Clients(xInd).GuiController.Queue.ActiveSlot.Project.Gen & ", G" & Clients(xInd).GuiController.Queue.ActiveSlot.Project.Gen & ")")
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.CoreVersion)
                                    Else
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                    End If
                                    If Not Clients(xInd).GuiController.Queue.HasError And Clients(xInd).GuiController.Queue.FullSlots Then
                                        If Clients(xInd).GuiController.Queue.ActiveSlot.Status = "2" Then
                                            .SubItems.Add("Ready")
                                            .ImageKey = "YELLOW"
                                            If mySettings.bClientIcons Then
                                                Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.Err)
                                                bIconDone = True
                                            End If
                                        ElseIf Clients(xInd).GuiController.Queue.ActiveSlot.Status = "4" Then
                                            .SubItems.Add("Downloading")
                                            .ImageKey = "YELLOW"
                                            If mySettings.bClientIcons Then
                                                Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.Err)
                                                bIconDone = True
                                            End If
                                        ElseIf Clients(xInd).GuiController.Queue.ActiveSlot.Status = "0" Then
                                            .SubItems.Add("Idle")
                                            .ImageKey = "Yellow"
                                            If mySettings.bClientIcons Then
                                                Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.Err)
                                                bIconDone = True
                                            End If
                                        Else
                                            If Clients(xInd).GuiController.Queue.Progress >= 0 Then
                                                .SubItems.Add(Clients(xInd).GuiController.Queue.Progress.ToString)
                                            ElseIf Clients(xInd).GuiController.Queue.Progress = -1 Or Clients(xInd).GuiController.Queue.Progress = -2 Then
                                                .SubItems.Add("")
                                            End If
                                        End If
                                    Else
                                        .SubItems.Add("")
                                    End If
                                    If Not Clients(xInd).GuiController.Queue.HasError And Clients(xInd).GuiController.Queue.FullSlots Then
                                        Dim strPPD As String = Clients(xInd).GuiController.Queue.PPD_LastFrame.ToString
                                        If Not strPPD = "0" Then
                                            If InStr(strPPD, ",") <> 0 Then
                                                Dim iDigits As Int16 = strPPD.Length - strPPD.LastIndexOf(",")
                                                For iAddDigits As Int16 = 4 To iDigits Step -1
                                                    strPPD &= "0"
                                                Next
                                            Else
                                                strPPD &= ",0000"
                                            End If
                                            .SubItems.Add(strPPD)
                                        Else
                                            'Look for statistical data 
                                            If Not Clients(xInd).GuiController.Statistics.ActivePRGC.KnownFrames = 0 Then
                                                'Use last frametime
                                                If ProjectInfo.KnownProject(Clients(xInd).GuiController.Queue.ActiveSlot.Project.Project) Then
                                                    strPPD = ProjectInfo.PPD(Clients(xInd).GuiController.Queue.ActiveSlot.Project.Project, Clients(xInd).GuiController.Statistics.ActivePRGC.AverageFrameTime).ToString
                                                    If InStr(strPPD, ",") <> 0 Then
                                                        Dim iDigits As Int16 = strPPD.Length - strPPD.LastIndexOf(",")
                                                        For iAddDigits As Int16 = 4 To iDigits Step -1
                                                            strPPD &= "0"
                                                        Next
                                                    Else
                                                        strPPD &= ",0000"
                                                    End If
                                                    .SubItems.Add(strPPD)
                                                Else
                                                    .SubItems.Add("0,0000")
                                                End If
                                            Else
                                                'Look for reference values
                                                If Clients(xInd).GuiController.Statistics.ActivePRGC.bHasReferenceValues Then
                                                    'Use reference frame time
                                                    strPPD = ProjectInfo.PPD(Clients(xInd).GuiController.Queue.ActiveSlot.Project.Project, Clients(xInd).GuiController.Statistics.ActivePRGC.rv3Frames).ToString
                                                    If InStr(strPPD, ",") <> 0 Then
                                                        Dim iDigits As Int16 = strPPD.Length - strPPD.LastIndexOf(",")
                                                        For iAddDigits As Int16 = 4 To iDigits Step -1
                                                            strPPD &= "0"
                                                        Next
                                                    Else
                                                        strPPD &= ",0000"
                                                    End If
                                                    .SubItems.Add(strPPD)
                                                Else
                                                    'Zero
                                                    .SubItems.Add("0,0000")
                                                End If
                                            End If
                                        End If
                                        strPPD = Clients(xInd).GuiController.Queue.PPD_Effective.ToString
                                        If InStr(strPPD, ",") <> 0 Then
                                            Dim iDigits As Int16 = strPPD.Length - strPPD.LastIndexOf(",")
                                            For iAddDigits As Int16 = 4 To iDigits Step -1
                                                strPPD &= "0"
                                            Next
                                        Else
                                            strPPD &= ",0000"
                                        End If
                                        .SubItems.Add(strPPD)
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.PointsInUpdate.ToString)
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.EUE_Count.ToString)
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.TotalUploadFailures.ToString)
                                    Else
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                    End If
                                    If Not Clients(xInd).PandeGroup.ServiceMode Then
                                        Clients(xInd).GuiController.IsService = False
                                        If Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Err Then
                                            .SubItems.Add("Err")
                                        ElseIf Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Hidden Then
                                            .SubItems.Add("-hidden-")
                                        ElseIf Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Visible Then
                                            .SubItems.Add("-visible-")
                                        End If
                                    Else
                                        Clients(xInd).GuiController.IsService = True
                                        Clients(xInd).GuiController.AttachToSC()
                                        .SubItems.Add("-service-")
                                    End If
                                End If
                            End With
                            lvItem.Tag = Clients(xInd).GuiController.ClientLocation
                            fTray.lvC.Items.Add(lvItem)
                            bDone = True
                            If mySettings.bClientIcons And Not bIconDone Then Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.iRun)
                            Exit For
                        End If
                    Catch ex As Exception
                        If Clients(xInd).PandeGroup.ServiceMode Then
                            Clients(xInd).GuiController.IsService = True
                            Clients(xInd).GuiController.AttachToSC()
                            If Clients(xInd).GuiController.ServiceState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eServiceState.Running Then
                                Clients(xInd).GuiController.Running = True
                            End If
                            Clients(xInd).GuiController.ReadQueue(True)
                            lvItem = New ListViewItem
                            With lvItem
                                .Tag = Clients(xInd).GuiController.ClientLocation
                                If Clients(xInd).GuiController.ServiceState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eServiceState.Err Then
                                    .ImageKey = "RED"
                                    If mySettings.bClientIcons Then Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.Err)
                                ElseIf Clients(xInd).GuiController.ServiceState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eServiceState.Paused Then
                                    .ImageKey = "YELLOW"
                                    If mySettings.bClientIcons Then Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.iPause)
                                ElseIf Clients(xInd).GuiController.ServiceState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eServiceState.Running Then
                                    .ImageKey = "GREEN"
                                    If mySettings.bClientIcons Then Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.iRun)
                                ElseIf Clients(xInd).GuiController.ServiceState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eServiceState.Stopped Then
                                    .ImageKey = "RED"
                                    If mySettings.bClientIcons Then Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.iStop)
                                End If
                                .Text = Clients(xInd).GuiController.ClientLocation.Replace(cPath & "\", "")
                                If Clients(xInd).GuiController.Queue.ActiveSlot.Status = "0" Then
                                    .ImageKey = "RED"
                                    .SubItems.Add("Idle", Color.Red, fTray.lvC.BackColor, fTray.lvC.Font)
                                    For yInt As Int16 = 2 To 5
                                        .SubItems.Add("")
                                    Next
                                    .SubItems.Add(Clients(xInd).GuiController.Queue.PointsInUpdate.ToString)
                                    .SubItems.Add(Clients(xInd).GuiController.Queue.EUE_Count.ToString)
                                    .SubItems.Add(Clients(xInd).GuiController.Queue.TotalUploadFailures.ToString)
                                    If Not Clients(xInd).PandeGroup.ServiceMode Then
                                        Clients(xInd).GuiController.IsService = False
                                        If Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Err Then
                                            .SubItems.Add("Err")
                                        ElseIf Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Hidden Then
                                            .SubItems.Add("-hidden-")
                                        ElseIf Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Visible Then
                                            .SubItems.Add("-visible-")
                                        End If
                                    Else
                                        Clients(xInd).GuiController.IsService = True
                                        Clients(xInd).GuiController.AttachToSC()
                                        .SubItems.Add("-service-")
                                    End If
                                Else
                                    If Not Clients(xInd).GuiController.Queue.HasError And Clients(xInd).GuiController.Queue.FullSlots Then
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.ActiveSlot.Project.Project & "(R" & Clients(xInd).GuiController.Queue.ActiveSlot.Project.Run & ", C" & Clients(xInd).GuiController.Queue.ActiveSlot.Project.Gen & ", G" & Clients(xInd).GuiController.Queue.ActiveSlot.Project.Gen & ")")
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.CoreVersion)
                                    Else
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                    End If
                                    If Not Clients(xInd).GuiController.Queue.HasError And Clients(xInd).GuiController.Queue.FullSlots Then
                                        If Clients(xInd).GuiController.Queue.ActiveSlot.Status = "2" Then
                                            .SubItems.Add("Ready")
                                            .ImageKey = "YELLOW"
                                            If mySettings.bClientIcons Then
                                                Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.Err)
                                                bIconDone = True
                                            End If
                                        ElseIf Clients(xInd).GuiController.Queue.ActiveSlot.Status = "4" Then
                                            .SubItems.Add("Downloading")
                                            .ImageKey = "YELLOW"
                                            If mySettings.bClientIcons Then
                                                Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.Err)
                                                bIconDone = True
                                            End If
                                        ElseIf Clients(xInd).GuiController.Queue.ActiveSlot.Status = "0" Then
                                            .SubItems.Add("Idle")
                                            .ImageKey = "Yellow"
                                            If mySettings.bClientIcons Then
                                                Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.Err)
                                                bIconDone = True
                                            End If
                                        Else
                                            If Clients(xInd).GuiController.Queue.Progress >= 0 Then
                                                .SubItems.Add(Clients(xInd).GuiController.Queue.Progress.ToString)
                                            ElseIf Clients(xInd).GuiController.Queue.Progress = -1 Or Clients(xInd).GuiController.Queue.Progress = -2 Then
                                                .SubItems.Add("")
                                            End If
                                        End If
                                    Else
                                        .SubItems.Add("")
                                    End If
                                    If Not Clients(xInd).GuiController.Queue.HasError And Clients(xInd).GuiController.Queue.FullSlots Then
                                        Dim strPPD As String = Clients(xInd).GuiController.Queue.PPD_LastFrame.ToString
                                        If Not strPPD = "0" Then
                                            If InStr(strPPD, ",") <> 0 Then
                                                Dim iDigits As Int16 = strPPD.Length - strPPD.LastIndexOf(",")
                                                For iAddDigits As Int16 = 4 To iDigits Step -1
                                                    strPPD &= "0"
                                                Next
                                            Else
                                                strPPD &= ",0000"
                                            End If
                                            .SubItems.Add(strPPD)
                                        Else
                                            'Look for statistical data 
                                            If Not Clients(xInd).GuiController.Statistics.ActivePRGC.KnownFrames = 0 Then
                                                'Use last frametime
                                                If ProjectInfo.KnownProject(Clients(xInd).GuiController.Queue.ActiveSlot.Project.Project) Then
                                                    strPPD = ProjectInfo.PPD(Clients(xInd).GuiController.Queue.ActiveSlot.Project.Project, Clients(xInd).GuiController.Statistics.ActivePRGC.AverageFrameTime).ToString
                                                    If InStr(strPPD, ",") <> 0 Then
                                                        Dim iDigits As Int16 = strPPD.Length - strPPD.LastIndexOf(",")
                                                        For iAddDigits As Int16 = 4 To iDigits Step -1
                                                            strPPD &= "0"
                                                        Next
                                                    Else
                                                        strPPD &= ",0000"
                                                    End If
                                                    .SubItems.Add(strPPD)
                                                Else
                                                    .SubItems.Add("0,0000")
                                                End If
                                            Else
                                                'Look for reference values
                                                If Clients(xInd).GuiController.Statistics.ActivePRGC.bHasReferenceValues Then
                                                    'Use reference frame time
                                                    strPPD = ProjectInfo.PPD(Clients(xInd).GuiController.Queue.ActiveSlot.Project.Project, Clients(xInd).GuiController.Statistics.ActivePRGC.rv3Frames).ToString
                                                    If InStr(strPPD, ",") <> 0 Then
                                                        Dim iDigits As Int16 = strPPD.Length - strPPD.LastIndexOf(",")
                                                        For iAddDigits As Int16 = 4 To iDigits Step -1
                                                            strPPD &= "0"
                                                        Next
                                                    Else
                                                        strPPD &= ",0000"
                                                    End If
                                                    .SubItems.Add(strPPD)
                                                Else
                                                    'Zero
                                                    .SubItems.Add("0,0000")
                                                End If
                                            End If
                                        End If
                                        strPPD = Clients(xInd).GuiController.Queue.PPD_Effective.ToString
                                        If InStr(strPPD, ",") <> 0 Then
                                            Dim iDigits As Int16 = strPPD.Length - strPPD.LastIndexOf(",")
                                            For iAddDigits As Int16 = 4 To iDigits Step -1
                                                strPPD &= "0"
                                            Next
                                        Else
                                            strPPD &= ",0000"
                                        End If
                                        .SubItems.Add(strPPD)
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.PointsInUpdate.ToString)
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.EUE_Count.ToString)
                                        .SubItems.Add(Clients(xInd).GuiController.Queue.TotalUploadFailures.ToString)
                                    Else
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                        .SubItems.Add("")
                                    End If
                                    If Not Clients(xInd).PandeGroup.ServiceMode Then
                                        Clients(xInd).GuiController.IsService = False
                                        If Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Err Then
                                            .SubItems.Add("Err")
                                        ElseIf Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Hidden Then
                                            .SubItems.Add("-hidden-")
                                        ElseIf Clients(xInd).GuiController.wState = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eWindowState.Visible Then
                                            .SubItems.Add("-visible-")
                                        End If
                                    Else
                                        Clients(xInd).GuiController.IsService = True
                                        Clients(xInd).GuiController.AttachToSC()
                                        .SubItems.Add("-service-")
                                    End If
                                End If
                            End With
                            fTray.lvC.Items.Add(lvItem)
                            bDone = True
                            If mySettings.bClientIcons And Not bIconDone Then Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.iRun)
                            Exit For
                        End If
                    End Try
                Next
            End If
            If Not bDone Then
                Clients(xInd).GuiController.Running = False
                Clients(xInd).GuiController.ReadQueue()
                lvItem = New ListViewItem
                With lvItem
                    .Text = Clients(xInd).GuiController.ClientLocation.Replace(cPath & "\", "")
                    .SubItems.Add("")
                    .SubItems.Add("")
                    .SubItems.Add("")
                    .SubItems.Add("")
                    .SubItems.Add("")
                    .SubItems.Add(Clients(xInd).GuiController.Queue.PointsInUpdate.ToString)
                    .SubItems.Add(Clients(xInd).GuiController.Queue.EUE_Count.ToString)
                    .SubItems.Add(Clients(xInd).GuiController.Queue.WUs_Ready.ToString)
                    .SubItems.Add("")
                End With
                lvItem.Tag = Clients(xInd).GuiController.ClientLocation
                lvItem.ImageKey = "RED"
                fTray.lvC.Items.Add(lvItem)
                If mySettings.bClientIcons Then Clients(xInd).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.iStop)
            End If
        Next
        Dim iTPPD As Double = 0, iEPPD As Double = 0
        Try
            For xInd As Int16 = 0 To fTray.lvC.Items.Count - 1
                If fTray.lvC.Items(xInd).SubItems(4).Text <> "" Then iTPPD += CDbl(fTray.lvC.Items(xInd).SubItems(4).Text)
                If fTray.lvC.Items(xInd).SubItems(5).Text <> "" Then iEPPD += CDbl(fTray.lvC.Items(xInd).SubItems(5).Text)
            Next
            Math.Round(iTPPD, 4)
            Math.Round(iEPPD, 4)
            fTray.tsTotalPPD.Text = iTPPD.ToString & " (" & iEPPD.ToString & ")"
        Catch ex As Exception
        End Try
        fTray.tsTime.Text = DateTime.Now.ToShortDateString & " " & DateTime.Now.ToLongTimeString
        'Get min sizes
        fTray.lvC.Dock = DockStyle.None
        fTray.lvC.Width = 10
        fTray.lvC.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize)
        For xInd As Int16 = 0 To fTray.lvC.Columns.Count - 1
            mySettings.HeaderWidth(xInd) = fTray.lvC.Columns(xInd).Width
        Next
        fTray.lvC.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent)
        'if content is smaller then header, then resize that collum back
        For xInd As Int16 = 0 To fTray.lvC.Columns.Count - 1
            If fTray.lvC.Columns(xInd).Width < mySettings.HeaderWidth(xInd) Then fTray.lvC.AutoResizeColumn(xInd, ColumnHeaderAutoResizeStyle.HeaderSize)
        Next
        'Minimum size for client, workunit and core columns
        If fTray.lvC.Columns(0).Width < 150 Then fTray.lvC.Columns(0).Width = 150
        If fTray.lvC.Columns(1).Width < 150 Then fTray.lvC.Columns(1).Width = 150
        If fTray.lvC.Columns(2).Width < 150 Then fTray.lvC.Columns(2).Width = 150
        fTray.lvC.Dock = DockStyle.Fill
        'ppd collum min size??
        'fTray.lvC.Columns(4).Width = 80
    End Sub
#End Region
#Region "Global functions"
    Public Sub WaitMS(ByVal Miliseconds As Long)
        Dim tStart As DateTime = DateTime.Now
        Dim tEnd As DateTime = tStart.AddMilliseconds(Miliseconds)
        While DateTime.Now < tEnd
            Application.DoEvents()
        End While
    End Sub
    Public ReadOnly Property ActiveTimeBias() As Long  'Return minutes from 
        Get
            Try
                Dim rKey As Microsoft.Win32.RegistryKey = Registry.LocalMachine.OpenSubKey("SYSTEM\CurrentControlSet\Control\TimeZoneInformation")
                Dim sVal As Long = rKey.GetValue("ActiveTimeBias")
                Return sVal
            Catch ex As Exception
                Return Long.MinValue
            End Try
        End Get
    End Property
    Public Function ConvertUTC_Local(ByVal UtcTime As DateTime) As DateTime
        Try
            Dim nVal As DateTime = DateTime.UtcNow
            DateTime.TryParse(UtcTime.ToLongDateString & " " & UtcTime.ToLongTimeString, nVal)
            Return nVal.ToLocalTime
        Catch ex As Exception
            Return DateTime.MinValue
        End Try
    End Function
    Public Function ConvertLocal_Utc(ByVal LocalTime As DateTime) As DateTime
        Try
            Dim nTime As DateTime = DateTime.Now
            DateTime.TryParse(LocalTime.ToLongDateString & " " & LocalTime.ToLongTimeString, nTime)
            Return nTime.ToUniversalTime
        Catch ex As Exception
            Return DateTime.MinValue
        End Try
    End Function
#End Region
#Region "Zip"
    Public Sub unzip(ByVal filename As String, ByVal targetdir As String, ByVal overwrite As Boolean, Optional ByVal password As String = "")
        Try
            Dim inputStrm As New ZipInputStream(System.IO.File.OpenRead(filename))
            inputStrm.Password = password
            Dim nextEntry As ZipEntry = inputStrm.GetNextEntry()
            While Not nextEntry Is Nothing
                If Not nextEntry.Name.LastIndexOf("/") = nextEntry.Name.Length - 1 Then
                    If nextEntry.Name.IndexOf("/") > 0 Then
                        If Not Directory.Exists(targetdir & "\" & nextEntry.Name.Replace("/", "\").Substring(0, nextEntry.Name.Replace("/", "\").LastIndexOf("\"))) Then
                            Directory.CreateDirectory(targetdir & "\" & nextEntry.Name.Replace("/", "\").Substring(0, nextEntry.Name.Replace("/", "\").LastIndexOf("\")))
                        End If
                    End If
                    Dim tmpStrm As FileStream
                    Dim tmpBuffer(2048) As Byte
                    Dim tmpLength As Integer = -1
                    If overwrite = True Then
                        tmpStrm = New FileStream(Path.Combine(targetdir, nextEntry.Name), FileMode.Create)
                    Else
                        tmpStrm = New FileStream(Path.Combine(targetdir, nextEntry.Name), FileMode.CreateNew)
                    End If

                    While True
                        tmpLength = inputStrm.Read(tmpBuffer, 0, tmpBuffer.Length)
                        If tmpLength > 0 Then
                            tmpStrm.Write(tmpBuffer, 0, tmpLength)
                        Else
                            Exit While
                        End If
                    End While
                    tmpStrm.Flush()
                    tmpStrm.Close()
                    nextEntry = inputStrm.GetNextEntry()
                Else
                    Directory.CreateDirectory(targetdir & "\" & nextEntry.Name.Replace("/", "\"))
                    nextEntry = inputStrm.GetNextEntry()
                End If
            End While
        Catch ex As Exception
            Debug.Print(ex.Message)
        End Try
    End Sub
#End Region
#Region "Download dependancies"
    Public Function DownloadZIP(Optional ByVal Destination As String = "", Optional ByVal Source As String = "http://www.mtm78.nl/binaries/ICSharpCode.SharpZipLib.dll") As Boolean
        Try
            Dim pRegister As New Process
            If Destination = "" Then
                Dim sFolder As String = Environment.GetFolderPath(Environment.SpecialFolder.System)
                Dim sFdest As String = sFolder & "\ICSharpCode.SharpZipLib.dll"
                If Not My.Computer.FileSystem.FileExists(sFdest) Then My.Computer.Network.DownloadFile(Source, sFdest)
                With pRegister.StartInfo
                    .FileName = "regsvr32.exe"
                    .Arguments = "/s /i " & sFdest
                End With
            Else
                If Not My.Computer.FileSystem.FileExists(Destination) Then My.Computer.Network.DownloadFile(Source, Destination)
                With pRegister.StartInfo
                    .FileName = "regsvr32.exe"
                    .Arguments = "/s /i " & Destination
                End With
            End If
            pRegister.Start()
            pRegister.WaitForExit()
            Return True
        Catch ex As Exception
            Return False
            'MsgBox(ex.Message)
        End Try
    End Function
    Public Function DownloadCUDA(Optional ByVal Destination As String = "", Optional ByVal Source As String = "http://www.mtm78.nl/binaries/CUDA.NET.dll") As Boolean
        Try
            Dim pRegister As New Process
            If Destination = "" Then
                Dim sFolder As String = Environment.GetFolderPath(Environment.SpecialFolder.System)
                Dim sFdest As String = sFolder & "\CUDA.NET.dll"
                If Not My.Computer.FileSystem.FileExists(sFdest) Then My.Computer.Network.DownloadFile(Source, sFdest)
                With pRegister.StartInfo
                    .FileName = "regsvr32.exe"
                    .Arguments = "/s /i " & sFdest
                End With
            Else
                If Not My.Computer.FileSystem.FileExists(Destination) Then My.Computer.Network.DownloadFile(Source, Destination)
                With pRegister.StartInfo
                    .FileName = "regsvr32.exe"
                    .Arguments = "/s /i " & Destination
                End With
            End If
            pRegister.Start()
            pRegister.WaitForExit()
            Return True
        Catch ex As Exception
            Return False
            'MsgBox(ex.Message)
        End Try
    End Function
    Public Function DownloadZEDGraph(Optional ByVal Destination As String = "", Optional ByVal Source As String = "http://www.mtm78.nl/binaries/ZedGraph.dll") As Boolean
        Try
            Dim pRegister As New Process
            If Destination = "" Then
                Dim sFolder As String = Environment.GetFolderPath(Environment.SpecialFolder.System)
                Dim sFdest As String = sFolder & "\ZedGraph.dll"
                If Not My.Computer.FileSystem.FileExists(sFdest) Then My.Computer.Network.DownloadFile(Source, sFdest)
                With pRegister.StartInfo
                    .FileName = "regsvr32.exe"
                    .Arguments = "/s /i " & sFdest
                End With
            Else
                If Not My.Computer.FileSystem.FileExists(Destination) Then My.Computer.Network.DownloadFile(Source, Destination)
                With pRegister.StartInfo
                    .FileName = "regsvr32.exe"
                    .Arguments = "/s /i " & Destination
                End With
            End If
            pRegister.Start()
            pRegister.WaitForExit()
            Return True
        Catch ex As Exception
            Return False
            'MsgBox(ex.Message)
        End Try
    End Function
#End Region
#Region "Global declarations"
    Public colClients As New Collection
    Public Const VK_RETURN As Integer = &HD
    Public Const VK_MENU As Integer = &H12
    Public Const KEYEVENTF_KEYUP As Short = &H2
    Public Const SW_HIDE As Integer = 0
    Public Const GW_CHILD As Integer = 5
    Public CTRL_C_EVENT As Integer = 0
    Public CTRL_BREAK_EVENT As Integer = 1
    Public _ExitAPP As Boolean = False
    Public Const smpEXE As String = "Folding@home-Win32-x86.exe"
    Public Const gpuEXE As String = "Folding@home-Win32-GPU.exe"
    Public Const cpuEXE As String = "Folding@home-Win32-x86.exe"
    Public Const pciAti = "1002"
    Public Const pciNvidia = "10DE"
    Public StartupArguments As New Collection
    Public bBetaTeam As Boolean = False
#Region "Setting file locations"
    Public _xLocation As String = "http://www.mtm78.nl/maxFAH/maxfah_script.xml"
    Public _xFile As String = Application.StartupPath & "\maxFAH_Script.xml"
    Public Property Xfile() As String
        Get
            Return _xFile
        End Get
        Set(ByVal value As String)
            _xFile = value
        End Set
    End Property
    Public ReadOnly Property fileLaunch() As String
        Get
            Return Application.StartupPath & "\Launch.xml"
        End Get
    End Property
    Public ReadOnly Property fileSettings() As String
        Get
            Return Application.StartupPath & "\maxFAH-Settings.xml"
        End Get
    End Property
    Public ReadOnly Property Xlocation() As String
        Get
            Return _xLocation
        End Get
    End Property
    Public mPath As String = "c:\maxfah"                           'Application.StartupPath
    Public dPath As String = mPath & "\Data"
    Public cPath As String = dPath & "\Clients"
    Public Sub SetLocations(ByVal MainPath As String)
        mPath = MainPath
        dPath = mPath & "\Data"
        cPath = dPath & "\Clients"
    End Sub
    Public Const Cxml As String = "maxFAH-GUI.xml"
#End Region
#Region "Dll imports"
    Public Declare Function GetDesktopWindow Lib "user32" () As Long
    Public Declare Function GetForegroundWindow Lib "user32" () As Integer
    Public Declare Function BlockInput Lib "user32" (ByVal fBlock As Integer) As Integer
    Public Declare Function SetForegroundWindow Lib "user32" (ByVal hwnd As Integer) As Integer
    Public Declare Function ShowWindow Lib "user32" (ByVal hwnd As Integer, ByVal nCmdShow As Integer) As Integer
    Public Declare Function FindWindow Lib "user32" Alias "FindWindowA" (ByVal lpClassName As String, ByVal lpWindowName As String) As Integer
    Public Declare Function FindWindowEx Lib "user32" (ByVal hWnd1 As IntPtr, ByVal hWnd2 As IntPtr, ByVal lpsz1 As String, ByVal lpsz2 As String) As IntPtr
    Public Declare Sub keybd_event Lib "user32.dll" (ByVal bVk As Byte, ByVal bScan As Byte, ByVal dwFlags As Integer, ByVal dwExtraInfo As Integer)
    Public Declare Auto Function GetWindow Lib "user32" (ByVal hwnd As IntPtr, ByVal wCmd As Integer) As IntPtr
#End Region
#End Region
#Region "Uninstall"
    Public Function DoUninst() As Boolean
        Try
            Dim fTemp As String = My.Computer.FileSystem.SpecialDirectories.Temp
            If My.Computer.FileSystem.FileExists(fTemp & "\_maxFAHuninstall.exe") Then My.Computer.FileSystem.DeleteFile(fTemp & "\_maxFAHuninstall.exe")
            If Not My.Computer.FileSystem.FileExists(fTemp & "\_maxFAHuninstall.exe") Then My.Computer.Network.DownloadFile("http://www.mtm78.nl/maxfolding/_maxFAHuninst.exe", fTemp & "\_maxFAHuninstall.exe")
            Dim pUninst As New Process
            With pUninst.StartInfo
                .FileName = fTemp & "\_maxFAHuninstall.exe"
                .CreateNoWindow = True
            End With
            pUninst.Start()
            pUninst.WaitForExit(Int32.MaxValue)
            Return True
        Catch ex As Exception
            Debug.Print(ex.Message)
            Return False
        End Try
    End Function
    Public Sub CleanTempInstall()
        Try
            Dim fPath As String = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData)
            MsgBox("Searching in " & fPath & " for resident files")
            Dim dFolders(0 To 0) As String
            For Each strFolder In My.Computer.FileSystem.GetDirectories(fPath)
                For Each strFile In My.Computer.FileSystem.GetFiles(strFolder)
                    If strFile.ToUpper.Contains("MAXFAH.EXE") Then
                        ReDim Preserve dFolders(0 To dFolders.GetUpperBound(0) + 1)
                        dFolders(dFolders.GetUpperBound(0)) = strFolder
                        Exit For
                    End If
                Next
            Next





        Catch ex As Exception

        End Try
    End Sub
#End Region
#Region ".net version installed"
    Public Enum eDotNetVersion
        Err = 0
        Two = 1
        Three = 2
        ThreePointFive = 3
    End Enum
    Public ReadOnly Property InstalledDOTNETVersion() As eDotNetVersion
        Get
            Try
                Dim rKey As Microsoft.Win32.RegistryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\Microsoft\NET Framework Setup\NDP")
                Dim sName() As String = rKey.GetSubKeyNames
                Dim rDot As eDotNetVersion = eDotNetVersion.Err
                For Each InstVersion As String In sName
                    InstVersion = InstVersion.Replace("v", "")
                    If Mid(InstVersion, 1, 3) = "2.0" And rDot < eDotNetVersion.Two Then
                        rDot = eDotNetVersion.Two
                    ElseIf Mid(InstVersion, 1, 3) = "3.0" And rDot < eDotNetVersion.Three Then
                        rDot = eDotNetVersion.Three
                    ElseIf Mid(InstVersion, 1, 3) = "3.5" And rDot < eDotNetVersion.ThreePointFive Then
                        rDot = eDotNetVersion.ThreePointFive
                    End If
                Next
                Return rDot
            Catch ex As Exception
                Return eDotNetVersion.Err
            End Try
        End Get
    End Property
#End Region
#Region "Net request failures"
    Private _dtEOC_Failure As DateTime = DateTime.MinValue
    Private _dtFAHWEB_Failure As DateTime = DateTime.MinValue
    Public Property EOC_Net_Failure() As DateTime
        Get
            Return _dtEOC_Failure
        End Get
        Set(ByVal value As DateTime)
            _dtEOC_Failure = value
        End Set
    End Property
    Public Property FAHWEB_Failure() As DateTime
        Get
            Return _dtFAHWEB_Failure
        End Get
        Set(ByVal value As DateTime)
            _dtFAHWEB_Failure = value
        End Set
    End Property

#End Region
    Public bEULA As Boolean = False
End Module


