﻿Public Class frmEULA
    Private bAccepted As Boolean = False
    Public ReadOnly Property Accepted() As Boolean
        Get
            Return bAccepted
        End Get
    End Property
    Private Sub frmEULA_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        wbAbout.DocumentText = RichTextBox1.Text
        wbAbout.Visible = False
        wbAbout.Dock = DockStyle.Fill
        rtfEULA.Visible = False
        rtfEULA.Dock = DockStyle.Fill
        rtfMAX.Rtf = txtmSource.Text
        rtfMAX.Dock = DockStyle.Fill
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If rtfMAX.Visible Then
            wbAbout.Visible = True
            rtfMAX.Visible = False
        ElseIf wbAbout.Visible Then
            rtfEULA.Visible = True
            wbAbout.Visible = False
        ElseIf rtfEULA.Visible Then
            bEULA = True
            Me.Close()
        End If
    End Sub
End Class