﻿Public Class frmMessage
    Public Event CancelClicked()
    Public Event NextClicked()


    Public Function SetButtons(ByVal cmdokText As String, ByVal cmdCancelText As String) As Boolean
        Try
            cmdOK.Text = cmdokText
            cmdCancel.Text = cmdCancelText
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function
    Private Sub cmdOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOK.Click
        RaiseEvent NextClicked()
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        RaiseEvent CancelClicked()
    End Sub

    Private Sub frmMessage_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class