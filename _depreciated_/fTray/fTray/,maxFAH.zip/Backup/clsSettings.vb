﻿Imports Microsoft.Win32
Public Class clsSettings
    Private bHasSettings As Boolean = False
    Private _cHeaderWidth(0 To 9) As Int16
    Public Property HeaderWidth(ByVal Index As Int16) As Int16
        Get
            Try
                Return _cHeaderWidth(Index)
            Catch ex As Exception
                Return -1
            End Try
        End Get
        Set(ByVal value As Int16)
            Try
                _cHeaderWidth(Index) = value
            Catch ex As Exception
                'Log to window
            End Try
        End Set
    End Property
    Public ReadOnly Property HasSettings() As Boolean
        Get
            Return bHasSettings
        End Get
    End Property
#Region "Settings"
    Public bExtendGUI As Boolean = True
    Public bManualAP As Boolean = False
    Public bStartInTray As Boolean = False
    Public bTrayManager As Boolean = False
    Public bAutoDownProjects As Boolean = True
    Public bStartWithWindows As Boolean = False
    Public bStartClients As Boolean = True
    Public bStartConsolesHidden As Boolean = True
    Public bConfirmExit As Boolean = False
    Public bShowConsolesOnExit As Boolean = True
    Public bAutoReload As Boolean = True
    Public bClientIcons As Boolean = True
    Public iAPinterval As Int16 = 30
    Public LastProjectUpdate As String = ""
    Public bShowBalloonTip As Boolean = False
    Public iServiceCheckInterval As Long = 5000
    Public Enum eEocLimit
        None = 0
        Minimal = 1
        OneDay = 2
        OneWeek = 3
        OneMonth = 4
    End Enum
    Public EocLimit As eEocLimit = eEocLimit.None
    Public NonFatal() As String
   
    Public dtLastProjectUpdate As DateTime = DateTime.MinValue
#End Region

    Public Function GetSettings() As Boolean
        Try
            Dim rKey As RegistryKey, gKey As RegistryKey, cKey As RegistryKey
            Try
                rKey = Registry.CurrentUser.OpenSubKey("Software\maxTray", RegistryKeyPermissionCheck.ReadSubTree, Security.AccessControl.RegistryRights.QueryValues)
            Catch ex As Exception
                Debug.Print(ex.Message)
                bHasSettings = False
                Return False
            End Try
            gKey = rKey.OpenSubKey("GUI")
            bExtendGUI = CBool(gKey.GetValue("Extended"))
            bManualAP = CBool(gKey.GetValue("ManualAP"))
            bStartInTray = CBool(gKey.GetValue("StartInTray"))
            bAutoDownProjects = CBool(gKey.GetValue("DownloadNewProjects"))
            bShowConsolesOnExit = CBool(gKey.GetValue("ShowConsolesOnExit"))
            bStartClients = CBool(gKey.GetValue("AutoStartClients"))
            bStartConsolesHidden = CBool(gKey.GetValue("StartConsolesHidden"))
            bStartWithWindows = CBool(gKey.GetValue("StartWithWindows"))
            bConfirmExit = CBool(gKey.GetValue("ConfirmExit"))
            bAutoReload = CBool(gKey.GetValue("AutoReload"))
            bClientIcons = CBool(gKey.GetValue("ClientIcons"))
            iAPinterval = CInt(gKey.GetValue("APinterval"))
            bShowBalloonTip = CBool(gKey.GetValue("ShowBalloonTip"))
            iServiceCheckInterval = CInt(gKey.GetValue("ServiceCheckInterval"))
            If iServiceCheckInterval = 0 Then iServiceCheckInterval = 5000
            If gKey.GetSubKeyNames.Contains("NonFatal") Then
                Dim nfKey As RegistryKey = gKey.OpenSubKey("NonFatal")
                If nfKey.ValueCount = 0 Then
                    nfKey.Close()
                    nfKey = Nothing
                    GoTo ResetNF
                End If
                ReDim NonFatal(0 To nfKey.ValueCount - 1)
                For xInt As Int16 = 0 To nfKey.ValueCount - 1
                    NonFatal(xInt) = nfKey.GetValue((xInt + 1).ToString)
                Next
            Else
ResetNF:
                ReDim NonFatal(0 To 3)
                NonFatal(0) = "CoreStatus = 64 (100)"
                NonFatal(1) = "CoreStatus = 66 (102)"
                NonFatal(2) = "CoreStatus = 62 (98)"
                NonFatal(3) = "CoreStatus = 6E (110)"
            End If
            gKey.Close()
            gKey = Nothing
            bHasSettings = True
            Return True
        Catch ex As Exception
            Debug.Print(ex.Message)
            bHasSettings = False
            Return False
        End Try
    End Function
    Public Function SaveSettings()
        Try
            Dim rKey As RegistryKey, gKey As RegistryKey, cKey As RegistryKey
            Try
                rKey = Registry.CurrentUser.OpenSubKey("Software", True)
                Dim sKeys() As String = rKey.GetSubKeyNames
                Dim bHas As Boolean = False
                For Each Str As String In sKeys
                    If Str = "maxTray" Then
                        bHas = True
                        Exit For
                    End If
                Next
                If bHas Then
                    rKey = rKey.OpenSubKey("maxTray", True)
                Else
                    rKey.CreateSubKey("maxTray")
                    rKey = rKey.OpenSubKey("maxTray", True)
                End If
                rKey.CreateSubKey("GUI")
                rKey.CreateSubKey("Client")
                gKey = rKey.OpenSubKey("GUI", True)
                cKey = rKey.OpenSubKey("Clients", True)
            Catch ex As Exception
                Debug.Print(ex.Message)
                Return False
            End Try
            gKey.SetValue("Extended", bExtendGUI.ToString)
            gKey.SetValue("ManualAP", bManualAP.ToString)
            gKey.SetValue("StartInTray", bStartInTray.ToString)
            gKey.SetValue("DownloadNewProjects", bAutoDownProjects.ToString)
            gKey.SetValue("StartWithWindows", bStartWithWindows.ToString)
            gKey.SetValue("ShowConsolesOnExit", bShowConsolesOnExit.ToString)
            gKey.SetValue("AutoStartClients", bStartClients.ToString)
            gKey.SetValue("StartConsolesHidden", bStartConsolesHidden.ToString)
            gKey.SetValue("ConfirmExit", bConfirmExit.ToString)
            gKey.SetValue("AutoReload", bAutoReload.ToString)
            gKey.SetValue("ClientIcons", bClientIcons.ToString)
            gKey.SetValue("APinterval", iAPinterval.ToString)
            gKey.SetValue("ShowBalloonTip", bShowBalloonTip.ToString)
            gKey.SetValue("ServiceCheckInterval", iServiceCheckInterval.ToString)
            Dim nfKey As RegistryKey
            If Not gKey.GetSubKeyNames.Contains("NonFatal") Then
                nfKey = gKey.CreateSubKey("NonFatal")
            Else
                gKey.DeleteSubKey("NonFatal")
                nfKey = gKey.CreateSubKey("NonFatal")
            End If
            For xInt As Int16 = 0 To NonFatal.Count - 1
                nfKey.SetValue(xInt + 1, NonFatal(xInt))
            Next
            'More settings here!
            If bStartWithWindows Then
                Dim startKey As RegistryKey = Registry.CurrentUser.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Run", Microsoft.Win32.RegistryKeyPermissionCheck.ReadWriteSubTree, Security.AccessControl.RegistryRights.FullControl)
                If startKey.GetValueNames.Contains("maxFAH") Then startKey.DeleteValue("maxFAH")
                Dim strValue As String = ChrW(34) & Application.StartupPath & "\maxFAH.exe" & ChrW(34) & " -Tray"
                startKey.SetValue("maxFAH", strValue)
                startKey.Close()
                startKey = Nothing
            Else
                Dim startKey As RegistryKey = Registry.CurrentUser.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Run", RegistryKeyPermissionCheck.ReadWriteSubTree)
                If startKey.GetValueNames.Contains("maxFAH") Then startKey.DeleteValue("maxFAH")
                startKey.Close()
                startKey = Nothing
            End If
            gKey.Close() : rKey.Close() : nfKey.Close() : rKey.Close()
            gKey = Nothing : rKey = Nothing : nfKey = Nothing : rKey = Nothing
            Return True
        Catch ex As Exception
            LogWindow.WriteError("clsSettings, SaveSettings", Err, ex.Message)
            Return False
        End Try
    End Function
    Public Sub RemoveSettings()
        Try
            Dim rKey As RegistryKey = Registry.CurrentUser.OpenSubKey("Software")
            rKey.DeleteSubKeyTree("maxTray")
        Catch ex As Exception

        End Try
    End Sub

   
End Class