﻿Imports System.IO
Public Class frmLogWindow





End Class