﻿Imports Microsoft.Win32.Registry
Public Class clsCpuReg
    'Since I want to change from single binary without dll's in the installer I can use cpuid instead of wmi/registry
#Region "Error"
    Private _bErr As Boolean = False, _lErrObj As ErrObject
    Public ReadOnly Property HasError() As Boolean
        Get
            Return _bErr
        End Get
    End Property
    Public ReadOnly Property LastError() As ErrObject
        Get
            _bErr = False
            Return _lErrObj
        End Get
    End Property
#End Region
#Region "Cores"
    Private _iKeyCount As Int16 = 0
    Private _Core(0 To 0) As String
    Public ReadOnly Property NumberOfEntries() As Int16
        Get
            Return _Core.GetUpperBound(0)
        End Get
    End Property
    Public ReadOnly Property Core(ByVal Index As Int16) As String
        Get
            Try
                If _Core.GetUpperBound(0) = 0 Then
                    _bErr = True
                    With _lErrObj
                        .Description = "Class not initialized"
                        .Source = "clsCpuReg"
                    End With
                    Return Nothing
                ElseIf _Core.GetUpperBound(0) < Index Then
                    _bErr = True
                    With _lErrObj
                        .Description = "Query out of bounds"
                        .Source = "clsCpuReg"
                    End With
                    Return Nothing
                Else
                    Return _Core(Index)
                End If
            Catch ex As Exception
                _bErr = True
                With _lErrObj
                    .Description = ex.Message
                    .Source = "clsCpuReg- core query for index " & Index
                End With
                Return Nothing
            End Try
        End Get
    End Property
#End Region
#Region "Entry point"
    Public Sub New()
        Try
            Dim rKey As Microsoft.Win32.RegistryKey = Microsoft.Win32.Registry.LocalMachine.OpenSubKey("HARDWARE\DESCRIPTION\System\CentralProcessor")
            Dim sKey() As String = rKey.GetSubKeyNames
            If sKey.GetUpperBound(0) = 0 Then
                _bErr = True
                With _lErrObj
                    .Description = "No subkeys?"
                    .Source = "clsCpuReg-entrypoint"
                End With
                Exit Sub
            Else
                For xInt As Int16 = 0 To sKey.GetUpperBound(0)
                    Dim vKey As Microsoft.Win32.RegistryKey
                    Try
                        vKey = rKey.OpenSubKey(sKey(xInt))
                    Catch ex As Exception
                        _bErr = True
                        With _lErrObj
                            .Description = "Can not open sub key " & sKey(xInt) & vbNewLine & ex.Message
                            .Source = "clsCpuReg-entrypoint"
                        End With
                        Exit Sub
                    End Try
                    Try
                        ReDim Preserve _Core(0 To _Core.GetUpperBound(0) + 1)
                        _Core(_Core.GetUpperBound(0)) = vKey.GetValue("ProcessorNameString")
                    Catch ex As Exception
                        _bErr = True
                        With _lErrObj
                            .Description = "Can not get processor name " & sKey(xInt) & vbNewLine & ex.Message
                            .Source = "clsCpuReg-entrypoint"
                        End With
                        Exit Sub
                    End Try
                Next
            End If
            If _Core.GetUpperBound(0) = 0 Then
                _bErr = True
                With _lErrObj
                    .Description = "Could not get any processor information"
                    .Source = "clsCpuReg-entrypoint"
                End With
            End If
        Catch ex As Exception
            _bErr = True
            With _lErrObj
                .Description = ex.Message
                .Source = "clsCpuReg-entrypoint"
            End With
        End Try
    End Sub
#End Region

End Class
