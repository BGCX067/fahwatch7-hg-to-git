﻿Public Class frmEUE
    Private _cStatus As clsQueue.clsCoreStatus
    Private Sub rt_LinkClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.LinkClickedEventArgs) Handles rt.LinkClicked
        Process.Start(e.LinkText)
    End Sub
    Public Sub NotifyEUE(ByVal cStatus As clsQueue.clsCoreStatus)
        Try
            Me.Hide()
            If cStatus.IsEmpty Then Exit Sub
            _cStatus = cStatus
            rt.Text &= "Client: " & cStatus.ClientLocation & vbNewLine
            rt.Text &= "Core status: " & vbTab & cStatus.CoreStatus & vbNewLine
            rt.Text &= "Project: " & vbTab & cStatus.cEntry.Project.Project & " (Run " & cStatus.cEntry.Project.Run & " Clone " & cStatus.cEntry.Project.Clone & " Gen " & cStatus.cEntry.Project.Gen & ")" & vbNewLine
            rt.Text &= "Issued: " & vbTab & cStatus.cEntry.Issued.ToShortDateString & " " & cStatus.cEntry.Issued.ToLongTimeString & vbNewLine
            rt.Text &= "End time (eue):" & vbTab & cStatus.cEntry.TimeData.EndTime.ToShortDateString & " " & cStatus.cEntry.TimeData.EndTime.ToLongTimeString & vbNewLine & vbNewLine
            For Each sLine As String In cStatus.LogSnippet
                rt.Text &= sLine & vbNewLine
            Next
            nIcon.Text = cStatus.ClientLocation & vbNewLine & cStatus.CoreStatus
            nIcon.BalloonTipIcon = ToolTipIcon.Warning
            nIcon.BalloonTipTitle = cStatus.CoreStatus
            nIcon.BalloonTipText = cStatus.ClientLocation
            nIcon.ShowBalloonTip(5000)
        Catch ex As Exception
            Me.Finalize()
        End Try
    End Sub
    
    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        If My.Computer.FileSystem.FileExists(_cStatus.ClientLocation & "\fahlog.txt") Then Process.Start(_cStatus.ClientLocation & "\fahlog.txt")
    End Sub
    Private Sub LinkLabel2_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Process.Start(_cStatus.ClientLocation)
    End Sub

    Private Sub nIcon_BalloonTipClicked(ByVal sender As Object, ByVal e As System.EventArgs) Handles nIcon.BalloonTipClicked
        Me.Show()
    End Sub
    Private Sub nIcon_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles nIcon.DoubleClick
        Me.Show()
    End Sub
    Private Sub nIcon_MouseDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles nIcon.MouseDoubleClick
        Me.Show()
    End Sub
    Private Sub frmEUE_ResizeEnd(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.ResizeEnd
        rt.Height = Me.ClientRectangle.Height - LinkLabel1.Height - 5
    End Sub
End Class