﻿Public Class frmQueue
    Public Sub ShowQueue(ByVal Client As clsClientConfiguration.clsClientConfigs.sClientSettings.sClient, Optional ByVal OwnerForm As Form = Nothing)
        Try
            If Not Client.GuiController.Queue.ReadQueue Then Exit Sub
            With Client.GuiController.Queue
                If .HasError Then Exit Sub
                If Not .FullSlots Then Exit Sub
                rt.Clear()
                rt.Clear()
                rt.Text &= "Queue.dat version:" & .Version & vbNewLine & "Performance fraction: " & .PerformanceFraction & vbNewLine & "Performance fraction units: " & .PerformanceFractionUnits & vbNewLine & _
                "Download rate: " & (CInt(.DownloadRate) / 1000) & " Kb/S" & vbNewLine & "Download rate units: " & .DownloadRateUnits & vbNewLine & "Upload rate: " & (CInt(.UploadRate) / 1000) & " Kb/S" & vbNewLine & "Upload rate units: " & .UploadRateUnits & vbNewLine & _
                "Current index: " & .Current.ToString & vbNewLine
                For xInd = 0 To 9
                    Dim Entry As clsQueue.Entry = .Slot(xInd)
                    rt.Text &= vbNewLine
                    rt.Text &= "Index=" & xInd.ToString & vbNewLine
                    rt.Text &= "Status=" & Entry.Status & vbTab & "Upload status=" & Entry.UploadStatus & vbNewLine
                    rt.Text &= "Project: " & Entry.Project.Project & " (Run " & Entry.Project.Run & " Clone " & Entry.Project.Clone & " Generation " & Entry.Project.Gen & ")" & vbNewLine
                    rt.Text &= "Cpu memory: " & Entry.CpuMemory & " Gpu memory: " & Entry.GpuMemory & vbNewLine
                    rt.Text &= "Flops:" & Entry.Flops & vbTab & "Benchmark: " & Entry.BenchMark & vbNewLine
                    rt.Text &= "Username: " & Entry.UserName & " (" & Entry.TeamNumber & ")" & vbNewLine
                    rt.Text &= "Time data - begin:" & vbTab & Entry.TimeData.BeginTime.ToLongDateString & " " & Entry.TimeData.BeginTime.ToLongTimeString & vbNewLine
                    If Entry.TimeData.EndTime = #1/1/2000# Then
                        rt.Text &= "Time date - end:" & vbTab
                        If Entry.Status = "1" Then
                            If Client.GuiController.Queue.Eta <> #1/1/2000# Then
                                rt.Text &= " ETA - " & Client.GuiController.Queue.Eta.ToLongDateString & " " & Client.GuiController.Queue.Eta.ToLongTimeString & vbNewLine
                            Else
                                rt.Text &= " -unknown- " & vbNewLine
                            End If
                        Else
                            rt.Text &= " -unknown- " & vbNewLine
                        End If
                    Else
                        rt.Text &= "Time data - end:" & vbTab & Entry.TimeData.EndTime.ToLongDateString & " " & Entry.TimeData.EndTime.ToLongTimeString & vbNewLine
                    End If
                    rt.Text &= "Issued: " & vbTab & Entry.Issued.ToLongDateString & " " & Entry.Issued.ToLongTimeString & vbNewLine
                    If ProjectInfo.KnownProject(Entry.Project.Project) Then
                        Dim fDays As Int16 = CInt(Mid(ProjectInfo.Project(Entry.Project.Project).PreferredDays, 1, ProjectInfo.Project(Entry.Project.Project).PreferredDays.LastIndexOf(".")))
                        Dim eDate As DateTime = Entry.TimeData.BeginTime.AddDays(fDays)
                        rt.Text &= "Due: " & vbTab & eDate.ToLongDateString & " " & eDate.ToLongTimeString & vbNewLine
                    End If
                    rt.Text &= "Expires: " & vbTab & Entry.Due.ToLongDateString & " " & Entry.Due.ToLongTimeString & vbNewLine
                    rt.Text &= "Work server: " & Entry.ServerIP & ":" & Entry.ServerPort & vbNewLine
                    rt.Text &= "Collection server: " & Entry.CollectionServer & vbNewLine
                    rt.Text &= "Failed uploads: " & Entry.UploadFailures & vbNewLine
                Next
                AddRT("") : AddRT("")
            End With
            Me.Text = Mid(Client.GuiController.ClientLocation, cPath.Length + 2)
            Try
                If OwnerForm.Text <> "" Then
                    Me.Owner = OwnerForm
                    Me.ShowDialog(OwnerForm)
                End If
            Catch ex As Exception
                Me.Show()
            End Try
        Catch ex As Exception : End Try
    End Sub
    Private Sub AddRT(ByVal Line As String)
        rt.Text &= Line & vbNewLine
    End Sub
    Private Sub frmQueue_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Try
            If Owner.Text <> "" Then
                Owner.Focus()
            End If
        Catch ex As Exception

        End Try
    End Sub
   
End Class