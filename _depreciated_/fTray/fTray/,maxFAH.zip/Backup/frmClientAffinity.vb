﻿Public Class frmClientAffinity
   
    'Test code, only to show layout
    Private Sub frmClientAffinity_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try

        Catch ex As Exception

        End Try
    End Sub
    Private lvPitem As ListViewItem.ListViewSubItem
    Private lvAffinty As ListViewItem.ListViewSubItem
    Private Sub lvManual_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lvManual.MouseDown
        Try
            If e.Button = Windows.Forms.MouseButtons.Left Then
                Dim lvHInf As ListViewHitTestInfo = lvManual.HitTest(e.X, e.Y)
                Dim pItems As New Collection
                With pItems
                    .Add(ProcessPriorityClass.RealTime.ToString, ProcessPriorityClass.RealTime.ToString)
                    .Add(ProcessPriorityClass.High.ToString, ProcessPriorityClass.High.ToString)
                    .Add(ProcessPriorityClass.AboveNormal.ToString, ProcessPriorityClass.AboveNormal.ToString)
                    .Add(ProcessPriorityClass.Normal.ToString, ProcessPriorityClass.Normal.ToString)
                    .Add(ProcessPriorityClass.BelowNormal.ToString, ProcessPriorityClass.BelowNormal.ToString)
                    .Add(ProcessPriorityClass.Idle.ToString, ProcessPriorityClass.Idle.ToString)
                End With
                Dim aItems As New Collection
                With aItems
                    .Add("No", "No")
                    .Add("Yes", "Yes")
                End With

                If pItems.Contains(lvHInf.SubItem.Text) Or lvHInf.SubItem.Text = "low" Then
                    Dim mMenu As New ContextMenuStrip
                    With mMenu
                        For Each sPrio As String In pItems
                            .Items.Add(sPrio)
                        Next
                    End With
                    AddHandler mMenu.ItemClicked, AddressOf pMenuClicked
                    lvPitem = lvHInf.SubItem
                    mMenu.Show(lvManual, e.Location)
                ElseIf aItems.Contains(lvHInf.SubItem.Text) Then
                    Dim mMenu As New ContextMenuStrip
                    With mMenu
                        For Each sPrio As String In aItems
                            .Items.Add(sPrio)
                        Next
                    End With
                    AddHandler mMenu.ItemClicked, AddressOf aMenuClicked
                    lvAffinty = lvHInf.SubItem
                    mMenu.Show(lvManual, e.Location)
                End If
                lvHInf = Nothing
                pItems.Clear()
                pItems = Nothing
            End If
        Catch ex As Exception

        End Try
    End Sub
    Private Sub aMenuClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs)
        CType(lvAffinty, ListViewItem.ListViewSubItem).Text = e.ClickedItem.Text
    End Sub
    Private Sub pMenuClicked(ByVal Sender As Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs)
        CType(lvPitem, ListViewItem.ListViewSubItem).Text = e.ClickedItem.Text
    End Sub
    Private Sub rbManual_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbManual.CheckedChanged
        If rbManual.Checked Then
            lvManual.Enabled = True
            For Each sControl As Control In GroupBox1.Controls
                If TypeOf sControl Is Button Then
                    CType(sControl, Button).Enabled = True
                ElseIf TypeOf sControl Is ComboBox Then
                    CType(sControl, ComboBox).Enabled = True
                End If
            Next
        Else
            lvManual.Enabled = False
            For Each sControl As Control In GroupBox1.Controls
                If TypeOf sControl Is Button Then
                    If Not CType(sControl, Button).Text = "&Cancel" And Not CType(sControl, Button).Text = "&Save" Then
                        CType(sControl, Button).Enabled = False
                    End If
                ElseIf TypeOf sControl Is ComboBox Then
                    CType(sControl, ComboBox).Enabled = False
                End If
            Next
        End If
        lvManual.Enabled = rbManual.Checked
    End Sub

    Private Sub cmdNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdNext.Click
        'Save info!
        Try
            cmdNext.Enabled = False
            Dim intClient As Int16 = 0, intWorker As Int16 = 1
            For xInt As Int16 = 0 To lvManual.Items.Count - 1
                If lvManual.Items(xInt).Text = "" Then
                    'Same client!
                    With Clients(intClient).GuiController
                        .PrioritySettings(intWorker) = lvManual.Items(xInt).SubItems(2).Text
                        Dim strAff As String = ""
                        For zInt As Int16 = 1 To CInt(hwInfo.TotalCores)
                            If lvManual.Items(xInt).SubItems(2 + zInt).Text.ToUpper = "YES" Then
                                strAff &= "1"
                            Else
                                strAff &= "0"
                            End If
                        Next
                        .AffintySettings(intWorker) = strAff
                    End With
                    intWorker += 1
                Else
                    'new client!
                    intClient += 1
                    intWorker = 1
                    With Clients(intClient).GuiController
                        .PrioritySettings(intWorker) = lvManual.Items(xInt).SubItems(2).Text
                        Dim strAff As String = ""
                        For zInt As Int16 = 1 To CInt(hwInfo.TotalCores)
                            If lvManual.Items(xInt).SubItems(2 + zInt).Text.ToUpper = "YES" Then
                                strAff &= "1"
                            Else
                                strAff &= "0"
                            End If
                        Next
                        .AffintySettings(intWorker) = strAff
                    End With
                End If
            Next
            For Xint As Int16 = 1 To Clients.GetUpperBound(0)
                Cfg.CfgManager.ClientSettings.SaveConfig(Clients(Xint))
            Next
            If cmdNext.Text = "&Save" Then
                mySettings.bManualAP = rbManual.Checked
                For Each sControl As Control In GroupBox1.Controls
                    If TypeOf sControl Is ComboBox Then
                        mySettings.iAPinterval = CInt(CType(sControl, ComboBox).Text)
                        Exit For
                    End If
                Next
                mySettings.SaveSettings()
                fTray.SetAPinterval(mySettings.iAPinterval * 60 * 1000)
                Me.Close()
            Else
                'finish installation!
                Me.Close()
                formHWinfo.CloseHWinfo()
            End If
        Catch ex As Exception

        End Try
    End Sub
    Private Sub Cancel()
        Me.Close()
        If fTray.WindowState = FormWindowState.Normal Then fTray.BringToFront()
    End Sub
    Private Sub frmClientAffinity_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Try
            Me.Visible = False
            For xInt As Int16 = 1 To CInt(hwInfo.TotalCores)
                lvManual.Columns.Add("Core " & xInt)
            Next
            
            Dim iCurrentRow As Int16 = 0
            For xint As Int16 = 1 To Clients.GetUpperBound(0)
                'lvManual.Items.Add(Clients(xint).GuiController.ClientEXE.Replace(cPath, ""))
                lvManual.Items.Add(Clients(xint).GuiController.ShortName)
                If Clients(xint).GuiController.TypeOfClient >= 5 And Clients(xint).GuiController.TypeOfClient <= 8 Then
                    'Gpu client
                    lvManual.Items(iCurrentRow).SubItems.Add("1")
                    If Clients(xint).GuiController.APcount >= 1 Then 'Show client settings if no AP settings are stored
                        lvManual.Items(iCurrentRow).SubItems.Add(Clients(xint).GuiController.PrioritySettings(1))
                        Dim strAff As String = Clients(xint).GuiController.AffintySettings(1)
                        For yInt As Int16 = 1 To strAff.Length
                            If Mid(strAff, yInt, 1) = "1" Then
                                lvManual.Items(iCurrentRow).SubItems.Add("Yes")
                            Else
                                lvManual.Items(iCurrentRow).SubItems.Add("No")
                            End If
                        Next
                    Else
                        lvManual.Items(iCurrentRow).SubItems.Add(Clients(xint).PandeGroup.CorePriority)
                        If Clients(xint).PandeGroup.DisableAffinitylock.ToUpper = "NO" Then
                            'ordinal 0 uses last core, ordinal 1 previous ect 
                            For yInt As Int16 = 1 To CInt(hwInfo.TotalCores)
                                If yInt + Clients(xint).GuiController.Ordinal = CInt(hwInfo.TotalCores) Then
                                    lvManual.Items(iCurrentRow).SubItems.Add("Yes")
                                Else
                                    lvManual.Items(iCurrentRow).SubItems.Add("No")
                                End If
                            Next
                        Else
                            'affinity is set to all cores
                            For yInt As Int16 = 1 To CInt(hwInfo.TotalCores)
                                lvManual.Items(iCurrentRow).SubItems.Add("Yes")
                            Next
                        End If
                    End If
                    iCurrentRow += 1
                ElseIf Clients(xint).GuiController.TypeOfClient >= 1 And Clients(xint).GuiController.TypeOfClient < 5 Then
                    'Smp client
                    For yInt As Int16 = 1 To 4
                        lvManual.Items(iCurrentRow).SubItems.Add(yInt.ToString)
                        If Clients(xint).GuiController.APcount >= 1 Then 'Show stored settings
                            lvManual.Items(iCurrentRow).SubItems.Add(Clients(xint).GuiController.PrioritySettings(yInt))
                            Dim strAff As String = Clients(xint).GuiController.AffintySettings(yInt)
                            For zInt As Int16 = 1 To strAff.Length
                                If Mid(strAff, zInt, 1) = "1" Then
                                    lvManual.Items(iCurrentRow).SubItems.Add("Yes")
                                Else
                                    lvManual.Items(iCurrentRow).SubItems.Add("No")
                                End If
                            Next
                        Else
                            lvManual.Items(iCurrentRow).SubItems.Add(Clients(xint).PandeGroup.CorePriority)
                            'affinity is set to all cores
                            For zInt As Int16 = 1 To CInt(hwInfo.TotalCores)
                                lvManual.Items(iCurrentRow).SubItems.Add("Yes")
                            Next
                        End If
                        If yInt = 4 Then
                            iCurrentRow += 1
                        Else
                            iCurrentRow += 1
                            lvManual.Items.Add("")
                        End If
                    Next
                ElseIf Clients(xint).GuiController.TypeOfClient = clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eClient.CPU Then
                    'Unicore client 
                    lvManual.Items(iCurrentRow).SubItems.Add("1")
                    If Clients(xint).GuiController.APcount >= 1 Then 'show stored settings
                        lvManual.Items(iCurrentRow).SubItems.Add(Clients(xint).GuiController.PrioritySettings(1))
                        Dim strAff As String = Clients(xint).GuiController.AffintySettings(1)
                        For zInt As Int16 = 1 To strAff.Length
                            If Mid(strAff, zInt, 1) = "1" Then
                                lvManual.Items(iCurrentRow).SubItems.Add("Yes")
                            Else
                                lvManual.Items(iCurrentRow).SubItems.Add("No")
                            End If
                        Next
                    Else
                        lvManual.Items(iCurrentRow).SubItems.Add(Clients(xint).PandeGroup.CorePriority)
                        'affinity is set to all cores on default
                        For yInt As Int16 = 1 To CInt(hwInfo.TotalCores)
                            lvManual.Items(iCurrentRow).SubItems.Add("Yes")
                        Next
                    End If
                    iCurrentRow += 1
                End If
            Next
            lvManual.Columns(0).AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent)
            Dim iWidth As Int16 = 0, iHeight As Int16 = 0
            For xint As Int16 = 0 To lvManual.Columns.Count - 1
                iWidth += lvManual.Columns(xint).Width
            Next
            For xint As Int16 = 0 To lvManual.Items.Count - 1
                iHeight += lvManual.Items(xint).Bounds.Height
            Next
            lvManual.Width = iWidth + 25
            lvManual.Height = iHeight + 30

            rbManual.Checked = mySettings.bManualAP
            If mySettings.bTrayManager Then
                GroupBox1.AutoSize = False
                cmdNext.Text = "&Save"
                Dim cmdCancel As New Button
                Dim cmdApply As New Button
                Dim cmbInterval As New ComboBox

                cmdApply.Size = cmdNext.Size
                cmdApply.Anchor = AnchorStyles.Bottom + AnchorStyles.Right
                cmdApply.Text = "&Apply"


                With cmbInterval
                    .Items.Add("10")
                    .Items.Add("30")
                    .Items.Add("60")
                    .Text = mySettings.iAPinterval.ToString
                    .DropDownStyle = ComboBoxStyle.DropDownList
                    .Width = 40
                    .Anchor = AnchorStyles.Bottom + AnchorStyles.Right
                End With

                cmdCancel.Size = cmdNext.Size
                cmdCancel.Anchor = AnchorStyles.Bottom + AnchorStyles.Right
                cmdCancel.Text = "&Cancel"

                GroupBox1.Controls.Add(cmdApply)
                GroupBox1.Controls.Add(cmbInterval)
                GroupBox1.Controls.Add(cmdCancel)

                cmdApply.Left = cmdNext.Left - cmdApply.Width - 5
                cmbInterval.Left = cmdApply.Left - cmbInterval.Width - 5
                cmdCancel.Left = cmbInterval.Left - cmdApply.Width - 5

                cmbInterval.Top = cmdNext.Top
                cmdApply.Top = cmdNext.Top
                cmdCancel.Top = cmdNext.Top

                cmdApply.Enabled = rbManual.Checked
                cmbInterval.Enabled = rbManual.Checked

                Me.CancelButton = cmdCancel
                AddHandler cmdCancel.Click, AddressOf Cancel
                AddHandler cmdApply.Click, AddressOf Apply
            End If
            lvManual.Enabled = rbManual.Checked
            Me.Visible = True
        Catch ex As Exception

        End Try
    End Sub
    Private Sub Apply()
        For xint As Int16 = 1 To Clients.GetUpperBound(0)
            Clients(xint).GuiController.ApplyAP()
        Next
    End Sub
End Class