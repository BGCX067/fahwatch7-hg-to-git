﻿Public Class frmClosePrograms
    Private _cancel As Boolean = False, _retry As Boolean = False
    Public ReadOnly Property Canceld() As Boolean
        Get
            Return _cancel
        End Get
    End Property
    Public ReadOnly Property Retry() As Boolean
        Get
            Return _retry
        End Get
    End Property
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim rVal As MsgBoxResult = MsgBox("Cancel will revert any changes made this far, are you sure?", MsgBoxStyle.ApplicationModal + MsgBoxStyle.OkCancel)
        If rVal = MsgBoxResult.Cancel Then Exit Sub
        _cancel = True
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        _retry = True
    End Sub
End Class