﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDownloadClients
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.lblClient = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.lblDownload = New System.Windows.Forms.Label
        Me.bitsec = New System.Windows.Forms.Label
        Me.PbarDownload = New System.Windows.Forms.ProgressBar
        Me.tSpeed = New System.Windows.Forms.Timer(Me.components)
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblClient
        '
        Me.lblClient.AutoSize = True
        Me.lblClient.Location = New System.Drawing.Point(6, 54)
        Me.lblClient.Name = "lblClient"
        Me.lblClient.Size = New System.Drawing.Size(0, 13)
        Me.lblClient.TabIndex = 8
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lblClient)
        Me.GroupBox1.Controls.Add(Me.lblDownload)
        Me.GroupBox1.Controls.Add(Me.bitsec)
        Me.GroupBox1.Controls.Add(Me.PbarDownload)
        Me.GroupBox1.Location = New System.Drawing.Point(2, -2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(277, 75)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        '
        'lblDownload
        '
        Me.lblDownload.AutoSize = True
        Me.lblDownload.Location = New System.Drawing.Point(6, 37)
        Me.lblDownload.Margin = New System.Windows.Forms.Padding(3, 1, 3, 1)
        Me.lblDownload.Name = "lblDownload"
        Me.lblDownload.Size = New System.Drawing.Size(0, 13)
        Me.lblDownload.TabIndex = 6
        '
        'bitsec
        '
        Me.bitsec.Location = New System.Drawing.Point(152, 52)
        Me.bitsec.Margin = New System.Windows.Forms.Padding(3, 0, 3, 3)
        Me.bitsec.Name = "bitsec"
        Me.bitsec.Size = New System.Drawing.Size(120, 16)
        Me.bitsec.TabIndex = 5
        Me.bitsec.Text = "Bit/sec "
        Me.bitsec.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'PbarDownload
        '
        Me.PbarDownload.Location = New System.Drawing.Point(6, 14)
        Me.PbarDownload.Name = "PbarDownload"
        Me.PbarDownload.Size = New System.Drawing.Size(266, 19)
        Me.PbarDownload.TabIndex = 0
        '
        'tSpeed
        '
        Me.tSpeed.Interval = 1000
        '
        'frmDownloadClients
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(285, 79)
        Me.ControlBox = False
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "frmDownloadClients"
        Me.ShowInTaskbar = False
        Me.Text = "1132"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lblClient As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents lblDownload As System.Windows.Forms.Label
    Friend WithEvents bitsec As System.Windows.Forms.Label
    Friend WithEvents PbarDownload As System.Windows.Forms.ProgressBar
    Friend WithEvents tSpeed As System.Windows.Forms.Timer
End Class
