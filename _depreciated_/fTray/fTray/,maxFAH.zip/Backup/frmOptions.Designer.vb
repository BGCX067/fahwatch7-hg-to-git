﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOptions
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmOptions))
        Me.chkStartWithWindows = New System.Windows.Forms.CheckBox
        Me.chkMinimized = New System.Windows.Forms.CheckBox
        Me.chkStartClients = New System.Windows.Forms.CheckBox
        Me.chkHideConsoles = New System.Windows.Forms.CheckBox
        Me.chkShowHidden = New System.Windows.Forms.CheckBox
        Me.chkConfirmExit = New System.Windows.Forms.CheckBox
        Me.chkAutoDownload = New System.Windows.Forms.CheckBox
        Me.chkShowIcons = New System.Windows.Forms.CheckBox
        Me.chkBalloonTips = New System.Windows.Forms.CheckBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.cmbServiceInt = New System.Windows.Forms.ComboBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.lbNonFatal = New System.Windows.Forms.ListBox
        Me.cmdRemove = New System.Windows.Forms.Button
        Me.cmdAdd = New System.Windows.Forms.Button
        Me.txtNF = New System.Windows.Forms.TextBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.cmbEocLimit = New System.Windows.Forms.ComboBox
        Me.chkEocLimit = New System.Windows.Forms.CheckBox
        Me.llblEoc = New System.Windows.Forms.LinkLabel
        Me.cmdCancel = New System.Windows.Forms.Button
        Me.cmdSave = New System.Windows.Forms.Button
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'chkStartWithWindows
        '
        Me.chkStartWithWindows.AutoSize = True
        Me.chkStartWithWindows.Location = New System.Drawing.Point(6, 14)
        Me.chkStartWithWindows.Name = "chkStartWithWindows"
        Me.chkStartWithWindows.Size = New System.Drawing.Size(114, 17)
        Me.chkStartWithWindows.TabIndex = 0
        Me.chkStartWithWindows.Text = "Start with windows"
        Me.chkStartWithWindows.UseVisualStyleBackColor = True
        '
        'chkMinimized
        '
        Me.chkMinimized.AutoSize = True
        Me.chkMinimized.Location = New System.Drawing.Point(5, 37)
        Me.chkMinimized.Name = "chkMinimized"
        Me.chkMinimized.Size = New System.Drawing.Size(96, 17)
        Me.chkMinimized.TabIndex = 1
        Me.chkMinimized.Text = "Start minimized"
        Me.chkMinimized.UseVisualStyleBackColor = True
        '
        'chkStartClients
        '
        Me.chkStartClients.AutoSize = True
        Me.chkStartClients.Location = New System.Drawing.Point(6, 62)
        Me.chkStartClients.Name = "chkStartClients"
        Me.chkStartClients.Size = New System.Drawing.Size(172, 17)
        Me.chkStartClients.TabIndex = 2
        Me.chkStartClients.Text = "Start clients on program startup"
        Me.chkStartClients.UseVisualStyleBackColor = True
        '
        'chkHideConsoles
        '
        Me.chkHideConsoles.AutoSize = True
        Me.chkHideConsoles.Location = New System.Drawing.Point(6, 86)
        Me.chkHideConsoles.Name = "chkHideConsoles"
        Me.chkHideConsoles.Size = New System.Drawing.Size(128, 17)
        Me.chkHideConsoles.TabIndex = 3
        Me.chkHideConsoles.Text = "Start consoles hidden"
        Me.chkHideConsoles.UseVisualStyleBackColor = True
        '
        'chkShowHidden
        '
        Me.chkShowHidden.AutoSize = True
        Me.chkShowHidden.Location = New System.Drawing.Point(6, 110)
        Me.chkShowHidden.Name = "chkShowHidden"
        Me.chkShowHidden.Size = New System.Drawing.Size(167, 17)
        Me.chkShowHidden.TabIndex = 4
        Me.chkShowHidden.Text = "Show hidden consoles on exit"
        Me.chkShowHidden.UseVisualStyleBackColor = True
        '
        'chkConfirmExit
        '
        Me.chkConfirmExit.AutoSize = True
        Me.chkConfirmExit.Location = New System.Drawing.Point(6, 134)
        Me.chkConfirmExit.Name = "chkConfirmExit"
        Me.chkConfirmExit.Size = New System.Drawing.Size(80, 17)
        Me.chkConfirmExit.TabIndex = 5
        Me.chkConfirmExit.Text = "Confirm exit"
        Me.chkConfirmExit.UseVisualStyleBackColor = True
        '
        'chkAutoDownload
        '
        Me.chkAutoDownload.AutoSize = True
        Me.chkAutoDownload.Location = New System.Drawing.Point(6, 158)
        Me.chkAutoDownload.Name = "chkAutoDownload"
        Me.chkAutoDownload.Size = New System.Drawing.Size(211, 17)
        Me.chkAutoDownload.TabIndex = 6
        Me.chkAutoDownload.Text = "Download unkown projects automaticly"
        Me.chkAutoDownload.UseVisualStyleBackColor = True
        '
        'chkShowIcons
        '
        Me.chkShowIcons.AutoSize = True
        Me.chkShowIcons.Location = New System.Drawing.Point(6, 182)
        Me.chkShowIcons.Name = "chkShowIcons"
        Me.chkShowIcons.Size = New System.Drawing.Size(175, 17)
        Me.chkShowIcons.TabIndex = 7
        Me.chkShowIcons.Text = "Show client icons in system tray"
        Me.chkShowIcons.UseVisualStyleBackColor = True
        '
        'chkBalloonTips
        '
        Me.chkBalloonTips.AutoSize = True
        Me.chkBalloonTips.Location = New System.Drawing.Point(6, 206)
        Me.chkBalloonTips.Name = "chkBalloonTips"
        Me.chkBalloonTips.Size = New System.Drawing.Size(106, 17)
        Me.chkBalloonTips.TabIndex = 8
        Me.chkBalloonTips.Text = "Show balloontips"
        Me.chkBalloonTips.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(2, 229)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(161, 13)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Interval to monitor service clients"
        '
        'cmbServiceInt
        '
        Me.cmbServiceInt.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbServiceInt.FormattingEnabled = True
        Me.cmbServiceInt.Items.AddRange(New Object() {"5s", "10s", "30s", "1m", "5m", "10m"})
        Me.cmbServiceInt.Location = New System.Drawing.Point(169, 226)
        Me.cmbServiceInt.Name = "cmbServiceInt"
        Me.cmbServiceInt.Size = New System.Drawing.Size(71, 21)
        Me.cmbServiceInt.TabIndex = 10
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(8, 14)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(187, 13)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "List of non fatal CoreStatus messages:"
        '
        'lbNonFatal
        '
        Me.lbNonFatal.FormattingEnabled = True
        Me.lbNonFatal.Location = New System.Drawing.Point(11, 32)
        Me.lbNonFatal.Name = "lbNonFatal"
        Me.lbNonFatal.Size = New System.Drawing.Size(234, 69)
        Me.lbNonFatal.TabIndex = 12
        '
        'cmdRemove
        '
        Me.cmdRemove.Location = New System.Drawing.Point(11, 131)
        Me.cmdRemove.Name = "cmdRemove"
        Me.cmdRemove.Size = New System.Drawing.Size(75, 20)
        Me.cmdRemove.TabIndex = 13
        Me.cmdRemove.Text = "Remove"
        Me.cmdRemove.UseVisualStyleBackColor = True
        '
        'cmdAdd
        '
        Me.cmdAdd.Location = New System.Drawing.Point(170, 133)
        Me.cmdAdd.Name = "cmdAdd"
        Me.cmdAdd.Size = New System.Drawing.Size(75, 20)
        Me.cmdAdd.TabIndex = 14
        Me.cmdAdd.Text = "Add"
        Me.cmdAdd.UseVisualStyleBackColor = True
        '
        'txtNF
        '
        Me.txtNF.Location = New System.Drawing.Point(10, 105)
        Me.txtNF.Name = "txtNF"
        Me.txtNF.Size = New System.Drawing.Size(235, 20)
        Me.txtNF.TabIndex = 16
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.chkStartClients)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.chkStartWithWindows)
        Me.GroupBox1.Controls.Add(Me.chkMinimized)
        Me.GroupBox1.Controls.Add(Me.cmbServiceInt)
        Me.GroupBox1.Controls.Add(Me.chkHideConsoles)
        Me.GroupBox1.Controls.Add(Me.chkShowHidden)
        Me.GroupBox1.Controls.Add(Me.chkConfirmExit)
        Me.GroupBox1.Controls.Add(Me.chkAutoDownload)
        Me.GroupBox1.Controls.Add(Me.chkShowIcons)
        Me.GroupBox1.Controls.Add(Me.chkBalloonTips)
        Me.GroupBox1.Location = New System.Drawing.Point(4, -3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(252, 258)
        Me.GroupBox1.TabIndex = 17
        Me.GroupBox1.TabStop = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.lbNonFatal)
        Me.GroupBox2.Controls.Add(Me.txtNF)
        Me.GroupBox2.Controls.Add(Me.cmdAdd)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.cmdRemove)
        Me.GroupBox2.Location = New System.Drawing.Point(262, -3)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(258, 258)
        Me.GroupBox2.TabIndex = 18
        Me.GroupBox2.TabStop = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.cmbEocLimit)
        Me.GroupBox3.Controls.Add(Me.chkEocLimit)
        Me.GroupBox3.Controls.Add(Me.llblEoc)
        Me.GroupBox3.Location = New System.Drawing.Point(5, 258)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(514, 206)
        Me.GroupBox3.TabIndex = 19
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "EOC statistics options"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(236, 144)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(266, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "(Updates are with 3h interval, so 8 x 957 bytes per day)"
        '
        'cmbEocLimit
        '
        Me.cmbEocLimit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbEocLimit.FormattingEnabled = True
        Me.cmbEocLimit.Items.AddRange(New Object() {"Minimal", "One day", "One week", "One month"})
        Me.cmbEocLimit.Location = New System.Drawing.Point(94, 140)
        Me.cmbEocLimit.Name = "cmbEocLimit"
        Me.cmbEocLimit.Size = New System.Drawing.Size(135, 21)
        Me.cmbEocLimit.TabIndex = 2
        '
        'chkEocLimit
        '
        Me.chkEocLimit.AutoSize = True
        Me.chkEocLimit.Location = New System.Drawing.Point(8, 144)
        Me.chkEocLimit.Name = "chkEocLimit"
        Me.chkEocLimit.Size = New System.Drawing.Size(80, 17)
        Me.chkEocLimit.TabIndex = 1
        Me.chkEocLimit.Text = "Impose limit"
        Me.chkEocLimit.UseVisualStyleBackColor = True
        '
        'llblEoc
        '
        Me.llblEoc.LinkArea = New System.Windows.Forms.LinkArea(39, 23)
        Me.llblEoc.Location = New System.Drawing.Point(8, 20)
        Me.llblEoc.Name = "llblEoc"
        Me.llblEoc.Size = New System.Drawing.Size(495, 120)
        Me.llblEoc.TabIndex = 0
        Me.llblEoc.TabStop = True
        Me.llblEoc.Text = resources.GetString("llblEoc.Text")
        Me.llblEoc.UseCompatibleTextRendering = True
        '
        'cmdCancel
        '
        Me.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdCancel.Location = New System.Drawing.Point(4, 470)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(75, 23)
        Me.cmdCancel.TabIndex = 20
        Me.cmdCancel.Text = "&Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'cmdSave
        '
        Me.cmdSave.Location = New System.Drawing.Point(445, 470)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(75, 23)
        Me.cmdSave.TabIndex = 21
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(5, 173)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(498, 30)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "*Uploaded wu's en points in update are derived from the upload event's of work un" & _
            "its prior to the current EOC update time. "
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(8, 162)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(234, 96)
        Me.Label5.TabIndex = 17
        Me.Label5.Text = resources.GetString("Label5.Text")
        '
        'frmOptions
        '
        Me.AcceptButton = Me.cmdSave
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.cmdCancel
        Me.ClientSize = New System.Drawing.Size(525, 499)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "frmOptions"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.Text = " "
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents chkStartWithWindows As System.Windows.Forms.CheckBox
    Friend WithEvents chkMinimized As System.Windows.Forms.CheckBox
    Friend WithEvents chkStartClients As System.Windows.Forms.CheckBox
    Friend WithEvents chkHideConsoles As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowHidden As System.Windows.Forms.CheckBox
    Friend WithEvents chkConfirmExit As System.Windows.Forms.CheckBox
    Friend WithEvents chkAutoDownload As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowIcons As System.Windows.Forms.CheckBox
    Friend WithEvents chkBalloonTips As System.Windows.Forms.CheckBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmbServiceInt As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lbNonFatal As System.Windows.Forms.ListBox
    Friend WithEvents cmdRemove As System.Windows.Forms.Button
    Friend WithEvents cmdAdd As System.Windows.Forms.Button
    Friend WithEvents txtNF As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents llblEoc As System.Windows.Forms.LinkLabel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cmbEocLimit As System.Windows.Forms.ComboBox
    Friend WithEvents chkEocLimit As System.Windows.Forms.CheckBox
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
End Class
