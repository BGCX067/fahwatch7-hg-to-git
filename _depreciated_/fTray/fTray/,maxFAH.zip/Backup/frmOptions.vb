﻿Imports System.IO

Public Class frmOptions
    Private Sub frmOptions_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Try
            chkAutoDownload.Checked = mySettings.bAutoDownProjects
            chkBalloonTips.Checked = mySettings.bShowBalloonTip
            chkConfirmExit.Checked = mySettings.bConfirmExit
            chkHideConsoles.Checked = mySettings.bStartConsolesHidden
            chkMinimized.Checked = mySettings.bStartInTray
            chkShowHidden.Checked = mySettings.bShowConsolesOnExit
            chkShowIcons.Checked = mySettings.bClientIcons
            chkStartClients.Checked = mySettings.bStartClients
            chkStartWithWindows.Checked = mySettings.bStartWithWindows
            Select Case mySettings.iServiceCheckInterval
                Case Is = 5000
                    cmbServiceInt.Text = "5s"
                Case Is = 10000
                    cmbServiceInt.Text = "10s"
                Case Is = 30000
                    cmbServiceInt.Text = "30s"
                Case Is = 60000
                    cmbServiceInt.Text = "1m"
                Case Is = (60000 * 5)
                    cmbServiceInt.Text = "5m"
                Case Is = (60000 * 10)
                    cmbServiceInt.Text = "10m"
                Case Is < 5000
                    cmbServiceInt.Text = "5s"
                Case Is > 600000
                    cmbServiceInt.Text = "10m"
            End Select
            If Not mySettings.EocLimit = clsSettings.eEocLimit.None Then
                chkEocLimit.Checked = True
                Select Case mySettings.EocLimit
                    Case clsSettings.eEocLimit.Minimal
                        cmbEocLimit.Text = "Minimal"
                    Case clsSettings.eEocLimit.OneDay
                        cmbEocLimit.Text = "One day"
                    Case clsSettings.eEocLimit.OneWeek
                        cmbEocLimit.Text = "One week"
                    Case clsSettings.eEocLimit.OneMonth
                        cmbEocLimit.Text = "One month"
                End Select
                cmbEocLimit.Enabled = False
            Else
                chkEocLimit.Checked = False
                cmbEocLimit.Enabled = False
            End If
            lbNonFatal.Items.Clear()
            For Each nfStr In mySettings.NonFatal
                lbNonFatal.Items.Add(nfStr)
            Next
        Catch ex As Exception

        End Try
    End Sub

    Private Sub llblEoc_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles llblEoc.LinkClicked
        Process.Start(e.Link.ToString)
    End Sub

    Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Try
            With mySettings
                .bAutoDownProjects = chkAutoDownload.Checked
                .bClientIcons = chkShowIcons.Checked
                .bConfirmExit = chkConfirmExit.Checked
                .bShowBalloonTip = chkBalloonTips.Checked
                .bShowConsolesOnExit = chkShowHidden.Checked
                .bStartClients = chkStartClients.Checked
                .bStartConsolesHidden = chkHideConsoles.Checked
                .bStartInTray = chkMinimized.Checked
                .bStartWithWindows = chkStartWithWindows.Checked
                Select Case cmbServiceInt.Text
                    Case Is = "5s"
                        .iServiceCheckInterval = 5000
                    Case Is = "10s"
                        .iServiceCheckInterval = 10000
                    Case Is = "30s"
                        .iServiceCheckInterval = 30000
                    Case Is = "1m"
                        .iServiceCheckInterval = 60000
                    Case Is = "5m"
                        .iServiceCheckInterval = 300000
                    Case Is = "10m"
                        .iServiceCheckInterval = 600000
                End Select
                ReDim .NonFatal(0 To lbNonFatal.Items.Count - 1)
                For xInt As Int16 = 0 To lbNonFatal.Items.Count - 1
                    .NonFatal(xInt) = lbNonFatal.Items(xInt).ToString
                Next
                If chkEocLimit.Checked Then
                    Select Case cmbEocLimit.Text
                        Case Is = "Minimal"
                            .EocLimit = clsSettings.eEocLimit.Minimal
                        Case Is = "One day"
                            .EocLimit = clsSettings.eEocLimit.OneDay
                        Case Is = "One week"
                            .EocLimit = clsSettings.eEocLimit.OneWeek
                        Case Is = "One month"
                            .EocLimit = clsSettings.eEocLimit.OneMonth
                    End Select
                Else
                    .EocLimit = clsSettings.eEocLimit.None
                End If
                .SaveSettings()
            End With
            If mySettings.bClientIcons Then
                Try
                    For xint As Integer = 1 To Clients.GetUpperBound(0)
                        If Clients(xint).PandeGroup.ServiceMode Then
                            Select Case Clients(xint).GuiController.ServiceState
                                Case clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eServiceState.Err
                                    Clients(xint).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.Err)
                                Case clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eServiceState.Paused
                                    Clients(xint).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.iPause)
                                Case clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eServiceState.Running
                                    Clients(xint).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.iRun)
                                Case clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.eServiceState.Stopped
                                    Clients(xint).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.iStop)
                            End Select
                        Else
                            If Clients(xint).GuiController.Running(True) Then
                                Clients(xint).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.iRun)
                            Else
                                Clients(xint).GuiController.ShowIcon(clsClientConfiguration.clsClientConfigs.sClientSettings.sClient.clsGUIController.iState.iStop)
                            End If
                        End If
                    Next
                Catch ex As Exception
                    LogWindow.WriteError("Options form, Hide/Show client icons", Err, ex.Message)
                End Try
            Else
                For xInt As Int16 = 1 To Clients.GetUpperBound(0)
                    Clients(xInt).GuiController.HideIcon()
                Next
            End If
            Me.Close()
        Catch ex As Exception
            LogWindow.WriteError("Options form, SaveSettings", Err, ex.Message)
            MsgBox("An error occured when saving the selected settings")
        End Try
    End Sub

    Private Sub chkEocLimit_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkEocLimit.CheckedChanged
        If chkEocLimit.Checked Then
            cmbEocLimit.Enabled = True
            If cmbEocLimit.Text = "" Then
                Select Case mySettings.EocLimit
                    Case clsSettings.eEocLimit.Minimal
                        cmbEocLimit.Text = "Minimal"
                    Case clsSettings.eEocLimit.None
                        cmbEocLimit.Text = "Minimal"
                    Case clsSettings.eEocLimit.OneDay
                        cmbEocLimit.Text = "One day"
                    Case clsSettings.eEocLimit.OneWeek
                        cmbEocLimit.Text = "One week"
                    Case clsSettings.eEocLimit.OneMonth
                        cmbEocLimit.Text = "One month"
                End Select
            End If
        Else
            cmbEocLimit.Enabled = False
        End If
    End Sub

    Private Sub cmdRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdRemove.Click
        Try
            If lbNonFatal.SelectedIndex = -1 Then Exit Sub
            Dim rVal As MsgBoxResult = MsgBox("Remove - " & lbNonFatal.Items(lbNonFatal.SelectedIndex).ToString, MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Confirm removal!")
            If rVal = MsgBoxResult.No Then Exit Sub
            lbNonFatal.Items.RemoveAt(lbNonFatal.SelectedIndex)
        Catch ex As Exception
            LogWindow.WriteError("Options form, RemoveNF", Err, ex.Message)
        End Try
    End Sub

    Private Sub frmOptions_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub cmdAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
        Try
            If txtNF.TextLength = 0 Then
                txtNF.Focus()
                Exit Sub
            ElseIf Not txtNF.Text.ToUpper.Contains("CORESTATUS = ") Then
                MsgBox("Status code is not correctly formatted")
                txtNF.Focus()
                Exit Sub
            End If
            For Each nfItem As String In lbNonFatal.Items
                If nfItem.ToUpper.Contains(txtNF.Text.ToUpper) Or txtNF.Text.ToUpper.Contains(nfItem.ToUpper) Then
                    MsgBox("Duplicate status")
                    txtNF.Focus()
                    Exit Sub
                End If
            Next
            lbNonFatal.Items.Add(txtNF.Text)
        Catch ex As Exception
            LogWindow.WriteError("Options form, AddNF", Err, ex.Message)
        End Try
    End Sub
End Class