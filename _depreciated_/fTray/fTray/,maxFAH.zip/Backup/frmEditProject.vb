﻿Public Class frmEditProject
    Private _Project As clsProjectInfo.sProject
    Public Property Project() As clsProjectInfo.sProject
        Get
            Return _Project
        End Get
        Set(ByVal value As clsProjectInfo.sProject)
            _Project = value
        End Set
    End Property
    Private Sub frmEditProject_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.Alt And e.KeyCode = Keys.S Then

        ElseIf e.Alt And e.KeyCode = Keys.C Then
            Me.Close()
            If fTray.WindowState = FormWindowState.Normal Then fTray.BringToFront()
        End If
    End Sub
    Private Sub cmdUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdUpdate.Click
        With _Project
            .PreferredDays = txtPrefferdDays.Text
            .FinalDeadline = txtFinalDeadline.Text
            .Credit = txtCredit.Text
            .NumberOfAtoms = txtNOatoms.Text
            .ServerIP = txtServerIP.Text
            .Contact = txtContact.Text
            .PersonalNotes = "Edited:" & DateTime.Now.ToLongDateString & "-" & DateTime.Now.ToShortTimeString
        End With
        If Not ProjectInfo.UpdateProject(_Project) Then
            MsgBox("Edit failed for some reason?")
        End If
        Me.Close()
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Me.Close()
    End Sub

    Private Sub frmEditProject_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        With Project
            txtContact.Text = .Contact
            txtFinalDeadline.Text = .FinalDeadline
            txtCredit.Text = .Credit
            txtNOatoms.Text = .NumberOfAtoms
            txtPrefferdDays.Text = .PreferredDays
            txtServerIP.Text = .ServerIP
        End With
    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label3.Click

    End Sub

    Private Sub Label4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label4.Click

    End Sub

    Private Sub Label5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label5.Click

    End Sub

    Private Sub Label8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label8.Click

    End Sub

    Private Sub Label10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label10.Click

    End Sub

    Private Sub txtPrefferdDays_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtPrefferdDays.TextChanged

    End Sub

    Private Sub txtCredit_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCredit.TextChanged

    End Sub

    Private Sub txtFinalDeadline_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFinalDeadline.TextChanged

    End Sub

    Private Sub txtContact_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtContact.TextChanged

    End Sub

    Private Sub txtServerIP_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtServerIP.TextChanged

    End Sub

    Private Sub txtNOatoms_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtNOatoms.TextChanged

    End Sub
End Class