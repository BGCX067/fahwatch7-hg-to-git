﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("maxFAH")> 
<Assembly: AssemblyDescription("Folding@Home tool suite from MtM")> 
<Assembly: AssemblyCompany("MtM78")> 
<Assembly: AssemblyProduct("maxFAH")> 
<Assembly: AssemblyCopyright("Copyright © Marvin Westmaas")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("61d10dba-4f6d-45b1-b398-2946bbf485ff")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("0.1.0.6")> 
<Assembly: AssemblyFileVersion("0.1.0.6")> 
