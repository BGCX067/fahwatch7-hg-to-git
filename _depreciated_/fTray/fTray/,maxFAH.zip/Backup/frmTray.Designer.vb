﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTray
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmTray))
        Me.nIcon = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.tMenu = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.mnuClose = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuShow = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripSeparator
        Me.mnuStop = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuStart = New System.Windows.Forms.ToolStripMenuItem
        Me.sStrip = New System.Windows.Forms.StatusStrip
        Me.tsTime = New System.Windows.Forms.ToolStripStatusLabel
        Me.tsTotalPPD = New System.Windows.Forms.ToolStripStatusLabel
        Me.tDT = New System.Windows.Forms.Timer(Me.components)
        Me.mStrip = New System.Windows.Forms.MenuStrip
        Me.mnuMaxTray = New System.Windows.Forms.ToolStripMenuItem
        Me.TestOptionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuExtend = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.mnuMinimize = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuExit = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuClients = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem7 = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuAllStart = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuAllStop = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuAllShow = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuAllHide = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuStopWhenDone = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuStopOnFrame = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuPFmanager = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.mnuRefreshAll = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuProjects = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuProjectBrowser = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuPlist = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuDownloadProjects = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuWeb = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuUpdates = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripSeparator
        Me.mnuFoldingForum = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuEOC_forum = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuEOC_Stats = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuStatistics = New System.Windows.Forms.ToolStripMenuItem
        Me.DebugToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ResizeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.scMain = New System.Windows.Forms.SplitContainer
        Me.scClLo = New System.Windows.Forms.SplitContainer
        Me.lvC = New System.Windows.Forms.ListView
        Me.cName = New System.Windows.Forms.ColumnHeader
        Me.cWU = New System.Windows.Forms.ColumnHeader
        Me.cmCore = New System.Windows.Forms.ColumnHeader
        Me.cProgress = New System.Windows.Forms.ColumnHeader
        Me.cPPD = New System.Windows.Forms.ColumnHeader
        Me.cmEffective = New System.Windows.Forms.ColumnHeader
        Me.cmPointsUpdate = New System.Windows.Forms.ColumnHeader
        Me.cmEUE = New System.Windows.Forms.ColumnHeader
        Me.cmWUsReady = New System.Windows.Forms.ColumnHeader
        Me.cWindow = New System.Windows.Forms.ColumnHeader
        Me.iList = New System.Windows.Forms.ImageList(Me.components)
        Me.spLogPGB = New System.Windows.Forms.SplitContainer
        Me.rtLOG = New System.Windows.Forms.RichTextBox
        Me.tPB = New System.Windows.Forms.ProgressBar
        Me.lbl3Frames = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.lblAllFrames = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.lbl24HAverage = New System.Windows.Forms.Label
        Me.lblPointsToday = New System.Windows.Forms.Label
        Me.lblProcessedWU = New System.Windows.Forms.Label
        Me.lblPointsUpdate = New System.Windows.Forms.Label
        Me.lblEocUpdate = New System.Windows.Forms.Label
        Me.Label27 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.gbClient = New System.Windows.Forms.GroupBox
        Me.lblWUReady = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.lblUploaded = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.lblStuckUploads = New System.Windows.Forms.Label
        Me.lblPFraction = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.llblTeam = New System.Windows.Forms.LinkLabel
        Me.llblName = New System.Windows.Forms.LinkLabel
        Me.Label12 = New System.Windows.Forms.Label
        Me.llblWU = New System.Windows.Forms.LinkLabel
        Me.lblRemaining = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.lblProject = New System.Windows.Forms.Label
        Me.lblProgress = New System.Windows.Forms.Label
        Me.Label45 = New System.Windows.Forms.Label
        Me.lblCFrameTime = New System.Windows.Forms.Label
        Me.Label44 = New System.Windows.Forms.Label
        Me.lblExpires = New System.Windows.Forms.Label
        Me.lblCore = New System.Windows.Forms.Label
        Me.lblAtoms = New System.Windows.Forms.Label
        Me.lblPoints = New System.Windows.Forms.Label
        Me.lblPPD = New System.Windows.Forms.Label
        Me.lblEta = New System.Windows.Forms.Label
        Me.lblDue = New System.Windows.Forms.Label
        Me.lblIssued = New System.Windows.Forms.Label
        Me.Worth = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.Label31 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label40 = New System.Windows.Forms.Label
        Me.Label41 = New System.Windows.Forms.Label
        Me.tUpdateClients = New System.Windows.Forms.Timer(Me.components)
        Me.tLogTimeout = New System.Windows.Forms.Timer(Me.components)
        Me.tQueueTimeout = New System.Windows.Forms.Timer(Me.components)
        Me.tMenu.SuspendLayout()
        Me.sStrip.SuspendLayout()
        Me.mStrip.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.scMain.Panel1.SuspendLayout()
        Me.scMain.Panel2.SuspendLayout()
        Me.scMain.SuspendLayout()
        Me.scClLo.Panel1.SuspendLayout()
        Me.scClLo.Panel2.SuspendLayout()
        Me.scClLo.SuspendLayout()
        Me.spLogPGB.Panel1.SuspendLayout()
        Me.spLogPGB.Panel2.SuspendLayout()
        Me.spLogPGB.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.gbClient.SuspendLayout()
        Me.SuspendLayout()
        '
        'nIcon
        '
        Me.nIcon.ContextMenuStrip = Me.tMenu
        Me.nIcon.Icon = CType(resources.GetObject("nIcon.Icon"), System.Drawing.Icon)
        Me.nIcon.Text = "maxTray"
        '
        'tMenu
        '
        Me.tMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuClose, Me.mnuShow, Me.ToolStripMenuItem4, Me.mnuStop, Me.mnuStart})
        Me.tMenu.Name = "tMenu"
        Me.tMenu.Size = New System.Drawing.Size(114, 98)
        '
        'mnuClose
        '
        Me.mnuClose.Name = "mnuClose"
        Me.mnuClose.Size = New System.Drawing.Size(113, 22)
        Me.mnuClose.Text = "Close"
        '
        'mnuShow
        '
        Me.mnuShow.Name = "mnuShow"
        Me.mnuShow.Size = New System.Drawing.Size(113, 22)
        Me.mnuShow.Text = "Show"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(110, 6)
        '
        'mnuStop
        '
        Me.mnuStop.Name = "mnuStop"
        Me.mnuStop.Size = New System.Drawing.Size(113, 22)
        Me.mnuStop.Text = "Stop all"
        '
        'mnuStart
        '
        Me.mnuStart.Name = "mnuStart"
        Me.mnuStart.Size = New System.Drawing.Size(113, 22)
        Me.mnuStart.Text = "Start all"
        '
        'sStrip
        '
        Me.sStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsTime, Me.tsTotalPPD})
        Me.sStrip.Location = New System.Drawing.Point(0, 639)
        Me.sStrip.Name = "sStrip"
        Me.sStrip.Size = New System.Drawing.Size(1221, 22)
        Me.sStrip.SizingGrip = False
        Me.sStrip.TabIndex = 2
        '
        'tsTime
        '
        Me.tsTime.Name = "tsTime"
        Me.tsTime.Size = New System.Drawing.Size(0, 17)
        '
        'tsTotalPPD
        '
        Me.tsTotalPPD.AutoSize = False
        Me.tsTotalPPD.BorderStyle = System.Windows.Forms.Border3DStyle.RaisedOuter
        Me.tsTotalPPD.Name = "tsTotalPPD"
        Me.tsTotalPPD.Size = New System.Drawing.Size(1206, 17)
        Me.tsTotalPPD.Spring = True
        Me.tsTotalPPD.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tDT
        '
        Me.tDT.Interval = 1000
        '
        'mStrip
        '
        Me.mStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuMaxTray, Me.mnuClients, Me.mnuProjects, Me.mnuWeb, Me.mnuStatistics, Me.DebugToolStripMenuItem, Me.ResizeToolStripMenuItem})
        Me.mStrip.Location = New System.Drawing.Point(0, 0)
        Me.mStrip.Name = "mStrip"
        Me.mStrip.Size = New System.Drawing.Size(1221, 24)
        Me.mStrip.TabIndex = 3
        '
        'mnuMaxTray
        '
        Me.mnuMaxTray.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TestOptionsToolStripMenuItem, Me.mnuExtend, Me.ToolStripSeparator2, Me.mnuMinimize, Me.mnuExit})
        Me.mnuMaxTray.Name = "mnuMaxTray"
        Me.mnuMaxTray.Size = New System.Drawing.Size(64, 20)
        Me.mnuMaxTray.Text = "maxTray"
        '
        'TestOptionsToolStripMenuItem
        '
        Me.TestOptionsToolStripMenuItem.Name = "TestOptionsToolStripMenuItem"
        Me.TestOptionsToolStripMenuItem.Size = New System.Drawing.Size(131, 22)
        Me.TestOptionsToolStripMenuItem.Text = "Options"
        '
        'mnuExtend
        '
        Me.mnuExtend.CheckOnClick = True
        Me.mnuExtend.Name = "mnuExtend"
        Me.mnuExtend.Size = New System.Drawing.Size(131, 22)
        Me.mnuExtend.Text = "Switch GUI"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(128, 6)
        '
        'mnuMinimize
        '
        Me.mnuMinimize.Name = "mnuMinimize"
        Me.mnuMinimize.Size = New System.Drawing.Size(131, 22)
        Me.mnuMinimize.Text = "Minimize"
        '
        'mnuExit
        '
        Me.mnuExit.Name = "mnuExit"
        Me.mnuExit.Size = New System.Drawing.Size(131, 22)
        Me.mnuExit.Text = "Exit"
        '
        'mnuClients
        '
        Me.mnuClients.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem7, Me.mnuPFmanager, Me.ToolStripMenuItem1, Me.ToolStripSeparator1, Me.mnuRefreshAll})
        Me.mnuClients.Name = "mnuClients"
        Me.mnuClients.Size = New System.Drawing.Size(55, 20)
        Me.mnuClients.Text = "Clients"
        '
        'ToolStripMenuItem7
        '
        Me.ToolStripMenuItem7.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuAllStart, Me.mnuAllStop, Me.mnuAllShow, Me.mnuAllHide, Me.mnuStopWhenDone, Me.mnuStopOnFrame})
        Me.ToolStripMenuItem7.Name = "ToolStripMenuItem7"
        Me.ToolStripMenuItem7.Size = New System.Drawing.Size(217, 22)
        Me.ToolStripMenuItem7.Text = "All clients ->"
        '
        'mnuAllStart
        '
        Me.mnuAllStart.Name = "mnuAllStart"
        Me.mnuAllStart.Size = New System.Drawing.Size(224, 22)
        Me.mnuAllStart.Text = "Start"
        '
        'mnuAllStop
        '
        Me.mnuAllStop.Name = "mnuAllStop"
        Me.mnuAllStop.Size = New System.Drawing.Size(224, 22)
        Me.mnuAllStop.Text = "Stop"
        '
        'mnuAllShow
        '
        Me.mnuAllShow.Name = "mnuAllShow"
        Me.mnuAllShow.Size = New System.Drawing.Size(224, 22)
        Me.mnuAllShow.Text = "Show"
        '
        'mnuAllHide
        '
        Me.mnuAllHide.Name = "mnuAllHide"
        Me.mnuAllHide.Size = New System.Drawing.Size(224, 22)
        Me.mnuAllHide.Text = "Hide"
        '
        'mnuStopWhenDone
        '
        Me.mnuStopWhenDone.CheckOnClick = True
        Me.mnuStopWhenDone.Name = "mnuStopWhenDone"
        Me.mnuStopWhenDone.Size = New System.Drawing.Size(224, 22)
        Me.mnuStopWhenDone.Text = "Stop when WU completes"
        '
        'mnuStopOnFrame
        '
        Me.mnuStopOnFrame.CheckOnClick = True
        Me.mnuStopOnFrame.Name = "mnuStopOnFrame"
        Me.mnuStopOnFrame.Size = New System.Drawing.Size(224, 22)
        Me.mnuStopOnFrame.Text = "Stop when Frame completes"
        '
        'mnuPFmanager
        '
        Me.mnuPFmanager.Name = "mnuPFmanager"
        Me.mnuPFmanager.Size = New System.Drawing.Size(217, 22)
        Me.mnuPFmanager.Text = "Affinity && priority manager"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(217, 22)
        Me.ToolStripMenuItem1.Text = "Add\Remove clients"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(214, 6)
        '
        'mnuRefreshAll
        '
        Me.mnuRefreshAll.Name = "mnuRefreshAll"
        Me.mnuRefreshAll.Size = New System.Drawing.Size(217, 22)
        Me.mnuRefreshAll.Text = "Manual refresh"
        '
        'mnuProjects
        '
        Me.mnuProjects.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuProjectBrowser, Me.mnuPlist, Me.mnuDownloadProjects})
        Me.mnuProjects.Name = "mnuProjects"
        Me.mnuProjects.Size = New System.Drawing.Size(61, 20)
        Me.mnuProjects.Text = "Projects"
        '
        'mnuProjectBrowser
        '
        Me.mnuProjectBrowser.Name = "mnuProjectBrowser"
        Me.mnuProjectBrowser.Size = New System.Drawing.Size(198, 22)
        Me.mnuProjectBrowser.Text = "Simple project browser"
        '
        'mnuPlist
        '
        Me.mnuPlist.Name = "mnuPlist"
        Me.mnuPlist.Size = New System.Drawing.Size(198, 22)
        Me.mnuPlist.Text = "Project list"
        '
        'mnuDownloadProjects
        '
        Me.mnuDownloadProjects.Name = "mnuDownloadProjects"
        Me.mnuDownloadProjects.Size = New System.Drawing.Size(198, 22)
        Me.mnuDownloadProjects.Text = "Download new projects"
        '
        'mnuWeb
        '
        Me.mnuWeb.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuUpdates, Me.ToolStripMenuItem3, Me.mnuFoldingForum, Me.mnuEOC_forum, Me.mnuEOC_Stats})
        Me.mnuWeb.Name = "mnuWeb"
        Me.mnuWeb.Size = New System.Drawing.Size(43, 20)
        Me.mnuWeb.Text = "Web"
        '
        'mnuUpdates
        '
        Me.mnuUpdates.Name = "mnuUpdates"
        Me.mnuUpdates.Size = New System.Drawing.Size(179, 22)
        Me.mnuUpdates.Text = "Check for updates"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(176, 6)
        '
        'mnuFoldingForum
        '
        Me.mnuFoldingForum.Name = "mnuFoldingForum"
        Me.mnuFoldingForum.Size = New System.Drawing.Size(179, 22)
        Me.mnuFoldingForum.Text = "Folding forum"
        '
        'mnuEOC_forum
        '
        Me.mnuEOC_forum.Name = "mnuEOC_forum"
        Me.mnuEOC_forum.Size = New System.Drawing.Size(179, 22)
        Me.mnuEOC_forum.Text = "EOC folding section"
        '
        'mnuEOC_Stats
        '
        Me.mnuEOC_Stats.Name = "mnuEOC_Stats"
        Me.mnuEOC_Stats.Size = New System.Drawing.Size(179, 22)
        Me.mnuEOC_Stats.Text = "EOC Folding Stats"
        '
        'mnuStatistics
        '
        Me.mnuStatistics.Name = "mnuStatistics"
        Me.mnuStatistics.Size = New System.Drawing.Size(65, 20)
        Me.mnuStatistics.Text = "Statistics"
        '
        'DebugToolStripMenuItem
        '
        Me.DebugToolStripMenuItem.Name = "DebugToolStripMenuItem"
        Me.DebugToolStripMenuItem.Size = New System.Drawing.Size(54, 20)
        Me.DebugToolStripMenuItem.Text = "Debug"
        '
        'ResizeToolStripMenuItem
        '
        Me.ResizeToolStripMenuItem.Name = "ResizeToolStripMenuItem"
        Me.ResizeToolStripMenuItem.Size = New System.Drawing.Size(51, 20)
        Me.ResizeToolStripMenuItem.Text = "Resize"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.scMain)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 24)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1221, 615)
        Me.Panel1.TabIndex = 4
        '
        'scMain
        '
        Me.scMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.scMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.scMain.IsSplitterFixed = True
        Me.scMain.Location = New System.Drawing.Point(0, 0)
        Me.scMain.Name = "scMain"
        '
        'scMain.Panel1
        '
        Me.scMain.Panel1.Controls.Add(Me.scClLo)
        Me.scMain.Panel1MinSize = 1
        '
        'scMain.Panel2
        '
        Me.scMain.Panel2.Controls.Add(Me.lbl3Frames)
        Me.scMain.Panel2.Controls.Add(Me.Label3)
        Me.scMain.Panel2.Controls.Add(Me.lblAllFrames)
        Me.scMain.Panel2.Controls.Add(Me.GroupBox1)
        Me.scMain.Panel2.Controls.Add(Me.gbClient)
        Me.scMain.Panel2.Controls.Add(Me.llblTeam)
        Me.scMain.Panel2.Controls.Add(Me.llblName)
        Me.scMain.Panel2.Controls.Add(Me.Label12)
        Me.scMain.Panel2.Controls.Add(Me.llblWU)
        Me.scMain.Panel2.Controls.Add(Me.lblRemaining)
        Me.scMain.Panel2.Controls.Add(Me.Label7)
        Me.scMain.Panel2.Controls.Add(Me.Label11)
        Me.scMain.Panel2.Controls.Add(Me.lblProject)
        Me.scMain.Panel2.Controls.Add(Me.lblProgress)
        Me.scMain.Panel2.Controls.Add(Me.Label45)
        Me.scMain.Panel2.Controls.Add(Me.lblCFrameTime)
        Me.scMain.Panel2.Controls.Add(Me.Label44)
        Me.scMain.Panel2.Controls.Add(Me.lblExpires)
        Me.scMain.Panel2.Controls.Add(Me.lblCore)
        Me.scMain.Panel2.Controls.Add(Me.lblAtoms)
        Me.scMain.Panel2.Controls.Add(Me.lblPoints)
        Me.scMain.Panel2.Controls.Add(Me.lblPPD)
        Me.scMain.Panel2.Controls.Add(Me.lblEta)
        Me.scMain.Panel2.Controls.Add(Me.lblDue)
        Me.scMain.Panel2.Controls.Add(Me.lblIssued)
        Me.scMain.Panel2.Controls.Add(Me.Worth)
        Me.scMain.Panel2.Controls.Add(Me.Label10)
        Me.scMain.Panel2.Controls.Add(Me.Label4)
        Me.scMain.Panel2.Controls.Add(Me.Label9)
        Me.scMain.Panel2.Controls.Add(Me.Label13)
        Me.scMain.Panel2.Controls.Add(Me.Label20)
        Me.scMain.Panel2.Controls.Add(Me.Label21)
        Me.scMain.Panel2.Controls.Add(Me.Label22)
        Me.scMain.Panel2.Controls.Add(Me.Label23)
        Me.scMain.Panel2.Controls.Add(Me.Label24)
        Me.scMain.Panel2.Controls.Add(Me.Label25)
        Me.scMain.Panel2.Controls.Add(Me.Label26)
        Me.scMain.Panel2.Controls.Add(Me.Label31)
        Me.scMain.Panel2.Controls.Add(Me.Label6)
        Me.scMain.Panel2.Controls.Add(Me.Label40)
        Me.scMain.Panel2.Controls.Add(Me.Label41)
        Me.scMain.Panel2MinSize = 1
        Me.scMain.Size = New System.Drawing.Size(1221, 615)
        Me.scMain.SplitterDistance = 884
        Me.scMain.SplitterWidth = 1
        Me.scMain.TabIndex = 7
        '
        'scClLo
        '
        Me.scClLo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.scClLo.Dock = System.Windows.Forms.DockStyle.Fill
        Me.scClLo.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.scClLo.IsSplitterFixed = True
        Me.scClLo.Location = New System.Drawing.Point(0, 0)
        Me.scClLo.Name = "scClLo"
        Me.scClLo.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'scClLo.Panel1
        '
        Me.scClLo.Panel1.AutoScroll = True
        Me.scClLo.Panel1.Controls.Add(Me.lvC)
        Me.scClLo.Panel1MinSize = 1
        '
        'scClLo.Panel2
        '
        Me.scClLo.Panel2.AutoScroll = True
        Me.scClLo.Panel2.Controls.Add(Me.spLogPGB)
        Me.scClLo.Panel2MinSize = 150
        Me.scClLo.Size = New System.Drawing.Size(880, 611)
        Me.scClLo.SplitterDistance = 242
        Me.scClLo.SplitterWidth = 1
        Me.scClLo.TabIndex = 5
        '
        'lvC
        '
        Me.lvC.Activation = System.Windows.Forms.ItemActivation.OneClick
        Me.lvC.AllowColumnReorder = True
        Me.lvC.BackColor = System.Drawing.Color.Gainsboro
        Me.lvC.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lvC.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.cName, Me.cWU, Me.cmCore, Me.cProgress, Me.cPPD, Me.cmEffective, Me.cmPointsUpdate, Me.cmEUE, Me.cmWUsReady, Me.cWindow})
        Me.lvC.Cursor = System.Windows.Forms.Cursors.Default
        Me.lvC.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lvC.FullRowSelect = True
        Me.lvC.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.lvC.Location = New System.Drawing.Point(0, 0)
        Me.lvC.MultiSelect = False
        Me.lvC.Name = "lvC"
        Me.lvC.Size = New System.Drawing.Size(878, 240)
        Me.lvC.SmallImageList = Me.iList
        Me.lvC.TabIndex = 3
        Me.lvC.UseCompatibleStateImageBehavior = False
        Me.lvC.View = System.Windows.Forms.View.Details
        '
        'cName
        '
        Me.cName.Text = "Client"
        Me.cName.Width = 200
        '
        'cWU
        '
        Me.cWU.Text = "Work unit"
        Me.cWU.Width = 200
        '
        'cmCore
        '
        Me.cmCore.Text = "Fahcore"
        Me.cmCore.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.cmCore.Width = 200
        '
        'cProgress
        '
        Me.cProgress.Text = "Progress"
        Me.cProgress.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.cProgress.Width = 54
        '
        'cPPD
        '
        Me.cPPD.Text = "PPD Last Frame"
        Me.cPPD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.cPPD.Width = 66
        '
        'cmEffective
        '
        Me.cmEffective.Text = "Effective PPD"
        Me.cmEffective.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'cmPointsUpdate
        '
        Me.cmPointsUpdate.Text = "Points in update"
        Me.cmPointsUpdate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'cmEUE
        '
        Me.cmEUE.Text = "# EUE's"
        Me.cmEUE.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'cmWUsReady
        '
        Me.cmWUsReady.Text = "WU's ready"
        Me.cmWUsReady.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'cWindow
        '
        Me.cWindow.Text = "Console"
        Me.cWindow.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.cWindow.Width = 5
        '
        'iList
        '
        Me.iList.ImageStream = CType(resources.GetObject("iList.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.iList.TransparentColor = System.Drawing.Color.Transparent
        Me.iList.Images.SetKeyName(0, "GREEN")
        Me.iList.Images.SetKeyName(1, "YELLOW")
        Me.iList.Images.SetKeyName(2, "RED")
        '
        'spLogPGB
        '
        Me.spLogPGB.Dock = System.Windows.Forms.DockStyle.Fill
        Me.spLogPGB.FixedPanel = System.Windows.Forms.FixedPanel.Panel2
        Me.spLogPGB.Location = New System.Drawing.Point(0, 0)
        Me.spLogPGB.Name = "spLogPGB"
        Me.spLogPGB.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'spLogPGB.Panel1
        '
        Me.spLogPGB.Panel1.Controls.Add(Me.rtLOG)
        Me.spLogPGB.Panel1MinSize = 0
        '
        'spLogPGB.Panel2
        '
        Me.spLogPGB.Panel2.Controls.Add(Me.tPB)
        Me.spLogPGB.Panel2MinSize = 20
        Me.spLogPGB.Size = New System.Drawing.Size(878, 366)
        Me.spLogPGB.SplitterDistance = 345
        Me.spLogPGB.SplitterWidth = 1
        Me.spLogPGB.TabIndex = 0
        '
        'rtLOG
        '
        Me.rtLOG.Dock = System.Windows.Forms.DockStyle.Fill
        Me.rtLOG.Location = New System.Drawing.Point(0, 0)
        Me.rtLOG.Name = "rtLOG"
        Me.rtLOG.ReadOnly = True
        Me.rtLOG.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical
        Me.rtLOG.Size = New System.Drawing.Size(878, 345)
        Me.rtLOG.TabIndex = 5
        Me.rtLOG.Text = ""
        '
        'tPB
        '
        Me.tPB.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tPB.Location = New System.Drawing.Point(0, 0)
        Me.tPB.Name = "tPB"
        Me.tPB.Size = New System.Drawing.Size(878, 20)
        Me.tPB.TabIndex = 6
        '
        'lbl3Frames
        '
        Me.lbl3Frames.AutoSize = True
        Me.lbl3Frames.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl3Frames.Cursor = System.Windows.Forms.Cursors.Default
        Me.lbl3Frames.Location = New System.Drawing.Point(105, 245)
        Me.lbl3Frames.Name = "lbl3Frames"
        Me.lbl3Frames.Size = New System.Drawing.Size(2, 15)
        Me.lbl3Frames.TabIndex = 57
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(14, 247)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(73, 13)
        Me.Label3.TabIndex = 56
        Me.Label3.Text = "Frametime (3):"
        '
        'lblAllFrames
        '
        Me.lblAllFrames.AutoSize = True
        Me.lblAllFrames.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAllFrames.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblAllFrames.Location = New System.Drawing.Point(105, 268)
        Me.lblAllFrames.Name = "lblAllFrames"
        Me.lblAllFrames.Size = New System.Drawing.Size(2, 15)
        Me.lblAllFrames.TabIndex = 60
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lbl24HAverage)
        Me.GroupBox1.Controls.Add(Me.lblPointsToday)
        Me.GroupBox1.Controls.Add(Me.lblProcessedWU)
        Me.GroupBox1.Controls.Add(Me.lblPointsUpdate)
        Me.GroupBox1.Controls.Add(Me.lblEocUpdate)
        Me.GroupBox1.Controls.Add(Me.Label27)
        Me.GroupBox1.Controls.Add(Me.Label19)
        Me.GroupBox1.Controls.Add(Me.Label18)
        Me.GroupBox1.Controls.Add(Me.Label17)
        Me.GroupBox1.Controls.Add(Me.Label16)
        Me.GroupBox1.Location = New System.Drawing.Point(17, 471)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(305, 129)
        Me.GroupBox1.TabIndex = 63
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "EOC Stats"
        '
        'lbl24HAverage
        '
        Me.lbl24HAverage.AutoSize = True
        Me.lbl24HAverage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbl24HAverage.Location = New System.Drawing.Point(118, 111)
        Me.lbl24HAverage.Name = "lbl24HAverage"
        Me.lbl24HAverage.Size = New System.Drawing.Size(2, 15)
        Me.lbl24HAverage.TabIndex = 9
        '
        'lblPointsToday
        '
        Me.lblPointsToday.AutoSize = True
        Me.lblPointsToday.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPointsToday.Location = New System.Drawing.Point(118, 88)
        Me.lblPointsToday.Name = "lblPointsToday"
        Me.lblPointsToday.Size = New System.Drawing.Size(2, 15)
        Me.lblPointsToday.TabIndex = 8
        '
        'lblProcessedWU
        '
        Me.lblProcessedWU.AutoSize = True
        Me.lblProcessedWU.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblProcessedWU.Location = New System.Drawing.Point(118, 66)
        Me.lblProcessedWU.Name = "lblProcessedWU"
        Me.lblProcessedWU.Size = New System.Drawing.Size(2, 15)
        Me.lblProcessedWU.TabIndex = 7
        '
        'lblPointsUpdate
        '
        Me.lblPointsUpdate.AutoSize = True
        Me.lblPointsUpdate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPointsUpdate.Location = New System.Drawing.Point(118, 43)
        Me.lblPointsUpdate.Name = "lblPointsUpdate"
        Me.lblPointsUpdate.Size = New System.Drawing.Size(2, 15)
        Me.lblPointsUpdate.TabIndex = 6
        '
        'lblEocUpdate
        '
        Me.lblEocUpdate.AutoSize = True
        Me.lblEocUpdate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEocUpdate.Location = New System.Drawing.Point(118, 20)
        Me.lblEocUpdate.Name = "lblEocUpdate"
        Me.lblEocUpdate.Size = New System.Drawing.Size(2, 15)
        Me.lblEocUpdate.TabIndex = 5
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(12, 111)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(67, 13)
        Me.Label27.TabIndex = 4
        Me.Label27.Text = "24h average"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(12, 88)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(68, 13)
        Me.Label19.TabIndex = 3
        Me.Label19.Text = "Points today:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(10, 66)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(89, 13)
        Me.Label18.TabIndex = 2
        Me.Label18.Text = "Processed WU's:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(10, 43)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(86, 13)
        Me.Label17.TabIndex = 1
        Me.Label17.Text = "Points in update:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(10, 20)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(45, 13)
        Me.Label16.TabIndex = 0
        Me.Label16.Text = "Update:"
        '
        'gbClient
        '
        Me.gbClient.Controls.Add(Me.lblWUReady)
        Me.gbClient.Controls.Add(Me.Label15)
        Me.gbClient.Controls.Add(Me.lblUploaded)
        Me.gbClient.Controls.Add(Me.Label14)
        Me.gbClient.Controls.Add(Me.lblStuckUploads)
        Me.gbClient.Controls.Add(Me.lblPFraction)
        Me.gbClient.Controls.Add(Me.Label5)
        Me.gbClient.Controls.Add(Me.Label1)
        Me.gbClient.Location = New System.Drawing.Point(14, 333)
        Me.gbClient.Name = "gbClient"
        Me.gbClient.Size = New System.Drawing.Size(308, 131)
        Me.gbClient.TabIndex = 62
        Me.gbClient.TabStop = False
        Me.gbClient.Text = "Client"
        '
        'lblWUReady
        '
        Me.lblWUReady.AutoSize = True
        Me.lblWUReady.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblWUReady.Location = New System.Drawing.Point(124, 51)
        Me.lblWUReady.Name = "lblWUReady"
        Me.lblWUReady.Size = New System.Drawing.Size(2, 15)
        Me.lblWUReady.TabIndex = 7
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(10, 51)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(103, 13)
        Me.Label15.TabIndex = 6
        Me.Label15.Text = "WU's ready to send:"
        '
        'lblUploaded
        '
        Me.lblUploaded.AutoSize = True
        Me.lblUploaded.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblUploaded.Location = New System.Drawing.Point(162, 100)
        Me.lblUploaded.Name = "lblUploaded"
        Me.lblUploaded.Size = New System.Drawing.Size(2, 15)
        Me.lblUploaded.TabIndex = 5
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(10, 100)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(146, 13)
        Me.Label14.TabIndex = 4
        Me.Label14.Text = "Uploaded wu's in last update:"
        '
        'lblStuckUploads
        '
        Me.lblStuckUploads.AutoSize = True
        Me.lblStuckUploads.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblStuckUploads.Location = New System.Drawing.Point(124, 75)
        Me.lblStuckUploads.Name = "lblStuckUploads"
        Me.lblStuckUploads.Size = New System.Drawing.Size(2, 15)
        Me.lblStuckUploads.TabIndex = 3
        '
        'lblPFraction
        '
        Me.lblPFraction.AutoSize = True
        Me.lblPFraction.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPFraction.Location = New System.Drawing.Point(124, 25)
        Me.lblPFraction.Name = "lblPFraction"
        Me.lblPFraction.Size = New System.Drawing.Size(2, 15)
        Me.lblPFraction.TabIndex = 2
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(10, 75)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(77, 13)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "Uploadfailures:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(10, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(108, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Performance fraction:"
        '
        'llblTeam
        '
        Me.llblTeam.AutoSize = True
        Me.llblTeam.Location = New System.Drawing.Point(43, 9)
        Me.llblTeam.Name = "llblTeam"
        Me.llblTeam.Size = New System.Drawing.Size(0, 13)
        Me.llblTeam.TabIndex = 55
        '
        'llblName
        '
        Me.llblName.AutoSize = True
        Me.llblName.Location = New System.Drawing.Point(7, 9)
        Me.llblName.Name = "llblName"
        Me.llblName.Size = New System.Drawing.Size(0, 13)
        Me.llblName.TabIndex = 54
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(14, 269)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(77, 13)
        Me.Label12.TabIndex = 59
        Me.Label12.Text = "Frametime (all):"
        '
        'llblWU
        '
        Me.llblWU.AutoSize = True
        Me.llblWU.Location = New System.Drawing.Point(7, 33)
        Me.llblWU.Name = "llblWU"
        Me.llblWU.Size = New System.Drawing.Size(56, 13)
        Me.llblWU.TabIndex = 52
        Me.llblWU.TabStop = True
        Me.llblWU.Text = "Work unit:"
        '
        'lblRemaining
        '
        Me.lblRemaining.AutoSize = True
        Me.lblRemaining.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRemaining.Location = New System.Drawing.Point(105, 204)
        Me.lblRemaining.Name = "lblRemaining"
        Me.lblRemaining.Size = New System.Drawing.Size(2, 15)
        Me.lblRemaining.TabIndex = 49
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(14, 205)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(60, 13)
        Me.Label7.TabIndex = 48
        Me.Label7.Text = "Remaining:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label11.Location = New System.Drawing.Point(105, 204)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(2, 15)
        Me.Label11.TabIndex = 50
        '
        'lblProject
        '
        Me.lblProject.AutoSize = True
        Me.lblProject.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblProject.Location = New System.Drawing.Point(69, 33)
        Me.lblProject.Name = "lblProject"
        Me.lblProject.Size = New System.Drawing.Size(2, 15)
        Me.lblProject.TabIndex = 46
        '
        'lblProgress
        '
        Me.lblProgress.AutoSize = True
        Me.lblProgress.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblProgress.Location = New System.Drawing.Point(105, 290)
        Me.lblProgress.Name = "lblProgress"
        Me.lblProgress.Size = New System.Drawing.Size(2, 15)
        Me.lblProgress.TabIndex = 44
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(14, 291)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(51, 13)
        Me.Label45.TabIndex = 43
        Me.Label45.Text = "Progress:"
        '
        'lblCFrameTime
        '
        Me.lblCFrameTime.AutoSize = True
        Me.lblCFrameTime.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCFrameTime.Location = New System.Drawing.Point(105, 225)
        Me.lblCFrameTime.Name = "lblCFrameTime"
        Me.lblCFrameTime.Size = New System.Drawing.Size(2, 15)
        Me.lblCFrameTime.TabIndex = 41
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(14, 226)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(76, 13)
        Me.Label44.TabIndex = 40
        Me.Label44.Text = "Frame time (c):"
        '
        'lblExpires
        '
        Me.lblExpires.AutoSize = True
        Me.lblExpires.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblExpires.Location = New System.Drawing.Point(105, 162)
        Me.lblExpires.Name = "lblExpires"
        Me.lblExpires.Size = New System.Drawing.Size(2, 15)
        Me.lblExpires.TabIndex = 38
        '
        'lblCore
        '
        Me.lblCore.AutoSize = True
        Me.lblCore.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCore.Location = New System.Drawing.Point(105, 57)
        Me.lblCore.Name = "lblCore"
        Me.lblCore.Size = New System.Drawing.Size(2, 15)
        Me.lblCore.TabIndex = 34
        '
        'lblAtoms
        '
        Me.lblAtoms.AutoSize = True
        Me.lblAtoms.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAtoms.Location = New System.Drawing.Point(105, 78)
        Me.lblAtoms.Name = "lblAtoms"
        Me.lblAtoms.Size = New System.Drawing.Size(2, 15)
        Me.lblAtoms.TabIndex = 33
        '
        'lblPoints
        '
        Me.lblPoints.AutoSize = True
        Me.lblPoints.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPoints.Location = New System.Drawing.Point(105, 99)
        Me.lblPoints.Name = "lblPoints"
        Me.lblPoints.Size = New System.Drawing.Size(2, 15)
        Me.lblPoints.TabIndex = 32
        '
        'lblPPD
        '
        Me.lblPPD.AutoSize = True
        Me.lblPPD.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPPD.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblPPD.Location = New System.Drawing.Point(105, 311)
        Me.lblPPD.Name = "lblPPD"
        Me.lblPPD.Size = New System.Drawing.Size(2, 15)
        Me.lblPPD.TabIndex = 31
        '
        'lblEta
        '
        Me.lblEta.AutoSize = True
        Me.lblEta.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEta.Location = New System.Drawing.Point(105, 183)
        Me.lblEta.Name = "lblEta"
        Me.lblEta.Size = New System.Drawing.Size(2, 15)
        Me.lblEta.TabIndex = 30
        '
        'lblDue
        '
        Me.lblDue.AutoSize = True
        Me.lblDue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDue.Location = New System.Drawing.Point(105, 141)
        Me.lblDue.Name = "lblDue"
        Me.lblDue.Size = New System.Drawing.Size(2, 15)
        Me.lblDue.TabIndex = 29
        '
        'lblIssued
        '
        Me.lblIssued.AutoSize = True
        Me.lblIssued.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblIssued.Location = New System.Drawing.Point(105, 120)
        Me.lblIssued.Name = "lblIssued"
        Me.lblIssued.Size = New System.Drawing.Size(2, 15)
        Me.lblIssued.TabIndex = 28
        '
        'Worth
        '
        Me.Worth.AutoSize = True
        Me.Worth.Location = New System.Drawing.Point(14, 100)
        Me.Worth.Name = "Worth"
        Me.Worth.Size = New System.Drawing.Size(39, 13)
        Me.Worth.TabIndex = 18
        Me.Worth.Text = "Points:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(14, 163)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(44, 13)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "Expires:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(14, 121)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(41, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Issued:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label9.Location = New System.Drawing.Point(105, 162)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(2, 15)
        Me.Label9.TabIndex = 38
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(14, 142)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(30, 13)
        Me.Label13.TabIndex = 37
        Me.Label13.Text = "Due:"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label20.Location = New System.Drawing.Point(105, 57)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(2, 15)
        Me.Label20.TabIndex = 34
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label21.Location = New System.Drawing.Point(105, 76)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(2, 15)
        Me.Label21.TabIndex = 33
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label22.Location = New System.Drawing.Point(105, 96)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(2, 15)
        Me.Label22.TabIndex = 32
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label23.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label23.Location = New System.Drawing.Point(105, 311)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(2, 15)
        Me.Label23.TabIndex = 31
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label24.Location = New System.Drawing.Point(105, 183)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(2, 15)
        Me.Label24.TabIndex = 30
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label25.Location = New System.Drawing.Point(105, 141)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(2, 15)
        Me.Label25.TabIndex = 29
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label26.Location = New System.Drawing.Point(105, 120)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(2, 15)
        Me.Label26.TabIndex = 28
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(14, 312)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(84, 13)
        Me.Label31.TabIndex = 20
        Me.Label31.Text = "PPD Last frame:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(14, 184)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(26, 13)
        Me.Label6.TabIndex = 19
        Me.Label6.Text = "Eta:"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(14, 79)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(59, 13)
        Me.Label40.TabIndex = 2
        Me.Label40.Text = "No. Atoms:"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(14, 58)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(32, 13)
        Me.Label41.TabIndex = 1
        Me.Label41.Text = "Core:"
        '
        'tUpdateClients
        '
        Me.tUpdateClients.Interval = 5000
        '
        'tLogTimeout
        '
        Me.tLogTimeout.Interval = 500
        '
        'tQueueTimeout
        '
        Me.tQueueTimeout.Interval = 500
        '
        'frmTray
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1221, 661)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.sStrip)
        Me.Controls.Add(Me.mStrip)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.MainMenuStrip = Me.mStrip
        Me.MaximizeBox = False
        Me.Name = "frmTray"
        Me.Text = "maxTray"
        Me.tMenu.ResumeLayout(False)
        Me.sStrip.ResumeLayout(False)
        Me.sStrip.PerformLayout()
        Me.mStrip.ResumeLayout(False)
        Me.mStrip.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.scMain.Panel1.ResumeLayout(False)
        Me.scMain.Panel2.ResumeLayout(False)
        Me.scMain.Panel2.PerformLayout()
        Me.scMain.ResumeLayout(False)
        Me.scClLo.Panel1.ResumeLayout(False)
        Me.scClLo.Panel2.ResumeLayout(False)
        Me.scClLo.ResumeLayout(False)
        Me.spLogPGB.Panel1.ResumeLayout(False)
        Me.spLogPGB.Panel2.ResumeLayout(False)
        Me.spLogPGB.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.gbClient.ResumeLayout(False)
        Me.gbClient.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents nIcon As System.Windows.Forms.NotifyIcon
    Friend WithEvents tMenu As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents mnuClose As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuShow As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents sStrip As System.Windows.Forms.StatusStrip
    Friend WithEvents tDT As System.Windows.Forms.Timer
    Friend WithEvents mStrip As System.Windows.Forms.MenuStrip
    Friend WithEvents mnuMaxTray As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMinimize As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuProjects As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuProjectBrowser As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuDownloadProjects As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuWeb As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuUpdates As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuFoldingForum As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuEOC_forum As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuStatistics As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuExit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents scMain As System.Windows.Forms.SplitContainer
    Friend WithEvents scClLo As System.Windows.Forms.SplitContainer
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Worth As System.Windows.Forms.Label
    Friend WithEvents tUpdateClients As System.Windows.Forms.Timer
    Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuStop As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuStart As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblDue As System.Windows.Forms.Label
    Friend WithEvents lblIssued As System.Windows.Forms.Label
    Friend WithEvents lblCore As System.Windows.Forms.Label
    Friend WithEvents lblAtoms As System.Windows.Forms.Label
    Friend WithEvents lblPoints As System.Windows.Forms.Label
    Friend WithEvents lblPPD As System.Windows.Forms.Label
    Friend WithEvents lblEta As System.Windows.Forms.Label
    Friend WithEvents lblExpires As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents lblProgress As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents lblCFrameTime As System.Windows.Forms.Label
    Friend WithEvents lblProject As System.Windows.Forms.Label
    Friend WithEvents lblRemaining As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents tsTime As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents tsTotalPPD As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents llblWU As System.Windows.Forms.LinkLabel
    Friend WithEvents tLogTimeout As System.Windows.Forms.Timer
    Friend WithEvents tQueueTimeout As System.Windows.Forms.Timer
    Friend WithEvents iList As System.Windows.Forms.ImageList
    Friend WithEvents mnuClients As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem7 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuAllStart As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuAllStop As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuAllShow As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuAllHide As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuStopWhenDone As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuExtend As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuRefreshAll As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuEOC_Stats As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuPFmanager As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuPlist As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents llblTeam As System.Windows.Forms.LinkLabel
    Friend WithEvents llblName As System.Windows.Forms.LinkLabel
    Friend WithEvents gbClient As System.Windows.Forms.GroupBox
    Friend WithEvents lblPFraction As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblAllFrames As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents lbl3Frames As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lblUploaded As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents lblStuckUploads As System.Windows.Forms.Label
    Friend WithEvents lblWUReady As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents tPB As System.Windows.Forms.ProgressBar
    Friend WithEvents spLogPGB As System.Windows.Forms.SplitContainer
    Friend WithEvents rtLOG As System.Windows.Forms.RichTextBox
    Friend WithEvents lvC As System.Windows.Forms.ListView
    Friend WithEvents cName As System.Windows.Forms.ColumnHeader
    Friend WithEvents cWU As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmCore As System.Windows.Forms.ColumnHeader
    Friend WithEvents cProgress As System.Windows.Forms.ColumnHeader
    Friend WithEvents cPPD As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmEffective As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmPointsUpdate As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmEUE As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmWUsReady As System.Windows.Forms.ColumnHeader
    Friend WithEvents cWindow As System.Windows.Forms.ColumnHeader
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents lbl24HAverage As System.Windows.Forms.Label
    Friend WithEvents lblPointsToday As System.Windows.Forms.Label
    Friend WithEvents lblPointsUpdate As System.Windows.Forms.Label
    Friend WithEvents lblEocUpdate As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents lblProcessedWU As System.Windows.Forms.Label
    Friend WithEvents TestOptionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DebugToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ResizeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuStopOnFrame As System.Windows.Forms.ToolStripMenuItem
End Class
