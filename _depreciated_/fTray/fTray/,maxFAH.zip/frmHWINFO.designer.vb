﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmHWINFO
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.chkHT = New System.Windows.Forms.CheckBox()
        Me.chkFolds = New System.Windows.Forms.CheckBox()
        Me.cmbGPU = New System.Windows.Forms.ComboBox()
        Me.lblCores = New System.Windows.Forms.Label()
        Me.cmbProcessor = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.chkAdmin = New System.Windows.Forms.CheckBox()
        Me.lblUserName = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.chk64 = New System.Windows.Forms.CheckBox()
        Me.chkOsSupported = New System.Windows.Forms.CheckBox()
        Me.lblWindowsVersion = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.pnSmpType = New System.Windows.Forms.Panel()
        Me.rbDeino = New System.Windows.Forms.RadioButton()
        Me.rbMPICH = New System.Windows.Forms.RadioButton()
        Me.pnClientType = New System.Windows.Forms.Panel()
        Me.rbSMP = New System.Windows.Forms.RadioButton()
        Me.rbUni = New System.Windows.Forms.RadioButton()
        Me.cmdLocation = New System.Windows.Forms.Button()
        Me.txtLocation = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtAcPass = New System.Windows.Forms.TextBox()
        Me.tvClients = New System.Windows.Forms.TreeView()
        Me.cMenu = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.FAQToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GuideToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.cmbSmpCores = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.cmdinstall = New System.Windows.Forms.Button()
        Me.fbDialog = New System.Windows.Forms.FolderBrowserDialog()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.pnSmpType.SuspendLayout()
        Me.pnClientType.SuspendLayout()
        Me.cMenu.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(8, 20)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(123, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Processors found:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(8, 55)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(79, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Gpu found:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.chkHT)
        Me.GroupBox1.Controls.Add(Me.chkFolds)
        Me.GroupBox1.Controls.Add(Me.cmbGPU)
        Me.GroupBox1.Controls.Add(Me.lblCores)
        Me.GroupBox1.Controls.Add(Me.cmbProcessor)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(7, 95)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Size = New System.Drawing.Size(665, 89)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        '
        'chkHT
        '
        Me.chkHT.AutoSize = True
        Me.chkHT.Enabled = False
        Me.chkHT.Location = New System.Drawing.Point(579, 17)
        Me.chkHT.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.chkHT.Name = "chkHT"
        Me.chkHT.Size = New System.Drawing.Size(65, 26)
        Me.chkHT.TabIndex = 12
        Me.chkHT.Text = "HT"
        Me.chkHT.UseVisualStyleBackColor = True
        '
        'chkFolds
        '
        Me.chkFolds.AutoSize = True
        Me.chkFolds.Enabled = False
        Me.chkFolds.Location = New System.Drawing.Point(483, 54)
        Me.chkFolds.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.chkFolds.Name = "chkFolds"
        Me.chkFolds.Size = New System.Drawing.Size(89, 26)
        Me.chkFolds.TabIndex = 7
        Me.chkFolds.Text = "Folds!"
        Me.chkFolds.UseVisualStyleBackColor = True
        '
        'cmbGPU
        '
        Me.cmbGPU.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbGPU.FormattingEnabled = True
        Me.cmbGPU.Location = New System.Drawing.Point(139, 52)
        Me.cmbGPU.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmbGPU.Name = "cmbGPU"
        Me.cmbGPU.Size = New System.Drawing.Size(335, 24)
        Me.cmbGPU.TabIndex = 5
        '
        'lblCores
        '
        Me.lblCores.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCores.Location = New System.Drawing.Point(531, 15)
        Me.lblCores.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblCores.Name = "lblCores"
        Me.lblCores.Size = New System.Drawing.Size(27, 25)
        Me.lblCores.TabIndex = 4
        Me.lblCores.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmbProcessor
        '
        Me.cmbProcessor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbProcessor.FormattingEnabled = True
        Me.cmbProcessor.Location = New System.Drawing.Point(139, 15)
        Me.cmbProcessor.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmbProcessor.Name = "cmbProcessor"
        Me.cmbProcessor.Size = New System.Drawing.Size(335, 24)
        Me.cmbProcessor.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(483, 20)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(49, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Cores:"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.chkAdmin)
        Me.GroupBox2.Controls.Add(Me.lblUserName)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.chk64)
        Me.GroupBox2.Controls.Add(Me.chkOsSupported)
        Me.GroupBox2.Controls.Add(Me.lblWindowsVersion)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Location = New System.Drawing.Point(7, -1)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox2.Size = New System.Drawing.Size(665, 89)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        '
        'chkAdmin
        '
        Me.chkAdmin.AutoSize = True
        Me.chkAdmin.Enabled = False
        Me.chkAdmin.Location = New System.Drawing.Point(483, 55)
        Me.chkAdmin.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.chkAdmin.Name = "chkAdmin"
        Me.chkAdmin.Size = New System.Drawing.Size(144, 26)
        Me.chkAdmin.TabIndex = 15
        Me.chkAdmin.Text = "Admin rights"
        Me.chkAdmin.UseVisualStyleBackColor = True
        '
        'lblUserName
        '
        Me.lblUserName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblUserName.Location = New System.Drawing.Point(141, 55)
        Me.lblUserName.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblUserName.Name = "lblUserName"
        Me.lblUserName.Size = New System.Drawing.Size(333, 20)
        Me.lblUserName.TabIndex = 14
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(16, 57)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(98, 17)
        Me.Label9.TabIndex = 13
        Me.Label9.Text = "Windows User"
        '
        'chk64
        '
        Me.chk64.AutoSize = True
        Me.chk64.Enabled = False
        Me.chk64.Location = New System.Drawing.Point(579, 21)
        Me.chk64.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.chk64.Name = "chk64"
        Me.chk64.Size = New System.Drawing.Size(69, 26)
        Me.chk64.TabIndex = 11
        Me.chk64.Text = "x64"
        Me.chk64.UseVisualStyleBackColor = True
        '
        'chkOsSupported
        '
        Me.chkOsSupported.AutoSize = True
        Me.chkOsSupported.Enabled = False
        Me.chkOsSupported.Location = New System.Drawing.Point(483, 21)
        Me.chkOsSupported.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.chkOsSupported.Name = "chkOsSupported"
        Me.chkOsSupported.Size = New System.Drawing.Size(128, 26)
        Me.chkOsSupported.TabIndex = 12
        Me.chkOsSupported.Text = "Supported"
        Me.chkOsSupported.UseVisualStyleBackColor = True
        '
        'lblWindowsVersion
        '
        Me.lblWindowsVersion.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblWindowsVersion.Location = New System.Drawing.Point(141, 21)
        Me.lblWindowsVersion.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblWindowsVersion.Name = "lblWindowsVersion"
        Me.lblWindowsVersion.Size = New System.Drawing.Size(333, 20)
        Me.lblWindowsVersion.TabIndex = 10
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(16, 22)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(114, 17)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Windows version"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.GroupBox4)
        Me.GroupBox3.Controls.Add(Me.cmdLocation)
        Me.GroupBox3.Controls.Add(Me.txtLocation)
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.txtAcPass)
        Me.GroupBox3.Controls.Add(Me.tvClients)
        Me.GroupBox3.Location = New System.Drawing.Point(7, 191)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox3.Size = New System.Drawing.Size(665, 311)
        Me.GroupBox3.TabIndex = 4
        Me.GroupBox3.TabStop = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.pnSmpType)
        Me.GroupBox4.Controls.Add(Me.pnClientType)
        Me.GroupBox4.Location = New System.Drawing.Point(12, 14)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox4.Size = New System.Drawing.Size(624, 59)
        Me.GroupBox4.TabIndex = 15
        Me.GroupBox4.TabStop = False
        '
        'pnSmpType
        '
        Me.pnSmpType.Controls.Add(Me.rbDeino)
        Me.pnSmpType.Controls.Add(Me.rbMPICH)
        Me.pnSmpType.Location = New System.Drawing.Point(335, 20)
        Me.pnSmpType.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.pnSmpType.Name = "pnSmpType"
        Me.pnSmpType.Size = New System.Drawing.Size(284, 31)
        Me.pnSmpType.TabIndex = 16
        '
        'rbDeino
        '
        Me.rbDeino.AutoSize = True
        Me.rbDeino.Location = New System.Drawing.Point(173, 4)
        Me.rbDeino.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rbDeino.Name = "rbDeino"
        Me.rbDeino.Size = New System.Drawing.Size(101, 21)
        Me.rbDeino.TabIndex = 7
        Me.rbDeino.TabStop = True
        Me.rbDeino.Text = "Use DEINO"
        Me.rbDeino.UseVisualStyleBackColor = True
        '
        'rbMPICH
        '
        Me.rbMPICH.AutoSize = True
        Me.rbMPICH.Location = New System.Drawing.Point(28, 4)
        Me.rbMPICH.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rbMPICH.Name = "rbMPICH"
        Me.rbMPICH.Size = New System.Drawing.Size(108, 21)
        Me.rbMPICH.TabIndex = 8
        Me.rbMPICH.TabStop = True
        Me.rbMPICH.Text = "Use MPICH2"
        Me.rbMPICH.UseVisualStyleBackColor = True
        '
        'pnClientType
        '
        Me.pnClientType.Controls.Add(Me.rbSMP)
        Me.pnClientType.Controls.Add(Me.rbUni)
        Me.pnClientType.Location = New System.Drawing.Point(8, 18)
        Me.pnClientType.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.pnClientType.Name = "pnClientType"
        Me.pnClientType.Size = New System.Drawing.Size(319, 33)
        Me.pnClientType.TabIndex = 15
        '
        'rbSMP
        '
        Me.rbSMP.AutoSize = True
        Me.rbSMP.Location = New System.Drawing.Point(175, 5)
        Me.rbSMP.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rbSMP.Name = "rbSMP"
        Me.rbSMP.Size = New System.Drawing.Size(124, 21)
        Me.rbSMP.TabIndex = 0
        Me.rbSMP.TabStop = True
        Me.rbSMP.Text = "Use SMP client"
        Me.rbSMP.UseVisualStyleBackColor = True
        '
        'rbUni
        '
        Me.rbUni.AutoSize = True
        Me.rbUni.Location = New System.Drawing.Point(4, 5)
        Me.rbUni.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rbUni.Name = "rbUni"
        Me.rbUni.Size = New System.Drawing.Size(170, 21)
        Me.rbUni.TabIndex = 8
        Me.rbUni.TabStop = True
        Me.rbUni.Text = "Use uniprocesor client"
        Me.rbUni.UseVisualStyleBackColor = True
        '
        'cmdLocation
        '
        Me.cmdLocation.Location = New System.Drawing.Point(585, 238)
        Me.cmdLocation.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmdLocation.Name = "cmdLocation"
        Me.cmdLocation.Size = New System.Drawing.Size(47, 25)
        Me.cmdLocation.TabIndex = 14
        Me.cmdLocation.Text = "..."
        Me.cmdLocation.UseVisualStyleBackColor = True
        '
        'txtLocation
        '
        Me.txtLocation.Location = New System.Drawing.Point(12, 238)
        Me.txtLocation.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtLocation.Name = "txtLocation"
        Me.txtLocation.Size = New System.Drawing.Size(559, 22)
        Me.txtLocation.TabIndex = 13
        Me.txtLocation.Text = "-select location-"
        Me.txtLocation.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(19, 278)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(216, 17)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Account password for SMP setup"
        '
        'txtAcPass
        '
        Me.txtAcPass.Location = New System.Drawing.Point(271, 273)
        Me.txtAcPass.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txtAcPass.Name = "txtAcPass"
        Me.txtAcPass.Size = New System.Drawing.Size(364, 22)
        Me.txtAcPass.TabIndex = 9
        Me.txtAcPass.UseSystemPasswordChar = True
        '
        'tvClients
        '
        Me.tvClients.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tvClients.CheckBoxes = True
        Me.tvClients.ContextMenuStrip = Me.cMenu
        Me.tvClients.Location = New System.Drawing.Point(12, 85)
        Me.tvClients.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.tvClients.Name = "tvClients"
        Me.tvClients.ShowLines = False
        Me.tvClients.Size = New System.Drawing.Size(623, 145)
        Me.tvClients.TabIndex = 5
        '
        'cMenu
        '
        Me.cMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FAQToolStripMenuItem, Me.GuideToolStripMenuItem})
        Me.cMenu.Name = "cMenu"
        Me.cMenu.Size = New System.Drawing.Size(106, 48)
        '
        'FAQToolStripMenuItem
        '
        Me.FAQToolStripMenuItem.Name = "FAQToolStripMenuItem"
        Me.FAQToolStripMenuItem.Size = New System.Drawing.Size(105, 22)
        Me.FAQToolStripMenuItem.Text = "FAQ"
        '
        'GuideToolStripMenuItem
        '
        Me.GuideToolStripMenuItem.Name = "GuideToolStripMenuItem"
        Me.GuideToolStripMenuItem.Size = New System.Drawing.Size(105, 22)
        Me.GuideToolStripMenuItem.Text = "Guide"
        '
        'cmbSmpCores
        '
        Me.cmbSmpCores.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbSmpCores.Enabled = False
        Me.cmbSmpCores.FormattingEnabled = True
        Me.cmbSmpCores.Items.AddRange(New Object() {"4", "2"})
        Me.cmbSmpCores.Location = New System.Drawing.Point(948, 21)
        Me.cmbSmpCores.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmbSmpCores.Name = "cmbSmpCores"
        Me.cmbSmpCores.Size = New System.Drawing.Size(53, 24)
        Me.cmbSmpCores.TabIndex = 12
        Me.cmbSmpCores.Visible = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Enabled = False
        Me.Label6.Location = New System.Drawing.Point(757, 26)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(177, 17)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "No. of cores per smp client"
        Me.Label6.Visible = False
        '
        'Button2
        '
        Me.Button2.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button2.Location = New System.Drawing.Point(16, 510)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(135, 33)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "Cancel"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'cmdinstall
        '
        Me.cmdinstall.Enabled = False
        Me.cmdinstall.Location = New System.Drawing.Point(537, 510)
        Me.cmdinstall.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmdinstall.Name = "cmdinstall"
        Me.cmdinstall.Size = New System.Drawing.Size(135, 33)
        Me.cmdinstall.TabIndex = 1
        Me.cmdinstall.Text = "Install"
        Me.cmdinstall.UseVisualStyleBackColor = True
        '
        'fbDialog
        '
        Me.fbDialog.RootFolder = System.Environment.SpecialFolder.MyComputer
        '
        'frmHWINFO
        '
        Me.AcceptButton = Me.cmdinstall
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.Button2
        Me.ClientSize = New System.Drawing.Size(680, 551)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.cmbSmpCores)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.cmdinstall)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.MaximizeBox = False
        Me.Name = "frmHWINFO"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Client selection"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.pnSmpType.ResumeLayout(False)
        Me.pnSmpType.PerformLayout()
        Me.pnClientType.ResumeLayout(False)
        Me.pnClientType.PerformLayout()
        Me.cMenu.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents lblCores As System.Windows.Forms.Label
    Friend WithEvents cmbProcessor As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents chkFolds As System.Windows.Forms.CheckBox
    Friend WithEvents cmbGPU As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents chk64 As System.Windows.Forms.CheckBox
    Friend WithEvents lblWindowsVersion As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents chkOsSupported As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents tvClients As System.Windows.Forms.TreeView
    Friend WithEvents chkHT As System.Windows.Forms.CheckBox
    Friend WithEvents chkAdmin As System.Windows.Forms.CheckBox
    Friend WithEvents lblUserName As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents rbMPICH As System.Windows.Forms.RadioButton
    Friend WithEvents rbDeino As System.Windows.Forms.RadioButton
    Friend WithEvents fbDialog As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents cmdinstall As System.Windows.Forms.Button
    Friend WithEvents cMenu As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents FAQToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GuideToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtAcPass As System.Windows.Forms.TextBox
    Friend WithEvents cmbSmpCores As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents cmdLocation As System.Windows.Forms.Button
    Friend WithEvents txtLocation As System.Windows.Forms.TextBox
    Friend WithEvents pnClientType As System.Windows.Forms.Panel
    Friend WithEvents rbUni As System.Windows.Forms.RadioButton
    Friend WithEvents rbSMP As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents pnSmpType As System.Windows.Forms.Panel
End Class
