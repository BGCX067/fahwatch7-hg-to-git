﻿'   EOC stats form
'   Copyright (c) 2010 Marvin Westmaas ( MtM / Marvin_The_Martian )
'
'   This program is free software: you can redistribute it and/or modify
'   it under the terms of the GNU General Public License as published by
'   the Free Software Foundation, either version 3 of the License, or
'   (at your option) any later version.
'
'   This program is distributed in the hope that it will be useful,
'   but WITHOUT ANY WARRANTY; without even the implied warranty of
'   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'   GNU General Public License for more details.
'
'   You should have received a copy of the GNU General Public License
'   along with this program.  If not, see <http://www.gnu.org/licenses/>.
Imports System.Xml
Imports System.Xml.XPath
Public Class frmEOC
    Private WithEvents tUpdate As New System.Timers.Timer
    Private mLocation As New System.Drawing.Point
    Private UserName As String = ""
    Private TeamNumber As String = ""
    Private UserID As String = ""
    Private bOnTop As Boolean = False
    Private _Client As clsClientConfiguration.clsClientConfigs.sClientSettings.sClient
    Private dtShown As New DateTime
    Private WithEvents tFade As New System.Timers.Timer
    Private _FadeTimeOut As Double = 5000
    Public ReadOnly Property MyPosition() As System.Drawing.Point
        Get
            Return mLocation
        End Get
    End Property
    Public Function ShowSig(ByVal Client As clsClientConfiguration.clsClientConfigs.sClientSettings.sClient, Optional ByVal FadeTimeOut As Double = 5000) As Boolean
        Try
            _FadeTimeOut = FadeTimeOut
            UserName = Client.PandeGroup.UserName
            TeamNumber = Client.PandeGroup.TeamNumber
            _Client = Client
            If _Client.EocID <> "" Then UserID = _Client.EocID
            If Client.GuiController.EOCStats.bHasImage Then
                pb.ImageLocation = Client.GuiController.EOCStats.fileSignatureImage
                pb.Refresh()
                If Not Client.GuiController.EOCStats.bImageRecent Then
                    MsgBox("The signature image displayed is outdated but could not be refreshed")
                End If
            Else
                MsgBox("There is no EOC signature image stored, and attempts to refresh it have failed")
                Return False
            End If
            nIcon.Text &= vbNewLine & UserName & " (" & TeamNumber & ")"
            nIcon.ContextMenuStrip = cMenu
            nIcon.Icon = My.Resources.EOC
            tUpdate.Interval = TimeSpan.FromHours(3).TotalMilliseconds
            tUpdate.AutoReset = True
            tUpdate.Enabled = True
            dtLastUpdate = DateTime.Now
            Me.Visible = True
            Return True
        Catch ex As Exception
            LogWindow.WriteError("frmEOC, ShowSig", Err, ex.Message)
            Me.Close()
            Return False
        End Try
    End Function
    Private Sub nIcon_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles nIcon.MouseClick
        Try
            If e.Button = Windows.Forms.MouseButtons.Right Then
                cMenu.Show()
            ElseIf e.Button = Windows.Forms.MouseButtons.Left Then
                If Me.Visible = False Then
                    Me.Visible = True
                Else
                    Me.Visible = False
                    tFade.Enabled = False
                End If
            End If
        Catch ex As Exception
            LogWindow.WriteError("frmEOC, nIcon.MouseClick", Err, ex.Message)
        End Try
    End Sub
    Private Sub cMenu_ItemClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles cMenu.ItemClicked
        Try
            Select Case e.ClickedItem.Text
                Case "Close sig image"
                    nIcon.Visible = False
                    Me.Close()
                Case "View user stats"
                    If UserID = "" Then
                        Try
                            Dim xSettings As XmlReaderSettings = New XmlReaderSettings()
                            xSettings.IgnoreComments = True
                            xSettings.IgnoreProcessingInstructions = True
                            xSettings.IgnoreWhitespace = True
                            Dim xResolver As XmlUrlResolver = New XmlUrlResolver()
                            xResolver.Credentials = System.Net.CredentialCache.DefaultCredentials
                            ' Set the reader settings object to use the resolver.
                            xSettings.XmlResolver = xResolver
                            Using xReader As XmlReader = XmlReader.Create("http://folding.extremeoverclocking.com/xml/user_summary.php?un=" & UserName & "&t=" & TeamNumber, xSettings)
                                With xReader
                                    .ReadToFollowing("UserID")
                                    UserID = .ReadElementString("UserID")
                                End With
                            End Using
                            _Client.EocID = UserID
                        Catch ex As Exception
                            'Set userid to -1
                            UserID = "-1"
                        End Try
                    End If
                    If Not UserID = "-1" Then Process.Start("http://folding.extremeoverclocking.com/user_summary.php?s=&u=" & UserID)
                Case "View team stats"
                    Process.Start("http://folding.extremeoverclocking.com/team_summary.php?s=&t=" & TeamNumber)
                Case "Reload image"
                    If DateTime.Now.Subtract(_Client.GuiController.EOCStats.LastUpdate.UpdateStatus.Last_Update_LocalTime).TotalHours < 3 Then
                        MsgBox("The current signature image is the most recent, update aborted.", MsgBoxStyle.OkOnly And MsgBoxStyle.Information, "Abuse preventer")
                        Exit Sub
                    End If
                    pb.ImageLocation = _Client.GuiController.EOCStats.fileSignatureImage
                    pb.Refresh()
                    dtLastUpdate = DateTime.Now
                    tUpdate.Enabled = False
                    tUpdate.AutoReset = True
                    tUpdate.Interval = TimeSpan.FromHours(3).TotalMilliseconds
                    tUpdate.Enabled = True
                Case "Remove on top"
                    bOnTop = False
                    Me.TopMost = bOnTop
                Case "Put on top"
                    bOnTop = True
                    Me.TopMost = bOnTop
            End Select
        Catch ex As Exception
            LogWindow.WriteError("frmEOC, cMenu.Itemclicked", Err, ex.Message)
        End Try
    End Sub
    Private dtLastUpdate As New DateTime
    Private Sub tUpdate_Elapsed(ByVal sender As Object, ByVal e As System.Timers.ElapsedEventArgs) Handles tUpdate.Elapsed
        Try
            Dim iRefresh As New RefPb(AddressOf RefreshPB)
            Me.Invoke(iRefresh)
        Catch ex As Exception
            LogWindow.WriteError("frmEOC, tUpdate.Elapsed", Err, ex.Message)
        End Try
    End Sub
    Delegate Sub RefPb()
    Private Sub RefreshPB()
        Try
            dtLastUpdate = DateTime.Now
            pb.ImageLocation = _Client.GuiController.EOCStats.fileSignatureImage
            pb.Refresh()
        Catch ex As Exception
            LogWindow.WriteError("frmEOC, RefreshPB", Err, ex.Message)
            'image could not be refreshed, close form
            Me.Close()
        End Try
    End Sub
    Private Sub nIcon_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles nIcon.MouseDown
        Try
            cMenu.Items.Clear()
            cMenu.Items.Add("Close sig image")
            cMenu.Items.Add("View user stats")
            cMenu.Items.Add("View team stats")
            cMenu.Items.Add("-")
            If bOnTop Then
                cMenu.Items.Add("Remove on top")
            Else
                cMenu.Items.Add("Put on top")
            End If
            cMenu.Items.Add("Reload image")
        Catch ex As Exception
            LogWindow.WriteError("frmEOC, nIcon.MouseDown", Err, ex.Message)
        End Try
    End Sub
    Private Sub frmEOC_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        On Error Resume Next
        _FadeThread.Abort()
        _SetOpThread.Abort()
        _FadeThread = Nothing
        _SetOpThread = Nothing
        nIcon.Visible = False
        tUpdate.Enabled = False
        tUpdate.Close()
        tUpdate = Nothing
        nIcon = Nothing
        _Client.GuiController.StatsVisible = False
    End Sub

    Private Sub frmEOC_VisibleChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.VisibleChanged
        Try
            If Me.Visible Then
                mLocation.Y = Screen.PrimaryScreen.WorkingArea.Bottom - pb.Height
                mLocation.X = Screen.PrimaryScreen.WorkingArea.Right - pb.Width
                For Xind As Int16 = 1 To Clients.GetUpperBound(0)
                    If Clients(Xind).Index <> _Client.Index And Clients(Xind).GuiController.StatsForm.Visible Then
                        mLocation.Y -= pb.Height
                    End If
                Next
                Me.Location = mLocation
                If _FadeTimeOut > 0 Then
                    tFade.Enabled = False
                    tFade.AutoReset = False
                    tFade.Interval = _FadeTimeOut
                    tFade.Enabled = True
                End If
            End If
        Catch ex As Exception
            LogWindow.WriteError("frmEOC, VisibleChanged", Err, ex.Message)
        End Try

    End Sub
    Delegate Sub fFade()
    Private _FadeThread As Threading.Thread
    Private _SetOpThread As Threading.Thread
    Private Sub Fade()
        Try
            While Me.Opacity > 0
                Dim _SetOpThread As New Threading.Thread(AddressOf SetOpacity)
                _SetOpThread.Start(Me.Opacity - 0.01)
                Threading.Thread.CurrentThread.Sleep(5)
            End While
            Reset()
        Catch ex As Exception
            LogWindow.WriteError("frmEOC, Fade", Err, ex.Message)
        End Try
    End Sub
    Delegate Sub ResetMe()
    Private Sub Reset()
        Try
            If Me.InvokeRequired Then
                Dim mRes As New ResetMe(AddressOf Reset)
                Me.Invoke(mRes)
            Else
                Me.Visible = False
                Me.Opacity = 100
            End If
        Catch ex As Exception
            LogWindow.WriteError("frmEOC, Reset", Err, ex.Message)
        End Try
    End Sub
    Delegate Sub SetOp(ByVal Value As Double)
    Private Sub SetOpacity(ByVal Value As Double)
        Try
            If Me.InvokeRequired Then
                Dim mInv As New SetOp(AddressOf SetOpacity)
                Me.Invoke(mInv, New Object() {Value})
            Else
                Me.Opacity = Value
            End If
        Catch ex As Exception
            LogWindow.WriteError("frmEOC, SetOpacity", Err, ex.Message)
        End Try
    End Sub
    Private Sub tFade_Elapsed(ByVal sender As Object, ByVal e As System.Timers.ElapsedEventArgs) Handles tFade.Elapsed
        Try
            Dim _FadeThread As New Threading.Thread(AddressOf Fade)
            _FadeThread.Start()
        Catch ex As Exception
            LogWindow.WriteError("frmEOC, tFade_Elapsed", Err, ex.Message)
        End Try
    End Sub
End Class